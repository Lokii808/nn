import sys

def generate_wordlist(subdomains_file, domain):
    # Verifica se os parâmetros estão presentes
    if not subdomains_file or not domain:
        print("Uso: python3 nodes_creator.py subdominios.txt dominio.com")
        sys.exit(1)

    try:
        # Abre o arquivo de subdomínios e cria a wordlist
        with open(subdomains_file, 'r') as f:
            subdomains = f.readlines()

        # Cria a wordlist com os subdomínios e o domínio
        wordlist = [sub.strip() + '.' + domain for sub in subdomains]

        # Adiciona os novos subdomínios ao arquivo wordlist.txt
        with open('wordlist.txt', 'a') as f:
            f.write("\n".join(wordlist) + "\n")

        print("[+] Wordlist adicionada ao arquivo: wordlist.txt")
    except FileNotFoundError:
        print(f"Erro: O arquivo {subdomains_file} não foi encontrado.")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python3 nodes_creator.py subdominios.txt dominio.com")
        sys.exit(1)

    subdomains_file = sys.argv[1]
    domain = sys.argv[2]

    generate_wordlist(subdomains_file, domain)
