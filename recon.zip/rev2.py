import re
import ipaddress
import subprocess
import os

HTTPX_OUTPUT = "pure.txt"
IP_PORTS_FILE = "ip_ports.txt"
IPS_MASSCAN_FILE = "ips_masscan.txt"
MASSCAN_OUTPUT = "masscan_results.txt"
HTTPX_FILTERED_OUTPUT = "httpx_filtered.txt"
PORTS_ABERTAS_OUTPUT = "ports_abertas.txt"

IGNORE_PORTS = {"80", "443", "8080", "8443"}
STATUS_DESEJADOS = ["[200]", "[404]"]

def run_httpx(input_file):
    print("[*] Rodando httpx para HTTP probing...")
    cmd = ["httpx", "-l", input_file, "-ip", "-silent"]
    print("[*] Executando:", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("[!] Erro ao rodar httpx:", result.stderr)
        return False
    with open(HTTPX_OUTPUT, "w") as f:
        f.write(result.stdout)
    return True

def extract_ip_ports(input_file=HTTPX_OUTPUT, output_file=IP_PORTS_FILE):
    print("[*] Extraindo IP:PORT para masscan (IPv6 serão ignorados)...")
    ip_ports = set()
    with open(input_file, "r") as f_in:
        for line in f_in:
            line = line.strip()
            if not line:
                continue

            m = re.match(r"^(https?://[^\s]+)\s+\[([^\]]+)\]$", line)
            if not m:
                print(f"[!] Linha ignorada por formato inesperado: {line}")
                continue

            url = m.group(1)
            ip = m.group(2)

            try:
                ip_obj = ipaddress.ip_address(ip)
                if ip_obj.version != 4:
                    continue
            except ValueError:
                continue

            port_match = re.search(r":(\d+)", url)
            port = port_match.group(1) if port_match else ("80" if url.startswith("http://") else "443")

            ipport = f"{ip}:{port}"
            ip_ports.add(ipport)

    with open(output_file, "w") as f_out:
        for ipport in sorted(ip_ports):
            f_out.write(ipport + "\n")

def extract_ipv4_only(ip_ports_file=IP_PORTS_FILE, output_file=IPS_MASSCAN_FILE):
    print("[*] Extraindo somente IPs IPv4 para masscan...")
    ips = set()
    with open(ip_ports_file, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            ip_port = line.split(":")
            ip = ip_port[0]
            try:
                ip_obj = ipaddress.ip_address(ip)
                if ip_obj.version == 4:
                    ips.add(ip)
            except ValueError:
                continue
    with open(output_file, "w") as f_out:
        for ip in sorted(ips):
            f_out.write(ip + "\n")

def run_masscan(ip_list_file=IPS_MASSCAN_FILE, output_file=MASSCAN_OUTPUT):
    print("[*] Rodando masscan para escanear todas as portas TCP (1-65535) abertas (somente IPv4)...")
    ports = "1-65535"
    rate = "1000"
    cmd = ["masscan", "-iL", ip_list_file, "-p", ports, "--rate", rate, "-oG", output_file]
    print("[*] Executando:", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("[!] Erro ao executar masscan:", result.stderr)
        return False
    return True

def parse_masscan_output(masscan_file=MASSCAN_OUTPUT):
    ip_ports_abertos = set()
    if not os.path.isfile(masscan_file):
        print(f"[!] Arquivo {masscan_file} não existe. Pulando parsing.")
        return ip_ports_abertos

    with open(masscan_file, "r") as f:
        for line in f:
            if "Host:" in line and "Ports:" in line:
                m = re.search(r"Host:\s+(\S+)\s+\(\)\s+Ports:\s+(\d+)/open", line)
                if m:
                    ip = m.group(1)
                    port = m.group(2)
                    ip_ports_abertos.add(f"{ip}:{port}")
    return ip_ports_abertos

def run_httpx_filtered_and_notify(ip_ports_set):
    print("[*] Filtrando portas (ignorando 80,443,8080,8443) e rodando httpx...")
    filtered = [ipport for ipport in ip_ports_set if ipport.split(":")[1] not in IGNORE_PORTS]

    if not filtered:
        print("[!] Nenhum IP:PORT fora das portas ignoradas para rodar httpx.")
        return

    with open("httpx_input_filtered.txt", "w") as f:
        for item in filtered:
            if item.startswith("http"):
                f.write(item + "\n")
            else:
                f.write(f"https://{item}\n")

    cmd = ["httpx", "-l", "httpx_input_filtered.txt", "-status-code", "-silent"]
    print("[*] Executando:", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("[!] Erro ao rodar httpx:", result.stderr)
        return

    def strip_ansi(text):
        return re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', text)

    linhas_validas = []
    for linha in result.stdout.splitlines():
        limpa = strip_ansi(linha)
        if any(status in limpa for status in STATUS_DESEJADOS):
            linhas_validas.append(limpa)

    with open(HTTPX_FILTERED_OUTPUT, "w") as f_out:
        f_out.write("\n".join(linhas_validas))

    if linhas_validas:
        with open(PORTS_ABERTAS_OUTPUT, "w") as f_save:
            f_save.write("\n".join(linhas_validas))

        notify_cmd = ["notify", "-provider", "discord"]
        print("[*] Enviando resultado do httpx (200 ou 404) para discord via notify...")
        notify_proc = subprocess.run(notify_cmd, input="\n".join(linhas_validas), text=True, capture_output=True)
        if notify_proc.returncode != 0:
            print("[!] Erro ao enviar notify:", notify_proc.stderr)
        else:
            print("[*] Notify enviado com sucesso.")
    else:
        print("[!] Nenhuma resposta com status 200 ou 404 para enviar ao discord.")

def main():
    if not run_httpx("pure.txt"):
        print("[!] Falha ao rodar httpx, abortando.")
        return

    extract_ip_ports()
    extract_ipv4_only()

    if os.path.getsize(IPS_MASSCAN_FILE) == 0:
        print("[!] Nenhum IP válido para escanear no arquivo", IPS_MASSCAN_FILE)
        return

    if not run_masscan():
        print("[!] Falha ao rodar masscan, abortando.")
        return

    ip_ports_abertos = parse_masscan_output()
    print("[*] Portas abertas encontradas pelo masscan:")
    for ipport in sorted(ip_ports_abertos):
        print(ipport)

    run_httpx_filtered_and_notify(ip_ports_abertos)

if __name__ == "__main__":
    main()