import sys
import subprocess
from concurrent.futures import ThreadPoolExecutor

# Verifica se o arquivo foi passado
if len(sys.argv) < 2:
    print(f"Uso: {sys.argv[0]} list.txt")
    sys.exit(1)

DOMS_FILE = sys.argv[1]

def check_domain(domain):
    domain = domain.strip()
    if not domain or domain.startswith("-"):
        return  # Ignora domínios inválidos que causam erro no dig

    try:
        # Obtém resposta simples
        resposta = subprocess.check_output(["dig", domain, "+short"], text=True).strip()

        # Pega saída completa para verificar status
        dig_output = subprocess.check_output(["dig", domain], text=True)
        status = ""
        for line in dig_output.splitlines():
            if "status:" in line:
                parts = line.split()
                if len(parts) >= 6:
                    status = parts[5].strip(',').upper()
                break

        if status == "NOERROR" and not resposta:
            # Sanitiza domínio para notificação
            safe_domain = domain.replace('_', '\\_').replace('|', '').replace('*', '').replace('[', '').replace(']', '')
            msg = f"{safe_domain} - NOERROR sem IP"
            print(msg)
            subprocess.run(["notify"], input=msg, text=True)

    except subprocess.CalledProcessError:
        pass

with open(DOMS_FILE) as f:
    domains = f.readlines()

with ThreadPoolExecutor(max_workers=50) as executor:
    executor.map(check_domain, domains)
