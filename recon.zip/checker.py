# checker.py

def main():
    try:
        with open("urls_resolved.txt", "r") as file:
            lines = file.readlines()
        
        if len(lines) > 100:
            print(f"[+] Mais de 100 linhas encontradas ({len(lines)} linhas). Deletando o arquivo...")
            import os
            os.remove("urls_resolved.txt")
        else:
            print(f"[-] Apenas {len(lines)} linhas encontradas. Nenhuma ação necessária.")
            pass

    except FileNotFoundError:
        print("[!] Arquivo urls_resolved.txt não encontrado.")

if __name__ == "__main__":
    main()
