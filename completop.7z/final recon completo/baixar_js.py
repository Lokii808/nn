import requests
import os
import argparse
from urllib.parse import urlparse
import urllib3

# Supressão de avisos de SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def baixar_conteudo(lista_urls, output_dir):
    # Verifica se o diretório de saída existe, caso contrário, cria
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    with open(lista_urls, 'r', encoding='utf-8') as f:
        urls = f.read().splitlines()

    for idx, url in enumerate(urls, start=1):
        if not url.strip():
            continue

        try:
            print(f"Baixando: {url}")
            # Ignorando erros de SSL com verify=False
            response = requests.get(url, headers=headers, timeout=10, verify=False)
            response.raise_for_status()  # Gera uma exceção para códigos 4xx/5xx

            # Extrai o nome original do arquivo da URL
            parsed_url = urlparse(url)
            original_name = os.path.basename(parsed_url.path) or "index.html"

            # Adiciona o prefixo numérico ao nome do arquivo
            filename = f"{idx}_{original_name}.txt"

            # Cria o caminho completo do arquivo
            file_path = os.path.join(output_dir, filename)

            # Salva o conteúdo no arquivo
            with open(file_path, 'wb') as file:
                file.write(response.content)

            print(f"Salvo em: {file_path}")

        except requests.RequestException as e:
            print(f"Erro ao baixar {url}: {e}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Script para baixar conteúdos de URLs com sufixos numéricos")
    parser.add_argument("-l", "--lista", required=True, help="Arquivo contendo as URLs, uma por linha")
    parser.add_argument("-o", "--output", default="downloads", help="Diretório de saída (padrão: 'downloads')")
    args = parser.parse_args()

    baixar_conteudo(args.lista, args.output)
