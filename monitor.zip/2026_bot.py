#!/usr/bin/env python3
import os
import time
import subprocess
import signal
import datetime

# -----------------------------
# Configurações de Arquivos e Timeouts
# -----------------------------
TEMP_FILE = "temp.txt"          # Saída bruta do gungnir
LOG_FILE = "todos_subs.txt"      # Sua base de dados histórica (subdomínios já conhecidos)
ROOTS_FILE = "xx.txt"            # Lista de domínios alvo para o gungnir

HTTPX_TEMP_FILE = "httpx_temp.txt" # Resultados do scan de segurança (200, 307, 404)
SLICE_FILE = "slice1.txt"          # Caminhos "fatiados" pelo slicepathsurl
KATANA_FILE = "katana.txt"         # Saída do crawler Katana
ERRORS_400_FILE = "400s.txt"       # Alvos que retornaram status de erro (401, 403, 500, etc)

GUNGNIR_TIMEOUT = 20 * 60  # Limita a execução do gungnir a 20 minutos
HTTPX_TIMEOUT = 600       # Limita o httpx a 10 minutos por rodada

# Lista extensa de portas para busca de serviços web não padronizados
HTTPX_PORTS = (
    "80,443,8000,8080,8443,81,591,2082,2083,2086,2087,2095,2096,2480,"
    "3000,3333,4243,4567,4711,4712,4993,5000,5104,5108,5800,6543,7000,"
    "7396,7474,8001,8008,8042,8069,8081,8082,8088,8090,8091,8118,8123,"
    "8172,8222,8243,8280,8281,8333,8444,8500,8834,8880,8888,8983,9000,"
    "9043,9060,9080,9090,9091,9200,9443,9800,9981,12443,16080,18091,"
    "18092,20720"
)

HTTPX_CODES = "200,307,404" # Códigos de status considerados "interessantes" para o pipeline de segurança

# -----------------------------
# Função: Coleta de Subdomínios via Certificados (Gungnir)
# -----------------------------
def run_gungnir_for_1_hour():
    print(f"[+] Rodando gungnir ({datetime.datetime.now()})")
    # Monitora logs de transparência de certificados e remove domínios específicos indesejados
    cmd = f"gungnir -r {ROOTS_FILE} | egrep -v 'mini.sk'"
    with open(TEMP_FILE, "w") as out:
        proc = subprocess.Popen(
            cmd, shell=True, stdout=out, stderr=subprocess.DEVNULL, preexec_fn=os.setsid
        )
        try:
            proc.wait(timeout=GUNGNIR_TIMEOUT)
        except subprocess.TimeoutExpired:
            # Mata o processo se passar do tempo limite definido
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)

# -----------------------------
# Função: Carregar base histórica
# -----------------------------
def load_existing_logs():
    if not os.path.exists(LOG_FILE):
        return set()
    with open(LOG_FILE) as f:
        return set(x.strip() for x in f if x.strip())

# -----------------------------
# Função: Primeiro Scan de Segurança (Httpx Completo)
# -----------------------------
def run_httpx_on_entries(entries):
    if not entries:
        return ""
    print(f"[+] Rodando httpx em {len(entries)} entradas")
    # Escaneia todas as portas definidas procurando pelos códigos 200, 307 e 404
    cmd = ["httpx", "-p", HTTPX_PORTS, "--mc", HTTPX_CODES, "-silent", "-t", "100"]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    try:
        out, _ = proc.communicate("\n".join(entries), timeout=HTTPX_TIMEOUT)
    except subprocess.TimeoutExpired:
        proc.kill()
        out, _ = proc.communicate()
    if out.strip():
        with open(HTTPX_TEMP_FILE, "w") as f:
            f.write(out) # Salva para o Katana/Nuclei processarem depois
    return out

# -----------------------------
# Função: Scan de Portas em Erros 40x/500 (A que você pediu)
# -----------------------------
def run_status_400_check(input_file):
    if not os.path.exists(input_file):
        return
    print("[+] Verificando portas em alvos com status 40x/500...")
    
    # 1. Filtra do arquivo de novos subs apenas quem retorna erro HTTP
    os.system(f"httpx -l {input_file} -mc 404,403,500,401 -silent > {ERRORS_400_FILE}")
    
    if os.path.exists(ERRORS_400_FILE) and os.path.getsize(ERRORS_400_FILE) > 0:
        # 2. Se houver erros, re-escaneia todas as portas e envia pro Discord com seu prefixo
        cmd = (
            f"httpx -l {ERRORS_400_FILE} -p {HTTPX_PORTS} -silent | "
            f"awk '{{print \"(porta encontrada a partir de status 403|400|500|401 | \" $1 \")\"}}' | "
            f"notify -provider discord"
        )
        os.system(cmd)

# -----------------------------
# Função: Pipeline de Vulnerabilidade (Katana -> Slice -> Nuclei)
# -----------------------------
def run_security_pipeline():
    if not os.path.exists(HTTPX_TEMP_FILE) or os.path.getsize(HTTPX_TEMP_FILE) == 0:
        return

    # Crawler para encontrar endpoints, ignorando arquivos estáticos (js, jpg, etc)
    os.system(
        f"katana -list {HTTPX_TEMP_FILE} -c 5 -d 2 -retry 1 -timeout 5 "
        f"-ef js,jpg,jpeg,gif,css,png,svg,ico,pdf,woff,woff2 > {KATANA_FILE}"
    )

    # Filtra e organiza as URLs encontradas pelo Katana
    os.system(f"cat {KATANA_FILE} | slicepathsurl -l 5 > {SLICE_FILE}")
    
    # Roda scanner de XSS básico
    os.system(f"cat {SLICE_FILE} | xss")

    # Roda Nuclei com seus templates privados nos caminhos encontrados
    nuclei_cmd = (
        f"nuclei -t /home/ferramentas/paths/privados/ "
        f"-l {SLICE_FILE} -c 100 -silent 2>/dev/null | notify -provider discord"
    )
    os.system(nuclei_cmd)

# -----------------------------
# Função: Atualizar Logs e Manter Unicidade
# -----------------------------
def append_to_logs(entries):
    with open(LOG_FILE, "a") as f:
        for e in entries: f.write(e + "\n")
    # Lê tudo, remove duplicatas e salva em ordem alfabética
    with open(LOG_FILE) as f:
        unique = sorted(set(x.strip() for x in f if x.strip()))
    with open(LOG_FILE, "w") as f:
        f.write("\n".join(unique) + "\n")

# -----------------------------
# Função Principal: Lógica de Notificação e Orquestração
# -----------------------------
def check_and_notify():
    if not os.path.exists(TEMP_FILE): return

    with open(TEMP_FILE) as f:
        found = set(x.strip() for x in f if x.strip())

    # Diferença entre o que foi achado e o que já temos (Novos Alvos)
    new = sorted(found - load_existing_logs())
    if not new:
        os.remove(TEMP_FILE)
        return

    print(f"[+] {len(new)} novos subdomínios encontrados")

    # Cria arquivo temporário apenas com os novos subdomínios detectados
    tech_file = "tech_temp.txt"
    with open(tech_file, "w") as f:
        f.write("\n".join(new))

    # Identifica tecnologias específicas (IIS 10 e PHP) e manda pro Discord
    os.system(f'httpx -l {tech_file} -t 100 -tech-detect | grep "IIS:10" | notify -provider discord')
    os.system(f'httpx -l {tech_file} -t 100 -tech-detect | grep "PHP" | egrep -v "Wordpress|Laravel|wordPress" | notify -provider discord')

    # RODADA 1: Checagem de portas escondidas em quem deu erro (Sua nova lógica)
    run_status_400_check(tech_file)
    
    # RODADA 2: Scan completo para alimentar o pipeline de vulnerabilidades
    run_httpx_on_entries(new)
    
    # RODADA 3: Katana, Slice, XSS e Nuclei
    run_security_pipeline()
    
    # Finaliza adicionando os novos domínios à base para não repetir no futuro
    append_to_logs(new)

    # Faxina: Remove todos os arquivos temporários da rodada
    for f in [TEMP_FILE, HTTPX_TEMP_FILE, SLICE_FILE, KATANA_FILE, ERRORS_400_FILE, tech_file]:
        if os.path.exists(f): os.remove(f)

# -----------------------------
# Loop Infinito de Execução
# -----------------------------
def main_loop():
    while True:
        run_gungnir_for_1_hour() # Coleta por 20min
        check_and_notify()       # Processa e ataca
        time.sleep(30)           # Pausa curta antes de reiniciar

if __name__ == "__main__":
    main_loop()