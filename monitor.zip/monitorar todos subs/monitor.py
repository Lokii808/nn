import subprocess
import os
import schedule
import time

MAX_EXECUTION_TIME = 20 * 60  # 20 minutos em segundos

def executar_gungnir():
    with open("temp.txt", "w") as temp_file:
        proc = subprocess.Popen(["gungnir", "-r", "xx.txt"], stdout=temp_file, stderr=subprocess.PIPE)
        try:
            proc.wait(timeout=MAX_EXECUTION_TIME)
        except subprocess.TimeoutExpired:
            print("gungnir demorou mais que 20 minutos, finalizando processo...")
            proc.kill()
            proc.wait()

def ler_arquivo(nome_arquivo):
    if os.path.exists(nome_arquivo):
        with open(nome_arquivo, "r") as f:
            return set(line.strip().lstrip("*.") for line in f if line.strip())
    return set()

def rodar_httpx(dominios):
    with open("finals.txt", "w") as f:
        for dominio in dominios:
            f.write(dominio + "\n")

    cmd = ["httpx", "-mc", "200", "-l", "finals.txt"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    dominios_validos = set(result.stdout.strip().splitlines())
    return dominios_validos

def rodar_katana():
    cmd = [
        "katana",
        "-list", "finals.txt",
        "-silent",
        "-jc",
        "-d", "2",
        "-ef", "jpg,png,gif,css,svg,woff,woff2,ttf,eot,js",
        "-c", "100",
        "-o", "kk.txt"
    ]
    subprocess.run(cmd)

def rodar_slicepathsurl():
    with open("kk.txt", "r") as entrada, open("slice.txt", "w") as saida:
        proc = subprocess.Popen(["slicepathsurl", "-l", "5"], stdin=entrada, stdout=saida)
        proc.wait()

def rodar_nuclei():
    cmd = [
        "nuclei",
        "-t", "/home/kali/ferramentas/paths/tag/paths/",
        "-l", "slice.txt"
    ]
    nuclei_proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    notify_proc = subprocess.Popen(
        ["notify", "-provider", "discord"],
        stdin=nuclei_proc.stdout
    )
    nuclei_proc.stdout.close()
    notify_proc.communicate()

def limpar_arquivos():
    arquivos = ["slice.txt", "kk.txt", "finals.txt", "temp.txt", "novos_temp.txt"]
    for arquivo in arquivos:
        if os.path.exists(arquivo):
            os.remove(arquivo)

def comparar_e_processar():
    todos_subs = ler_arquivo("todos_subs.txt")
    novos_subs = ler_arquivo("temp.txt")

    novos_subs = set(d.replace("*.", "") for d in novos_subs)
    dominios_novos = novos_subs - todos_subs

    if dominios_novos:
        print(f"{len(dominios_novos)} domínios novos encontrados. Rodando httpx...")

        with open("novos_temp.txt", "w") as f:
            for dominio in dominios_novos:
                f.write(dominio + "\n")

        # Notificação com todos os domínios novos que retornam 200
        cmd_200 = ["httpx", "-mc", "200", "-l", "novos_temp.txt"]
        proc_200 = subprocess.Popen(cmd_200, stdout=subprocess.PIPE)
        notify_proc = subprocess.Popen(
            ["notify", "-provider", "telegram", "-bulk", "-p", "big_monitoramento 200 ok"],
            stdin=proc_200.stdout
        )
        proc_200.stdout.close()
        notify_proc.communicate()

        # Pega apenas os que retornaram 200
        dominios_validos = rodar_httpx(dominios_novos)

        if dominios_validos:
            print(f"{len(dominios_validos)} domínios responderam com status 200. Rodando katana, slicepathsurl e nuclei...")
            rodar_katana()
            rodar_slicepathsurl()
            rodar_nuclei()

            # Agora sim, apenas os válidos são adicionados ao histórico
            with open("todos_subs.txt", "a") as f:
                for dominio in dominios_validos:
                    f.write(dominio + "\n")
        else:
            print("Nenhum domínio respondeu com os status definidos. Nenhuma ferramenta rodará.")

        limpar_arquivos()
    else:
        print("Nenhum domínio novo encontrado.")

def tarefa():
    executar_gungnir()
    comparar_e_processar()

# Executa imediatamente ao iniciar
tarefa()

# Agenda a tarefa para rodar a cada 20 minutos
schedule.every(20).minutes.do(tarefa)

# Loop infinito com verificação de tarefas agendadas
while True:
    schedule.run_pending()
    time.sleep(60)
