import os
import time

# Ler a lista de domínios do arquivo
with open("xx.txt", "r") as f:
    domain_list = f.read().splitlines()

# Criar um arquivo para armazenar todos os subdomínios encontrados
with open("todos_subs.txt", "w") as output_file:
    for domain_nome in domain_list:
        print(f"Enumerando subdomínios para: {domain_nome}")
        
        # Enumerando subdomínios com subfinder
        os.system(f"subfinder -all -d {domain_nome} >> temp_subs.txt")
        time.sleep(2)
        print("subfinder OK")
        
        # Enumerando subdomínios com crt.sh
        os.system(f"curl -s 'https://crt.sh/?q=%25.{domain_nome}&output=json' | jq -r '.[].name_value' | anew | sed 's/\\*\\.//g' >> temp_subs.txt")
        print("crt.sh OK")
        
        # Enumerando subdomínios com github-subdomains (substitua a chave pelo seu token)
        os.system(f"github-subdomains -d {domain_nome} -t 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 >> temp_subs.txt")
        time.sleep(2)
        print("github-subdomains OK")
        
        # Enumerando subdomínios com Anubis (jldc.me)
        os.system(f'curl -s "https://jldc.me/anubis/subdomains/{domain_nome}" | grep -Po "((http|https):\\/\\/)?(([\\w.-]*)\\.([\\w]*)\\.([A-z]))\\w+" | anew >> temp_subs.txt')
        time.sleep(2)
        print("Anubis OK")
        
        # Archive (Wayback Machine)
        os.system(f'curl -s "http://web.archive.org/cdx/search/cdx?url=*.{domain_nome}&output=text&fl=original&collapse=urlkey" | sed -e "s_https*://__" -e "s/\\?.*//" | sort -u >> temp_subs.txt')
        print("Archive OK")
        
        # JLDC (novamente)
        os.system(f'curl -s "https://jldc.me/anubis/subdomains/{domain_nome}" | grep -Po "((http|https):\\/\\/)?(([\\w.-]*)\\.([\\w]*)\\.([A-z]))\\w+" | sort -u >> temp_subs.txt')
        print("JLDC OK")
        
        # AlienVault OTX
        os.system(f"curl -s 'https://otx.alienvault.com/api/v1/indicators/domain/{domain_nome}/url_list?limit=100&page=1' | jq -r '.url_list[]?.hostname' | sort -u >> temp_subs.txt")
        print("AlienVault OK")
        
        # Subdomain Center
        os.system(f'curl -s "https://api.subdomain.center/?domain={domain_nome}" | jq -r ".[]" | sort -u >> temp_subs.txt')
        print("subdomain center OK")
        
        # Filtrar e adicionar ao arquivo final
        os.system("cat temp_subs.txt | anew | unfurl domain | sort -u >> todos_subs.txt")
        print(f"Subdomínios de {domain_nome} adicionados a todos_subs.txt")
        
        # Limpar arquivo temporário
        os.system("rm -f temp_subs.txt")

print("Processo concluído! Todos os subdomínios foram salvos em todos_subs.txt")
