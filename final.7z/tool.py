import re
import os
import argparse


def extrair_urls(arquivo, dominio):
    # Regex para capturar URLs contendo o domínio específico
    regex = re.compile(
        rf"""
        (?:
            https?://                                    # Protocolos HTTP ou HTTPS
            |                                           # OU
            ["']                                        # Strings delimitadas por aspas
        )
        (?:[^"'\s]+?{re.escape(dominio)}[^"'\s]*)       # Parte da URL contendo o domínio
        """,
        re.VERBOSE
    )

    urls_encontradas = set()

    with open(arquivo, 'r', encoding='utf-8', errors='ignore') as f:  # Ignorar erros de codificação
        for linha in f:
            matches = regex.findall(linha)
            if matches:
                urls_encontradas.update(matches)

    # Remover aspas iniciais das URLs
    urls_formatadas = {url.lstrip('"').lstrip("'") for url in urls_encontradas}
    return urls_formatadas


def processar_diretorio(diretorio, dominio):
    urls_totais = set()

    # Iterar pelos arquivos no diretório
    for arquivo in os.listdir(diretorio):
        caminho_arquivo = os.path.join(diretorio, arquivo)

        # Processar apenas arquivos
        if os.path.isfile(caminho_arquivo):
            print(f"Analisando arquivo: {caminho_arquivo}")
            urls = extrair_urls(caminho_arquivo, dominio)
            urls_totais.update(urls)

    return urls_totais


def main():
    parser = argparse.ArgumentParser(description="Ferramenta para extrair URLs de arquivos JS")
    parser.add_argument("-u", "--url", required=True, help="Domínio a ser buscado (ex: att.com)")
    parser.add_argument("entrada", help="Arquivo ou diretório contendo os scripts JS para análise")
    parser.add_argument("-o", "--output", required=False, default="urls_extraidas.txt", help="Caminho para o arquivo de saída")
    args = parser.parse_args()

    if os.path.isdir(args.entrada):
        # Se for um diretório, processar todos os arquivos dentro dele
        urls = processar_diretorio(args.entrada, args.url)
    elif os.path.isfile(args.entrada):
        # Se for um arquivo, processá-lo diretamente
        urls = extrair_urls(args.entrada, args.url)
    else:
        print("Erro: Caminho de entrada não é um arquivo nem um diretório válido.")
        return

    if urls:
        # Salvar URLs no arquivo de saída
        with open(args.output, 'a', encoding='utf-8') as f:
            for url in sorted(urls):
                f.write(f"{url}\n")

        print(f"URLs encontradas e salvas em '{args.output}':")
        for url in urls:
            print(url)
    else:
        print("Nenhuma URL encontrada com o domínio especificado.")


if __name__ == "__main__":
    main()
