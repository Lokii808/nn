import os
import time
import subprocess

# Configurações de Arquivos
XX_TXT = "xx.txt"
WORDLIST = "oks.txt"
RESOLVERS = "resolvers.txt"
SS_TXT = "ss.txt"
TODOS_SUBS = "todos_subs.txt"

# Lista de Portas Expandida
HTTPX_PORTS = (
    "80,443,8000,8080,8443,81,591,2082,2083,2086,2087,2095,2096,2480,3000,3333,"
    "4243,4567,4711,4712,4993,5000,5104,5108,5800,6543,7000,7396,7474,"
    "8001,8008,8042,8069,8081,8082,8088,8090,8091,8118,8123,8172,8222,"
    "8243,8280,8281,8333,8444,8500,8834,8880,8888,8983,9000,9043,9060,"
    "9080,9090,9091,9200,9443,9800,9981,12443,16080,18091,18092,20720"
)

def carregar_vistos():
    """Carrega o histórico de domínios já notificados."""
    if not os.path.exists(TODOS_SUBS):
        return set()
    with open(TODOS_SUBS, "r") as f:
        return set(linha.strip() for linha in f if linha.strip())

def salvar_visto(dominio_porta):
    """Adiciona um novo domínio:porta ao histórico."""
    with open(TODOS_SUBS, "a") as f:
        f.write(f"{dominio_porta}\n")

def enviar_notificacao(mensagem):
    """Envia o alerta para o Discord via notify."""
    processo = subprocess.Popen(["notify", "-provider", "discord"], stdin=subprocess.PIPE, text=True)
    processo.communicate(input=mensagem)

def rodar_fluxo():
    if not os.path.exists(XX_TXT):
        print(f"[!] Erro: {XX_TXT} não encontrado.")
        return

    while True:
        with open(XX_TXT, "r") as f:
            dominios_alvo = [linha.strip() for linha in f if linha.strip()]

        for alvo in dominios_alvo:
            print(f"\n[*] Iniciando Brute Force: {alvo}")
            
            # 1. Puredns Brute Force
            cmd_puredns = f"puredns bruteforce {WORDLIST} {alvo} -r {RESOLVERS} --skip-wildcard-filter > {SS_TXT}"
            os.system(cmd_puredns)

            if not os.path.exists(SS_TXT) or os.stat(SS_TXT).st_size == 0:
                print(f"[-] Nenhum subdomínio encontrado para {alvo}.")
                if os.path.exists(SS_TXT): os.remove(SS_TXT)
                continue

            # 2. Httpx (Filtrando apenas Status 200)
            print(f"[*] Validando portas vivas (Status 200) para {alvo}...")
            cmd_httpx = f"httpx -l {SS_TXT} -ports {HTTPX_PORTS} -mc 200 -silent"
            resultado = subprocess.check_output(cmd_httpx, shell=True, text=True)
            
            vistos = carregar_vistos()
            achados_nesta_rodada = resultado.strip().splitlines()

            for item in achados_nesta_rodada:
                # Limpa a URL para o formato dominio:porta ou apenas dominio
                url_limpa = item.replace("http://", "").replace("https://", "")
                
                # 3. Comparação com Histórico
                if url_limpa not in vistos:
                    print(f"[+] NOVO: {url_limpa}")
                    # 4. Notificação e Registro
                    msg = f"{url_limpa} | bruter dominio novo"
                    enviar_notificacao(msg)
                    salvar_visto(url_limpa)
                    vistos.add(url_limpa) # Atualiza o set local para evitar duplicatas na mesma rodada

            # 5. Limpeza de arquivo temporário
            if os.path.exists(SS_TXT):
                os.remove(SS_TXT)
            
            print(f"[*] Finalizado: {alvo}. Aguardando 10s para o próximo...")
            time.sleep(10)

        print("\n[!] Ciclo completo finalizado. Reiniciando em 30 segundos...")
        time.sleep(30)

if __name__ == "__main__":
    try:
        rodar_fluxo()
    except KeyboardInterrupt:
        print("\n[!] Script parado pelo usuário.")