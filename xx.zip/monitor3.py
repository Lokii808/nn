#!/usr/bin/env python3
import os
import time
import subprocess
import signal
import datetime
import sys

# -----------------------------
# Configurações do script
# -----------------------------
TEMP_FILE = "temp.txt"             # Arquivo temporário que guarda a saída do gungnir
LOG_FILE = "todos_subs.txt"        # Sua base de dados principal de subdomínios conhecidos
ROOTS_FILE = "xx.txt"              # Lista de domínios raiz que o gungnir vai processar
HTTPX_OUTPUT_FILE = "httpx.txt"    # Arquivo ONDE ERA SALVO o output do httpx
GUNGNIR_TIMEOUT = 20 * 60          # Tempo máximo de execução do gungnir (20 minutos)

# ARQUIVOS TEMPORÁRIOS DO PIPELINE DE SEGURANÇA
HTTPX_TEMP_FILE = "httpx_temp.txt" # Novo arquivo para salvar o output do httpx antes do Katana
SLICE_FILE = "slice1.txt"          # Arquivo temporário para output do slicepathsurl
KATANA_FILE = "katana.txt"         # Arquivo temporário para output do Katana

# Lista de portas (string) e códigos de resposta para passar ao httpx
HTTPX_PORTS = (
    "80,443,8000,8080,8443,81,591,2082,2083,2086,2087,2095,2096,2480,3000,3333,"
    "4243,4567,4711,4712,4993,5000,5104,5108,5800,6543,7000,7396,7474,"
    "8001,8008,8042,8069,8081,8082,8088,8090,8091,8118,8123,8172,8222,"
    "8243,8280,8281,8333,8444,8500,8834,8880,8888,8983,9000,9043,9060,"
    "9080,9090,9091,9200,9443,9800,9981,12443,16080,18091,18092,20720"
)
HTTPX_CODES = "200,307,404"  # códigos a filtrar (--mc)
HTTPX_TIMEOUT = 120  # Timeout para cada execução do httpx (em segundos)

# -----------------------------
# Função para rodar o gungnir 
# -----------------------------
def run_gungnir_for_1_hour():
    print(f"[*] Iniciando gungnir por 1 hora... ({datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')})")
    pattern = rf"gungnir -r {ROOTS_FILE} | egrep -v 'mini.sk'"

    with open(TEMP_FILE, "w") as outfile:
        process = subprocess.Popen(
            pattern,
            shell=True,
            stdout=outfile,
            stderr=subprocess.DEVNULL,
            preexec_fn=os.setsid
        )

        try:
            process.wait(timeout=GUNGNIR_TIMEOUT)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                print("[*] Tempo esgotado: gungnir finalizado (SIGTERM).")
            except Exception as e:
                print(f"[!] Erro ao terminar processo por timeout: {e}")
        except KeyboardInterrupt:
            print("\n[!] Interrompido pelo usuário. Finalizando gungnir...")
            try:
                os.killpg(os.getpgid(process.pid), signal.SIGTERM)
            except Exception:
                pass
            sys.exit(0)
        except Exception as e:
            print(f"[!] Erro inesperado ao executar gungnir: {e}")

# -----------------------------
# Funções utilitárias de logs/notificações
# -----------------------------
def load_existing_logs():
    if not os.path.exists(LOG_FILE):
        return set()
    with open(LOG_FILE, "r") as f:
        return set(line.strip() for line in f if line.strip())

def notify_message_discord(message):
    if not message:
        return
    try:
        proc = subprocess.Popen(["notify", "-provider", "discord"], stdin=subprocess.PIPE, text=True)
        proc.communicate(input=message, timeout=30)
    except Exception as e:
        print(f"[!] Falha ao executar notify (Discord): {e}")

# -----------------------------
# Função para rodar httpx nos novos alvos (COM -t 100)
# -----------------------------
def run_httpx_on_entries(entries):
    if not entries:
        return ""

    cmd = ["httpx", "-p", HTTPX_PORTS, "--mc", HTTPX_CODES, "-silent", "-t", "100"] 
    out = ""

    try:
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )
        input_data = "\n".join(entries) + "\n"
        out, _ = proc.communicate(input=input_data, timeout=HTTPX_TIMEOUT)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
        except Exception:
            pass
        print("[!] httpx excedeu o tempo limite e foi encerrado.")
    except FileNotFoundError:
        print("[!] httpx não encontrado no PATH.")
    except Exception as e:
        print(f"[!] Erro executando httpx: {e}")

    if out is None:
        out = ""

    if out.strip():
        try:
            with open(HTTPX_TEMP_FILE, "w") as f: 
                f.write(out)
        except Exception as e:
            print(f"[!] Erro ao escrever {HTTPX_TEMP_FILE}: {e}")

    try:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(HTTPX_OUTPUT_FILE, "a") as f:
            f.write(f"--- httpx run at {timestamp} for {len(entries)} targets ---\n")
            if out.strip():
                f.write(out)
            else:
                f.write("(no httpx output)\n")
            f.write("\n")
    except Exception as e:
        print(f"[!] Erro ao escrever {HTTPX_OUTPUT_FILE}: {e}")

    return out

# -----------------------------
# Pipeline de segurança
# -----------------------------
def run_security_pipeline():
    if not os.path.exists(HTTPX_TEMP_FILE) or os.path.getsize(HTTPX_TEMP_FILE) == 0:
        print("[-] Nenhum output válido do httpx para iniciar o pipeline de segurança.")
        return

    print("[*] Iniciando pipeline de segurança (Katana, slicepathsurl, xss, Nuclei)...")

    katana_cmd = f"katana -list {HTTPX_TEMP_FILE} -c 5 -d 2 -retry 1 -timeout 5 -ef js,jpg,jpeg,gif,css,tif,tiff,png,ttf,woff,woff2,ico,pdf,svg,txt > {KATANA_FILE}"
    print(f"    - Rodando Katana...")
    os.system(katana_cmd)
    
    slice_cmd = f"cat {KATANA_FILE} | slicepathsurl -l 5 > {SLICE_FILE}"
    print(f"    - Rodando slicepathsurl...")
    os.system(slice_cmd)

    xss_cmd = f"cat {SLICE_FILE} | xss"
    print(f"    - Rodando xss em paths filtrados...")
    os.system(xss_cmd) 

    nuclei_cmd = f"nuclei -t /home/kali/ferramentas/paths/privados/ -l {SLICE_FILE} -c 100 | notify -provider discord"
    print(f"    - Rodando Nuclei com templates privados e notificando Discord.")
    os.system(nuclei_cmd)
    
    print("[*] Pipeline de segurança concluído.")

# -----------------------------
# Função para adicionar logs
# -----------------------------
def append_to_logs(new_entries):
    if not new_entries:
        return

    try:
        with open(LOG_FILE, "a") as f:
            for entry in new_entries:
                f.write(entry.strip() + "\n")
    except Exception as e:
        print(f"[!] Erro ao dar append em {LOG_FILE}: {e}")
        return

    try:
        with open(LOG_FILE, "r") as f:
            lines = set(line.strip() for line in f if line.strip())
        with open(LOG_FILE, "w") as f:
            for line in sorted(lines):
                f.write(line + "\n")
    except Exception as e:
        print(f"[!] Erro ao deduplicar {LOG_FILE}: {e}")

# -----------------------------
# Função principal de verificação
# -----------------------------
def check_and_notify():
    if not os.path.exists(TEMP_FILE) or os.path.getsize(TEMP_FILE) == 0:
        print("[-] Nenhum resultado encontrado pelo gungnir.")
        if os.path.exists(TEMP_FILE):
            os.remove(TEMP_FILE)
        return

    with open(TEMP_FILE, "r") as f:
        raw_lines = [line.strip() for line in f if line.strip()]

    temp_set = set(raw_lines)
    existing_logs = load_existing_logs()
    unique_new_entries = sorted(list(temp_set - existing_logs))

    if not unique_new_entries:
        print("[-] Nenhuma nova entrada encontrada (tudo já estava em todos_subs.txt).")
        try:
            os.remove(TEMP_FILE)
        except Exception:
            pass
        return

    print(f"[*] Encontradas {len(unique_new_entries)} entradas novas. Rodando httpx nelas...")

    # -------------------------------------------------------------
    # 🔥 ADIÇÃO: HTTPX para detectar IIS e PHP ANTES do httpx principal
    # -------------------------------------------------------------
    TECH_FILE = "tech_temp.txt"

    with open(TECH_FILE, "w") as f:
        for entry in unique_new_entries:
            f.write(entry + "\n")

    print("[*] Rodando detecção de tecnologia (IIS e PHP)...")

    os.system(f'httpx -l {TECH_FILE} -t 100 -tech-detect | grep "IIS:10" | notify -provider discord')
    os.system(f'httpx -l {TECH_FILE} -t 100 -tech-detect | grep "PHP" | notify -provider discord')

    try:
        os.remove(TECH_FILE)
    except:
        pass
    # -------------------------------------------------------------

    # 1. Roda httpx principal
    httpx_output = run_httpx_on_entries(unique_new_entries)

    # 2. Notificação IMEDIATA do Discord com os achados do httpx
    if httpx_output and httpx_output.strip():
        notify_message_discord(f"[Novos Alvos HTTP/S]\n{httpx_output}")

    # 3. RODA O PIPELINE DE SEGURANÇA NOS RESULTADOS DO HTTPX
    run_security_pipeline()
    
    # 4. Adiciona AS ENTRADAS NOVAS à base de dados principal (todos_subs.txt)
    append_to_logs(unique_new_entries)
    print(f"[*] {len(unique_new_entries)} entradas adicionadas a {LOG_FILE} (apêndice + dedup).")

    # 5. LIMPEZA DOS ARQUIVOS TEMPORÁRIOS DO CICLO
    print("[*] Limpando arquivos temporários do ciclo...")
    for f in [TEMP_FILE, HTTPX_TEMP_FILE, SLICE_FILE, KATANA_FILE, HTTPX_OUTPUT_FILE]:
        if os.path.exists(f):
            try:
                os.remove(f)
            except Exception as e:
                print(f"[!] Erro ao remover {f}: {e}")

# -----------------------------
# Loop principal 
# -----------------------------
def main_loop():
    try:
        while True:
            run_gungnir_for_1_hour()
            print("[*] Verificando e notificando entradas novas...")
            check_and_notify()
            print("[*] Aguardando 30 segundos antes da próxima execução...\n")
            time.sleep(30)
    except KeyboardInterrupt:
        print("\n[!] Interrompido pelo usuário. Saindo...")
        sys.exit(0)

# -----------------------------
# Ponto de entrada
# -----------------------------
if __name__ == "__main__":
    main_loop()
