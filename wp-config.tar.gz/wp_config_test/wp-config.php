<?php
/** Example wp-config.php for local testing only.
 *  THIS FILE USES PLACEHOLDERS — do NOT use in production.
 */

/** MySQL settings - placeholders for local testing */
define( 'DB_NAME', 'example_db' );
define( 'DB_USER', 'example_user' );
define( 'DB_PASSWORD', 'example_password' );
define( 'DB_HOST', 'localhost' );
define( 'DB_CHARSET', 'utf8' );
define( 'DB_COLLATE', '' );

/**#@+\n * Authentication Unique Keys and Salts.\n * These are randomly generated for this test file.\n * Replace with secure values for real installations.\n */\ndefine('AUTH_KEY',         'deQiiC1(j2fHF%DcMKm$0~>u-U59$bl0G#g<pR<G4bwy6Kk[4gOle{^zs@4}Er4!');
define('SECURE_AUTH_KEY',  'ZCrA}-LgYhsn2b}f#1c_%rqFQ^6iKujEbZG~H5NTlw[9siaSpq9qV$1ulin)xyZA');
define('LOGGED_IN_KEY',    'wyaU!%r<6&bzRD2C&PweP(~r0nmPJA]N)*dOImBo*vHv{jXB4_zYDJuo$2hatA*[');
define('NONCE_KEY',        'klmg<jDT~4Jw_pt^s2#nKfAy9uikXYu^$Hc1XRUTR7GhV~WGjp&Kzkypp}IYGL{0');
define('AUTH_SALT',        '0f9~}IfB5Zw2cu}EGRiH1eAxbl$msduL[<QyAOWSLzX(Rr]tp8TNv9qBg%~I9G2z');
define('SECURE_AUTH_SALT', ')kd$Ct%S$)!BUYY^6Xw8Q#i@-&P9&uuhY3>DM)1Z5sNY4UQ@0gx)ZPp-~mE1}^LQ');
define('LOGGED_IN_SALT',   'yDTQc*pguokibe-ntwJ]_eO&dsd@TDJ[1}n^s-(DKXC[-znt%Ngc7uFZW(5k38im');
define('NONCE_SALT',       'cQyU~vbeT)opl$[&@]TMGjo2C2JFBxj(iy00^WKn0fj)!LNF1vxH{6Nwu^>Odc0!');
/**#@-*/\n\n/** Table prefix */\n$table_prefix = 'wp_test_';\n\n/** Debug mode */\ndefine( 'WP_DEBUG', true );\n\n/* Absolute path to the WordPress directory. (optional for local test) */\nif ( ! defined( 'ABSPATH' ) ) {\n    define( 'ABSPATH', __DIR__ . '/' );\n}\n\n/* That's all, stop editing! Happy testing. */\n