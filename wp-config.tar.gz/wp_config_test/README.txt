Este arquivo é um exemplo para TESTE LOCAL apenas.
Contém placeholders e salts aleatórias. NÃO usar em produção.
