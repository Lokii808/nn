---
name: artifact-source-analysis
description: Descoberta e análise de artefatos descompiláveis/reconstruíveis (source maps, símbolos de debug, assemblies .NET, bytecode Java, binários mobile/nativos, WebAssembly) expostos por um alvo autorizado de bug bounty/pentest. Use sempre que estiver analisando HTML, JavaScript, CSS, JSON, respostas de API, headers HTTP, histórico de tráfego, resultados de crawling/recon ou qualquer conteúdo textual relacionado ao alvo autorizado — mesmo que nenhuma URL de artefato tenha sido encontrada diretamente pelo crawler. Não depende de o artefato estar linkado explicitamente; procura referências contextuais e constrói cadeias de descoberta recursiva (ex.: HTML → JS → source map → source → referência a DLL). Só deve ser usada dentro do escopo formalmente autorizado do engajamento.
---

# Artifact Source Analysis

Skill para transformar qualquer referência encontrada durante recon em uma possível cadeia de descoberta de código-fonte e lógica interna de um alvo **autorizado** (bug bounty / pentest com escopo definido). Cobre a detecção de artefatos descompiláveis/reconstruíveis e a análise recursiva deles.

**Pré-condição obrigatória**: só use esta skill dentro do escopo formalmente autorizado (programa de bug bounty, contrato de pentest, etc.). Antes de baixar ou analisar qualquer artefato, confirme que o domínio/host está no escopo. Nunca baixe, extraia ou distribua artefatos que contenham segredos de terceiros fora do escopo do teste (ex.: chaves privadas, credenciais de produção) — reporte a existência do artefato e o achado, sem republicar segredos sensíveis no relatório.

## Quando usar

Use esta skill sempre que estiver analisando qualquer conteúdo relacionado ao alvo autorizado — não apenas quando o crawler já tiver listado uma URL de artefato. A detecção deve acontecer de forma contínua, em paralelo a qualquer outra tarefa de recon.

## Fontes de detecção

Procure referências a artefatos em todos os contextos disponíveis:

- HTML / código-fonte HTML
- JavaScript inline e arquivos JS externos
- CSS (quando houver referências relevantes, ex. `url()` apontando para builds)
- JSON e respostas de API
- Headers HTTP (ex. `Location`, `X-SourceMap`, headers customizados)
- Histórico de tráfego (requests/responses capturados)
- URLs descobertas pelo crawler
- URLs encontradas em JavaScript e em source maps
- Endpoints encontrados em arquivos JS
- Parâmetros de requisições
- Redirects
- Páginas de erro (404/500 e afins)
- Arquivos carregados pelo navegador (network log)
- Manifests (web app manifest, manifestos de build)
- Service workers e Web Workers
- Recursos de preload/prefetch
- Scripts gerados dinamicamente
- Configurações expostas no frontend
- Documentação exposta publicamente
- Arquivos descobertos via links
- Resultados de crawling e de recon já existentes
- Qualquer outro conteúdo textual em análise

## Detecção contextual

Não dependa de um link explícito. Procure referências mesmo quando o artefato aparece apenas como string, comentário, valor de configuração ou parte de uma URL construída dinamicamente.

Exemplos de padrões a reconhecer:

```
HTML:       <script src="/static/app.js"></script>
JS:         sourceMappingURL=/static/app.js.map
JS:         fetch("/download/app.dll")
JS:         const debugFile = "/symbols/app.pdb"
JSON:       {"binary":"/build/application.dll"}
HTML:       <a href="/debug/app.pdb">
Header:     Location: /build/application.jar
Histórico:  GET /static/app.js.map
```

Também procure nomes de arquivo e caminhos concatenados ou construídos em tempo de execução:

```
const x = "app" + "lication.dll"
fetch(base + "/build/" + file)
/download?id=app.dll
/file?name=app.pdb
/asset?file=main.js.map
```

Não dependa de a extensão estar no final da URL — ela pode estar em um parâmetro (`?name=`, `?file=`, `?id=`).

## Extensões e artefatos suportados

Ao analisar JS/HTML/JSON/tráfego, procure referências a:

`.map` `.dll` `.exe` `.pdb` `.jar` `.war` `.class` `.apk` `.aab` `.ipa` `.so` `.dylib` `.wasm` `.bc` `.elf` `.dSYM`

Junto com: URLs absolutas/relativas, imports estáticos e dynamic imports, chamadas `fetch()`/`XMLHttpRequest`/WebSocket, service workers, loaders, manifests, configuração de build, caminhos de desenvolvimento (paths locais vazados), referências a source code e a símbolos/debug info.

## Prioridade de análise

1. Source maps
2. Debug symbols
3. Assemblies .NET
4. Bytecode Java
5. Binários mobile (APK/AAB/IPA)
6. Binários nativos (ELF, dylib, so, exe)
7. WebAssembly
8. Outros artefatos suportados

## Fluxo: crawl → análise → descoberta recursiva

Ao encontrar uma referência interessante:

1. Identifique o artefato (tipo, caminho, contexto onde apareceu).
2. Resolva a URL relativa para absoluta.
3. Verifique se o host está dentro do escopo autorizado.
4. Baixe o artefato.
5. Analise/descompile/reconstrua (conforme o tipo — ver seção de ferramentas por tipo, se disponível no ambiente).
6. Extraia novos caminhos, URLs, nomes de arquivo e referências de dentro do artefato.
7. Adicione os novos recursos encontrados à fila de análise.
8. Continue recursivamente, respeitando os limites descritos abaixo.

Exemplo de cadeia:

```
index.html → app.js → app.js.map → source original → BackendClient.cs
           → referência a /api/internal/... → referência a Backend.dll
           → Backend.dll → controllers/endpoints/configuração
```

## JavaScript como fonte primária de descoberta

Trate todo JavaScript analisado (inline ou externo) como fonte primária de descoberta, não apenas como código a ser lido por outro motivo. Ao passar por qualquer arquivo JS durante o recon, rode a varredura de padrões de artefato descrita acima antes de seguir para a próxima tarefa.

## Histórico de tráfego

Quando houver acesso ao histórico de tráfego (proxy, HAR, etc.), não analise apenas a URL de cada entrada. Analise também:

- request URL e request body
- response body e response headers
- redirects
- HTML/JS/JSON retornados

Se um artefato aparecer **somente** no histórico (não estando mais linkado pela aplicação atual), ainda assim registre-o e, se estiver acessível e dentro do escopo, analise-o.

## Descoberta indireta

Procure padrões como `*.dll`, `*.pdb`, `*.jar`, `*.map` dentro de strings soltas, comentários, código ofuscado parcialmente recuperável, mensagens de erro e arquivos de configuração — mesmo sem um link ou request associado a eles ainda.

## Regra fundamental

Nunca assuma que um artefato estará diretamente exposto em um caminho óbvio (`https://target.com/app.dll`). Ele costuma estar escondido em cadeias como:

- HTML → JS → source map → source → referência a DLL
- Histórico HTTP → JS → endpoint → arquivo
- Crawler → bundle → configuração → artefato

Sempre que uma referência a um artefato suportado for encontrada em qualquer contexto, adicione-a à fila de análise e siga a cadeia de forma controlada.

## Limites e deduplicação

Para evitar loops, downloads excessivos e retrabalho:

- Normalize URLs antes de comparar (remover parâmetros voláteis quando fizer sentido, resolver `.`/`..`, lowercase de host).
- Deduplique por hash do conteúdo baixado e por URL normalizada — não reanalise o mesmo artefato duas vezes.
- Defina um limite de profundidade de recursão (ex.: número máximo de "saltos" artefato → referência → novo artefato) e um limite de artefatos totais por execução, ajustáveis pelo usuário.
- Ao atingir os limites, pare e reporte o que ainda está na fila em vez de continuar indefinidamente.
- Respeite rate limiting do alvo entre downloads.

## Saída esperada

Para cada artefato encontrado, registre: tipo, caminho/URL de origem, onde a referência foi encontrada (arquivo + trecho), se foi baixado e analisado, e quais novos caminhos/artefatos ele revelou. Isso permite reconstruir a cadeia completa de descoberta no relatório final.
