---
name: path-normalization-traversal
description: Metodologia de path normalization / path traversal em proxys reversos (nginx, Tomcat, gateways internos) e em arquiteturas BFF (Backend for Frontend) para bug bounty. Use sempre que o usuÃ¡rio mencionar "path traversal", "path normalization", "..;/", "%2e%2e", "bff/proxy", proxy reverso caindo em rota interna, travessia dentro de um parÃ¢metro de ID/recurso de uma API, descoberta de aplicaÃ§Ã£o escondida atrÃ¡s de gateway, ou pedir para analisar um host/subdomÃ­nio/endpoint em busca de discrepÃ¢ncia de roteamento entre proxy e backend. O fluxo parte de uma lista de hosts/paths fornecida pelo usuÃ¡rio (output de crawler / trÃ¡fego capturado, com ou sem paths, ou uma PASTA de arquivos .txt â€” um por host â€” cada um com URLs e regras de filtro prÃ³prias). Ã‰ uma skill de DETECÃ‡ÃƒO: nenhum fuzzing/brute-force â€” tudo Ã© testado com requests diretos, um a um. Cobre: como identificar o baseline de erro, diferenciaÃ§Ã£o de erros (o sinal pode ser sÃ³ uma pÃ¡gina de erro diferente â€” Tomcat, JSP, gateway), sequÃªncias de bypass a testar (no prefixo da rota, sem barra antes da sequÃªncia, e dentro de parÃ¢metros), bypass de WAF intercalando separadores, mapeamento atÃ© a raiz do sistema interno via respostas 400/301, como confirmar travessia real comparando em todos os contextos (baseline, raiz direta, path direto), teste manual direto pÃ³s-travessia (arquivos sensÃ­veis, links da pÃ¡gina, rotas de JS â€” regra obrigatÃ³ria 3.1.1: em alvo nginx os 4 arquivos sensÃ­veis padrÃ£o .git/config, .env, README.md, settings.py sÃ£o testados sÃ³ sem barra; em Tomcat/JBoss/Java continuam testados com e sem barra), coleta de JS/rotas internas e de trÃ¡fego capturado (com ou sem token), chain de CVEs em tecnologia exposta (Tomcat/JBoss/Axis2), troca de ambiente stg/prod, e como reportar achados em 3 nÃ­veis. Fluxo-padrÃ£o PRIORIZADO (seÃ§Ã£o 0): rodada completa sobre a(s) URL(s) fornecida(s) pelo usuÃ¡rio â€” arquivo, pasta de .txt, OU simplesmente 1+ URLs coladas direto na conversa (o nome/formato nÃ£o importa) â€” ler e testar todas atÃ© o fim, dedup, agrupar por host completo, mÃ¡x. 5 paths por host individualmente (apenas os PRIMEIROS 5, em ordem â€” se vier 10 ou mais, sÃ³ os 5 primeiros), nÃ£o deixar nenhum host/URL elegÃ­vel sem processar, ignorar estÃ¡ticos E paths com extensÃ£o de arquivo (.php, .html, etc.); travessia testada APENAS no path em si (com/sem barra antes da sequÃªncia, regra 3.1) â€” NUNCA em segundo path, segundo nÃ­vel, prefixo intermediÃ¡rio ou primeiro segmento, seguido SEMPRE e automaticamente (mesmo com 1 ou 2 URLs avulsas, sem precisar o usuÃ¡rio pedir de novo) do segundo estÃ¡gio obrigatÃ³rio com apenas 3 paths padrÃ£o na raiz de cada host (/api, /v2, /static, com e sem trailing slash); testar_manual.txt salva sinais sÃ³ dos 2 PRIMEIROS paths de cada host; saÃ­das exatas poc.txt (sÃ³ confirmadas, zero falso positivo) / testar_manual.txt (sÃ³ sinais relevantes, mÃ¡x. 2 paths por host) / relatorio.txt (CONFIRMADO / INCONCLUSIVO-MANUAL / SEM EVIDÃŠNCIA) + checklist final.
---

# Path Normalization / Path Traversal em Proxys Reversos

Metodologia para encontrar discrepÃ¢ncias de normalizaÃ§Ã£o de path entre um proxy
reverso (nginx, gateway interno, API gateway) e o backend real (Tomcat, JBoss,
aplicaÃ§Ã£o Java, etc.), que podem expor aplicaÃ§Ãµes internas, painÃ©is
administrativos, arquivos sensÃ­veis (`.git/config`, `.env`, `README.md`,
`settings.py` â€” em nginx, sempre testados sem barra, ver seÃ§Ã£o 3.1.1) ou
rotas de API que nÃ£o deveriam ser alcanÃ§Ã¡veis publicamente.

**Regra de ouro:** o objetivo Ã© sempre confirmar leitura/acesso â€” nunca testar
PoCs destrutivas ou que alterem dados da aplicaÃ§Ã£o. Trabalhar sempre dentro do
escopo autorizado do programa de bug bounty / teste.

**Sobre os placeholders usados nesta skill:** em todo comando de exemplo
(`curl` etc.), termos como `alvo.com`, `/base/`, `<SEQ_CONFIRMADA>`,
`:param` sÃ£o placeholders ilustrativos, nÃ£o valores literais. Quem estiver
executando esta metodologia Ã© responsÃ¡vel por manter controle de duas
variÃ¡veis durante todo o processo â€” **o path base atual** (fornecido pela
lista do usuÃ¡rio â€” host com path, ou raiz seguida de redirect â€” ou revelado
por JS/trÃ¡fego capturado, seÃ§Ãµes 2 e 6) e **a sequÃªncia de bypass
confirmada** naquele path (seÃ§Ã£o 3/4) â€” e substituir os placeholders por
esses valores reais antes de rodar qualquer comando. Nunca rode um comando
com `/base/` ou `<SEQ_CONFIRMADA>` literal; sempre com o path e a sequÃªncia
que vocÃª mesmo acabou de confirmar naquela etapa do processo.

## 0. Workflow padrÃ£o do usuÃ¡rio â€” rodada completa sobre URL(s) fornecida(s) (PRIORIZADO)

**Este Ã© o fluxo-padrÃ£o sempre que o pedido envolver rodar a skill sobre
uma ou mais URLs/paths â€” nÃ£o importa a forma como eles chegam.** Vale
igualmente para: um arquivo `.txt` Ãºnico, uma pasta com vÃ¡rios `.txt`
(um por host), output de crawler, **ou simplesmente uma ou mais URLs
coladas direto na conversa** (ex.: o usuÃ¡rio manda sÃ³ `site.com/portal`,
ou `site.com/app` e `site.com/portal` em duas linhas). NÃ£o existe forma de
entrada "especial" e nenhuma tem prioridade sobre as outras â€” a regra
abaixo vale igual para todas, seja 1 URL avulsa ou um arquivo com 90 linhas.
Ã‰ o procedimento mais usado
e tem prioridade sobre o restante da skill sempre que houver conflito de
etapas de execuÃ§Ã£o. NÃ£o Ã© um fluxo alternativo â€” Ã© O fluxo, na ordem abaixo,
sem pular etapas, **e as duas etapas (0.2 e 0.3) sÃ£o sempre executadas em
sequÃªncia, nessa ordem, para qualquer quantidade de paths recebidos â€” 1, 2
ou 90.**

**Regra de seguranÃ§a (nÃ£o negociÃ¡vel):** executar apenas sobre alvos
explicitamente autorizados (escopo do programa de bug bounty / teste).
Requests GET, somente leitura; nada destrutivo; nenhum acesso a dado real
alÃ©m do necessÃ¡rio para confirmar a vulnerabilidade.

### 0.1 PreparaÃ§Ã£o da lista

1. **Ler TODAS as URLs da lista fornecida e rodar ATÃ‰ O FIM dela** â€” a
   cobertura vai da primeira Ã   Ãºltima URL, sem pular nenhuma. A rodada sÃ³
   termina quando a lista inteira foi processada; nenhuma URL fica de fora
   (o nome do arquivo nÃ£o importa â€” vale para qualquer lista que o usuÃ¡rio
   passar).
2. **Remover duplicadas** (dedup) preservando a ordem de apariÃ§Ã£o no arquivo.
3. **Agrupar por host COMPLETO** â€” cada domÃ­nio/subdomÃ­nio Ã© um host
   independente (`site.com` Ã¢â€°  `www.site.com` Ã¢â€°  `api.site.com`); paths de
   hosts diferentes nunca sÃ£o misturados num mesmo alvo.
4. **MÃ¡ximo de 5 paths distintos por host, individualmente** â€” o cap de 5
   aplica-se a CADA host, um a um (os primeiros 5 paths vÃ¡lidos daquele host
   apÃ³s o dedup, em ordem do arquivo). Host com 3 paths recebe 3; host com 12
   recebe 5. O cap nunca Ã© compartilhado entre hosts.
5. **NÃ£o deixar nenhum host/URL elegÃ­vel sem processar** â€” todo host com pelo
   menos 1 path vÃ¡lido entra na rodada; nenhuma URL elegÃ­vel fica de fora
   (por exemplo por ter sido atribuÃ­da ao host errado). Ao final, conferir:
   todas as URLs lidas do arquivo pertencem a algum host processado? Se sim,
   cobertura 100%.
6. **Ignorar recursos estÃ¡ticos e paths com extensÃ£o de arquivo** (nÃ£o entram
   na rodada e nÃ£o contam para o cap de 5): extensÃµes de arquivo â€” `.git`,
   `.svn`, `.sb`, `.png`, `.jpg`, `.jpeg`, `.gif`, `.svg`, `.css`, `.js`,
   `.ico`, fontes (`.woff`, `.woff2`, `.ttf`, `.eot`, `.otf`), vÃ­deos/Ã¡udios
   (`.mp4`, `.webm`, `.mp3`, `.mov`) â€” **e qualquer path que termine em
   extensÃ£o de pÃ¡gina/arquivo**: `.php`, `.phtml`, `.html`, `.htm`, `.aspx`,
   `.asp`, `.jsp`, `.jspx`, `.cfm`, `.cgi`, `.shtml`, etc. Path com
   `.php`/`.html`/extensÃ£o NÃƒO Ã© testado.

### 0.2 Primeiro estÃ¡gio â€” paths do arquivo (APENAS o path em si, nos 5 primeiros)

Testar APENAS os **5 primeiros paths vÃ¡lidos** de cada host (em ordem do
arquivo; host com menos paths recebe o que tiver â€” o cap nunca Ã©
compartilhado entre hosts). Se o host tiver 10 ou mais paths, sÃ³ os 5
primeiros entram; o resto NÃƒO Ã© testado.

A travessia Ã© testada **somente no path em si** â€” a sequÃªncia Ã© colada no
fim do prÃ³prio path da lista (com e sem barra antes da sequÃªncia, regra
3.1), comeÃ§ando pelo `../` puro sem encoding (seÃ§Ã£o 3.1.2), depois `..;/`,
`..%2f`, `..%5C` repetidas e as variantes extras da seÃ§Ã£o 3 (`..%252f`,
`%2e%2e%2f`, `%5c../`, `%5c..;/`).
NÃƒO se testa em segundo path, segundo nÃ­vel, prefixo intermediÃ¡rio,
primeiro segmento nem em path de redirect extra â€” o path da lista Ã‰ o
Ãºnico lugar de teste.

**Assim que o(s) path(s) recebido(s) terminar(em) de ser testado(s) â€” mesmo
que seja sÃ³ 1 ou 2 paths avulsos colados na conversa, sem ser arquivo â€”
o prÃ³ximo passo Ã‰ SEMPRE a seÃ§Ã£o 0.3, automaticamente, sem precisar o
usuÃ¡rio pedir de novo.** Ou seja: `site.com/app` e `site.com/portal`
recebidos direto no chat, depois de esgotadas as sequÃªncias de bypass
neles (0.2), viram obrigatoriamente tambÃ©m:

```
site.com/api    site.com/api/
site.com/v2     site.com/v2/
site.com/static site.com/static/
```

â€” e cada um desses seis Ã© testado com as mesmas sequÃªncias da seÃ§Ã£o 3
(0 e 1 barra, 1 e 2 travessias), com baseline e controle pareado prÃ³prios
(seÃ§Ã£o 0.3 abaixo). Essa transiÃ§Ã£o 0.2 â†’ 0.3 nunca Ã© pulada, nÃ£o importa
o tamanho da entrada.

### 0.3 Segundo estÃ¡gio â€” paths padrÃ£o na RAIZ do host (obrigatÃ³rio)

Depois de esgotar os paths recebidos (seÃ§Ã£o 0.2 â€” seja de arquivo ou
colados direto na conversa), testar tambÃ©m os **3 paths
padrÃ£o abaixo na RAIZ de cada host**, com **trailing slash e sem trailing
slash** (`site.com/api/` E `site.com/api`):

```
/api  /v2  /static
```

SÃ£o sÃ³ esses trÃªs â€” a lista NÃƒO Ã© ampliada com outros paths padrÃ£o
(`/admin/`, `/files/`, `/internal/` etc. nÃ£o entram). O objetivo aqui Ã©
cobrir os prefixos de roteamento que quase sempre existem, sem transformar
a rodada em fuzzing.

**Os paths padrÃ£o sÃ£o avaliados na RAIZ do host, independentemente do path
original da URL** â€” `site.com/fr/portal/secret` vira `site.com/api`,
`site.com/api/`, `site.com/v2`, `site.com/v2/`, `site.com/static`,
`site.com/static/`. O path da lista NÃƒO altera onde o path padrÃ£o Ã© testado.

Sobre cada um deles aplicam-se as mesmas sequÃªncias da seÃ§Ã£o 3, na mesma
ordem do primeiro estÃ¡gio: `../` puro sem encoding primeiro (seÃ§Ã£o 3.1.2),
depois `..;/`, `..%2f`, `..%5C`, e as variantes extras (`..%252f`,
`%2e%2e%2f`, `%5c../`, `%5c..;/`) â€” sempre **com e sem barra antes da
sequÃªncia** (regra 3.1), com 1 e 2 travessias, montadas conforme a regra de
montagem exata da seÃ§Ã£o 3 (a forma que produziria `//`, ex.
`/api//..;/`, NÃƒO Ã© testada â€” a sequÃªncia sÃ³ Ã© colada sobre o path SEM
trailing slash; o `com trailing slash` de `site.com/api/` vale apenas para
o baseline).

Vale aqui a mesma restriÃ§Ã£o do primeiro estÃ¡gio: a travessia Ã© colada no
path padrÃ£o em si. NÃ£o se testa segundo nÃ­vel, prefixo intermediÃ¡rio nem
path extra vindo de redirect.

Cada path padrÃ£o precisa do **seu prÃ³prio baseline** (a resposta de
`site.com/api` sem travessia) e do **controle pareado** â€” a mesma sequÃªncia
num path inexistente do host, nas duas formas (com e sem barra). Sem esse
par, um 400/403 global do servidor passa por sinal.

### 0.4 ClassificaÃ§Ã£o e regras de ouro

- **SÃ³ variaÃ§Ãµes de travessia apropriadas da skill** â€” nada de tÃ©cnicas fora
  do escopo da seÃ§Ã£o 3.
- **NÃ£o confirmar com base apenas em mudanÃ§a de comportamento** â€” resposta
  HTTP diferente, redirect, erro genÃ©rico ou troca de status sozinhos NÃƒO sÃ£o
  vulnerabilidade. DiferenÃ§a de comportamento Ã© sinal para investigar, nunca
  confirmaÃ§Ã£o (seÃ§Ã£o 4: comparar com baseline, raiz direta e path aleatÃ³rio
  com a mesma sequÃªncia).
- **Confirmado somente com evidÃªncia concreta e reproduzÃ­vel** â€” o re-fetch
  da mesma URL reproduz o mesmo resultado: arquivo sensÃ­vel lido
  (`.git/config`, `.env`, `README.md`, `settings.py`, com conteÃºdo â€” em alvo
  nginx, sempre testados na forma sem barra, regra obrigatÃ³ria da seÃ§Ã£o
  3.1), rota interna alcanÃ§ada, erro do backend que sÃ³ aparece com a
  sequÃªncia (ex.: 400 do Tomcat, 500 especÃ­fico de path+sequÃªncia) â€” e ainda
  assim validado em todos os contextos da seÃ§Ã£o 4.2.
- **ZERO falso positivo em `poc.txt`** â€” se hÃ¡ qualquer dÃºvida razoÃ¡vel, o
  caso nÃ£o entra no poc; vai para testar_manual. Ã‰ melhor zero achados do
  que um achado que nÃ£o se reproduz.
- **`testar_manual.txt` salva sinais sÃ³ dos 2 PRIMEIROS paths de cada host** â€”
  na hora de salvar, considerar apenas os paths 1 e 2 daquele host (ordem do
  arquivo); sinais detectados nos paths 3â€“5 NÃƒO entram no manual. Ex.: se
  detectar em `app.site.com/admin` e depois em `pp.site.com/portal` e
  `pp.site.com/cms`, salvar `app.site.com/admin` e apenas o primeiro de
  `pp.site.com` (`portal`) â€” nunca mais de 2 por domÃ­nio.

### 0.5 SaÃ­das â€” exatamente 3 arquivos

1. **`poc.txt`** â€” sÃ³ URLs confirmadas, uma por linha. Sem tÃ­tulos, sem
   explicaÃ§Ãµes, sem comentÃ¡rios, sem falsos positivos, sem inconclusivos.
   (Vazio = nenhuma confirmada.)
2. **`testar_manual.txt`** â€” sÃ³ os **2 primeiros paths de cada domÃ­nio**
   (em ordem do arquivo): se houver sinais em `app.site.com/admin` e em
   `pp.site.com/portal` e `pp.site.com/cms`, salvar `app.site.com/admin` e
   apenas `pp.site.com/portal` â€” nunca mais de 2 por domÃ­nio; sinais dos
   paths 3â€“5 nÃ£o sÃ£o salvos. Dentro desse limite, sÃ³ sinais tecnicamente
   relevantes que justificam validaÃ§Ã£o humana: a URL completa com a
   sequÃªncia, uma por linha. NÃƒO Ã© depÃ³sito de lixo: sinais genÃ©ricos jÃ¡
   descartados pelos controles (WAF uniforme, pÃ¡gina que ecoa o path,
   pÃ¡gina dinÃ¢mica) nÃ£o entram aqui.
3. **`relatorio.txt`** â€” curto, com as seÃ§Ãµes exatas:
   - **CONFIRMADO**: o que entrou no poc.txt (ou "0");
   - **INCONCLUSIVO-MANUAL**: o que estÃ¡ no testar_manual.txt e por quÃª;
   - **SEM EVIDÃŠNCIA**: o restante dos alvos testados.
   Incluir notas de cobertura (hosts/URLs, total de probes, rate-limits
   sofridos) e os falsos positivos da mÃ¡quina desmontados com os controles.

### 0.6 Checklist final (antes de reportar)

- [ ] Todas as URLs do arquivo foram lidas e atribuÃ­das a um host.
- [ ] Dedup aplicado; nenhuma URL elegÃ­vel ficou de fora (cobertura 100%).
- [ ] Agrupamento por host completo; nenhum host incorretamente fundido com
      outro.
- [ ] Cap de 5 paths/host aplicado individualmente, por host (sÃ³ os 5
      PRIMEIROS, em ordem do arquivo â€” 10 ou mais Ã¢â€ â€™ sÃ³ 5).
- [ ] EstÃ¡ticos e paths com extensÃ£o de arquivo (`.php`, `.html`, etc.)
      ignorados (e nÃ£o contaram no cap).
- [ ] Travessia testada APENAS no path em si â€” nenhum segundo path/nÃ­vel,
      prefixo intermediÃ¡rio, primeiro segmento ou path extra de redirect.
- [ ] Segundo estÃ¡gio executado em todos os hosts: `/api`, `/v2`, `/static`
      na raiz, com e sem trailing slash, com baseline e controle pareado
      prÃ³prios (e somente esses trÃªs paths padrÃ£o).
- [ ] `testar_manual.txt`: apenas sinais tecnicamente relevantes, sÃ³ dos 2
      primeiros paths de cada host.
- [ ] `poc.txt`: apenas URLs confirmadas com evidÃªncia reproduzÃ­vel â€” zero
      falso positivo.
- [ ] `relatorio.txt`: curto, com CONFIRMADO / INCONCLUSIVO-MANUAL /
      SEM EVIDÃŠNCIA bem diferenciados.

## 1. Ideia central

Um proxy reverso decide "isso Ã© um path vÃ¡lido para mim?" com uma lÃ³gica de
normalizaÃ§Ã£o diferente da lÃ³gica do backend que ele repassa a requisiÃ§Ã£o.
Quando as duas lÃ³gicas discordam sobre o que `../`, `..;`, `%2e%2e%2f` etc.
significam, Ã© possÃ­vel:

- Escapar de um prefixo de rota bloqueado (`/admin/..;/` volta para o backend
  cru sem o `/admin/`).
- Fazer o proxy encaminhar para um path que ele "acha" que Ã© outra coisa, mas
  que o backend interpreta como uma rota interna nunca exposta publicamente.
- Cair direto num servidor de aplicaÃ§Ã£o (Tomcat, JBoss, Axis2, um serviÃ§o
  interno) que estava apenas por trÃ¡s do proxy, nunca pensado para acesso
  direto.

## 2. Entrada: a lista do usuÃ¡rio (output de crawler) e o baseline

**O input desta metodologia Ã© uma lista de hosts/paths que o usuÃ¡rio fornece â€”
normalmente o output de um crawler** (trÃ¡fego real capturado: hosts, paths,
chamadas de API, redirects, rotas vistas em pÃ¡ginas/JS). **NÃ£o existe fuzzing
inicial de descoberta de paths** â€” a lista jÃ¡ Ã‰ a enumeraÃ§Ã£o; e depois de uma
travessia confirmada, tudo Ã© testado com requests diretos, um a um (seÃ§Ã£o 5),
nunca com fuzzing/brute-force.

A lista pode vir em dois formatos:

1. **Host raiz sem path** (ex.: `https://handshake.redbull.com/`): acesse e
   siga os redirects. Exemplo real: a raiz redireciona para
   `https://handshake.redbull.com/documents/` â€” o path final do redirect
   (`/documents/`) Ã© o base real onde a travessia serÃ¡ testada, nÃ£o a raiz.
2. **Host com path** (ex.: `https://site.com/admin`,
   `https://site.com/api/v1/users/12123`): cada path da lista Ã© um path base
   candidato direto â€” testa a travessia nele sem procurar mais nada.

Para cada path base (vindo de redirect ou jÃ¡ presente na lista):

1. Acesse o path e anote o status/corpo da resposta â€” esse Ã© o baseline
   daquele path (o "erro conhecido" dele: 404 padrÃ£o, mensagem JSON de erro,
   pÃ¡gina de login, etc.). Sem esse baseline vocÃª nÃ£o consegue diferenciar
   "a travessia nÃ£o fez nada" de "a travessia mudou o comportamento".
2. **Teste a travessia nele na hora** (seÃ§Ã£o 3) â€” o path jÃ¡ Ã© real, nÃ£o
   precisa de fuzzing pra descobrir nada antes. A travessia Ã© testada **sÃ³ no
   path em si** (sequÃªncia colada no fim do path, com e sem barra antes dela)
   â€” nunca em primeiro segmento, prefixo intermediÃ¡rio ou segundo path. Em
   path de API (ex.: `site.com/api/v1/users/123`), a travessia vai tambÃ©m
   dentro dos parÃ¢metros/IDs/UUIDs (seÃ§Ã£o 9: `123..;/`, `123..%2f`...) â€” mas
   sempre no prÃ³prio path, nunca em outro nÃ­vel.
3. Paths que aparecerem por **redirect** (301/302) NÃƒO viram path extra de
   teste â€” o redirect serve apenas para revelar o path base real do host
   (ex.: raiz Ã¢â€ â€™ `/documents/` = base da travessia).
4. Ignore pra fins de teste de travessia (nÃ£o pra anÃ¡lise de JS, ver seÃ§Ã£o 6)
   os paths que forem claramente arquivo estÃ¡tico pela extensÃ£o: `.js`, `.txt`,
   `.xml`, `.png`, `.svg`, `.webp`, `.jpg`, `.css`, fontes (`.woff`,
   `.woff2`, `.ttf`, `.eot`, `.otf`), `.ico`, `.sb`, `.git`, `.svn`,
   vÃ­deos/Ã¡udios (`.mp4`, `.webm`, `.mp3`, `.mov`) **e qualquer path que
   termine em extensÃ£o de pÃ¡gina** (`.php`, `.phtml`, `.html`, `.htm`,
   `.aspx`, `.asp`, `.jsp`, `.jspx`, `.cfm`, `.cgi`, `.shtml`...). Esses nÃ£o
   costumam esconder uma regra de proxy vulnerÃ¡vel, sÃ³ ruÃ­do (lista completa
   na seÃ§Ã£o 0.1, item 6).

**Modo pasta de resultados (`.txt` por host) â€” input alternativo.** Ã€s vezes
a lista chega como uma **PASTA de arquivos `.txt`** (ex.:
`/home/ferramentas/fuzz/resultados/`), um arquivo por host, cada um com URLs
(output de crawler/trÃ¡fego capturado rodado na rede do usuÃ¡rio), ex.:

```
https://api.pds.starbucks.com.cn/FUZZ
https://api.pds.starbucks.com.cn/index
https://3pp.starbucks.com.cn/#/.git/config
https://cipgsapi.stg.starbucks.com.cn/favicon.ico
https://cipgsapi.stg.starbucks.com.cn/html
https://cipgsapi.stg.starbucks.com.cn/static
https://cipgsapi.stg.starbucks.com.cn/v2
```

Ao processar cada arquivo `.txt`, aplicar estes filtros em cada linha, NESTA
ordem:

1. **Pular linha que comeÃ§a com caractere especial** (`#`, `!`, `@`, `.` no
   inÃ­cio...) â€” ex.: `https://site.com/#/.git/config` Ã© artefato de fragmento
   Ã¢â€ â€™ ignorar.
2. **Pular linha que contÃ©m `FUZZ`** â€” ex.: `https://site.com/FUZZ` Ã¢â€ â€™
   ignorar.
3. **Pular arquivo estÃ¡tico Ã³bvio** â€” `favicon.ico`, `robots.txt`, `.css`,
   `.js`, `.png`, fontes etc. Ã¢â€ â€™ ignorar.
4. Ficar com os **5 PRIMEIROS paths vÃ¡lidos** do arquivo (os arquivos variam
   de 2 a 90+ linhas; alguns hosts sÃ³ tÃªm 1â€“2 vÃ¡lidos â€” testa o que houver,
   nunca mais que 5). O cap de 5 aplica-se **por arquivo/host,
   individualmente** â€” nunca Ã© compartilhado entre hosts. **Nenhum arquivo
   (host) com pelo menos 1 path vÃ¡lido pode ficar sem processar** â€” se uma
   pasta tem 30 arquivos `.txt`, os 30 entram na rodada (seÃ§Ã£o 0.1, itens
   3â€“5).
5. Em cada path vÃ¡lido, testar a travessia da seÃ§Ã£o 3 **nas DUAS formas**:
   com barra antes da sequÃªncia (`site.com/path/..;/`) e sem barra
   (`site.com/path..;/`) â€” o par de sempre â€” e as demais sequÃªncias conforme
   o baseline responder.

## 3. SequÃªncias de bypass a testar

Para cada path vÃ¡lido (`/base/`), testar sistematicamente as variaÃ§Ãµes abaixo
â€” **com e sem barra final**, e **com 1 e com 2 travessias**:

```
/base/../
/base../
/base/..;/
/base..;/
/base/..%2f
/base..%2f
/base..%2f..%2f
/base/..%2f..%2f
/base/..%5c
/base..%5c
/base..%5C..%5C
/base/..%5C..%5C
/base/%5c..;/
/base/%5c../
/base/..%5c..%5c
/base/..;/..;/
/base/..%252f
/base/%2e%2e%2f
/base%2e%2e%2f
/base/..;/..;/
/base..;/..;/
```

**Onde inserir a sequÃªncia â€” sempre no FIM do path da lista, e sÃ³ lÃ¡.**
A travessia Ã© testada **apenas no prÃ³prio path** (ex.: `/base/..;/` e
`/base..;/`) â€” NUNCA em primeiro segmento, prefixo intermediÃ¡rio, segundo
path ou posiÃ§Ã£o interna do path (`/app..;/`, `/app/app2/..;/`,
`/public/path/config/..;/..;/internal/route` NÃƒO sÃ£o testados). Uma Ãºnica
posiÃ§Ã£o por path. A sequÃªncia Ã© a mesma para todo path: colada no fim, nas
duas formas (com e sem barra antes dela), 1 e 2 travessias.

**Montagem exata da URL â€” regra obrigatÃ³ria para o scan E para os
controles.** A URL testada Ã© SEMPRE construÃ­da a partir da tabela de
sequÃªncias, nunca a partir de uma descriÃ§Ã£o textual dela:
`URL = scheme://host + path + (barra_antes? "/" : "") + seq`. O controle
pareado (repro/rand/root, seÃ§Ãµes 0.3 e 4) deve reconstruir a MESMA URL a
partir da MESMA tabela (seq, barra_antes, travessias) â€” re-parsing de um
rÃ³tulo textual da sequÃªncia para remontar a URL Ã© a fonte de um bug real
jÃ¡ ocorrido: o rÃ³tulo Ã© ambÃ­guo (ex.: `..;//` pode ser lida como a seq
`..;/` com barra antes OU como a sequÃªncia literal `..;//`) e o controle
acaba testando uma URL DIFERENTE da escaneada. Se o log guardar apenas um
rÃ³tulo, guardar tambÃ©m a URL completa testada (ou os 3 campos
seq/barra/travessias em separado) para o controle usar essa URL exata.

**A forma de barra dupla NÃƒO Ã© testada.** Colar a sequÃªncia sobre um path
com trailing slash na variante "com barra antes" produziria `//`
(ex.: `/api//..;/`) â€” forma que confunde proxies/parsers e Ã© descartada
por decisÃ£o da skill. ConsequÃªncia prÃ¡tica: as 4 combinaÃ§Ãµes (path com/sem
trailing slash Ã— seq com/sem barra antes) colapsam em **2 URLs distintas**
por sequÃªncia:

```
/api..;/    (sem barra antes da sequÃªncia)
/api/..;/   (com barra antes da sequÃªncia â€” idÃªntico a /api/ + ..;/)
```

O trailing slash do path vale apenas para o **baseline** (a resposta de
`/api/` sem sequÃªncia, seÃ§Ã£o 0.3), nunca para montar a URL com sequÃªncia.

Pontos importantes observados na prÃ¡tica:

- **NÃ£o pule o `../` puro, sem nenhum encoding** â€” antes de partir pras
  variantes com `%2f`/`%5c`/`;`, teste sempre o traversal mais simples
  possÃ­vel: `/base/../<arquivo>` e `/base../<arquivo>` (sem barra),
  concatenado direto no path, sem nenhuma codificaÃ§Ã£o. Muita gente pula
  direto pro encoded porque "Ã³bvio que `../` cru Ã© bloqueado", mas vÃ¡rios
  proxies/CDNs sÃ³ normalizam o path se ele vier de request do prÃ³prio
  navegador (que jÃ¡ resolve `../` antes de mandar) â€” enviado cru via Burp
  Repeater/curl (sem normalizaÃ§Ã£o do cliente), o `../` sem encoding passa
  direto e o backend resolve. Caso real: `GET /README.md` Ã¢â€ â€™ 404 padrÃ£o;
  `GET /api../README.md` (sem barra antes do `../`, sem encoding nenhum) Ã¢â€ â€™
  200 com o conteÃºdo do arquivo. Ver caso completo na seÃ§Ã£o 3.1.2.
- A posiÃ§Ã£o da barra importa muito. Ã€s vezes `/base/..%2f` nÃ£o funciona mas
  `/base..%2f` (sem a barra antes da sequÃªncia) sim â€” ou o inverso. Teste as
  duas formas sempre.
- `..;/` (o "path parameter" do Tomcat/Java) costuma funcionar especificamente
  contra aplicaÃ§Ãµes Java/Tomcat/JBoss atrÃ¡s do proxy.
- `%5c` (barra invertida codificada) costuma ser Ãºtil contra proxies
  baseados em regex que sÃ³ tratam `/` e esquecem `\`.
- Duas travessias seguidas (`..;/..;/`, `..%2f..%2f`, `..%5c..%5c`) Ã  s vezes
  sÃ£o necessÃ¡rias quando o path base tem mais de um segmento.
- Se nada disso responder diferente do baseline, tente as variantes menos
  comuns de encoding duplo/misto (`..%252f`, `....///`) antes de desistir
  daquele path.

### 3.1 â€” A sequÃªncia pode funcionar SEM a barra antes dela (e atÃ© Ã© a ÃšNICA forma que funciona)

A regra do "par de sempre" (com barra e sem barra) precisa de Ãªnfase extra:
em vÃ¡rios casos reais a forma **sem barra antes da sequÃªncia** Ã© a Ãºnica que
funciona, principalmente com `%5c` e com 2 travessias. Sempre testar o par:

```
site.com/path/..%2f      (com barra antes da sequÃªncia)
site.com/path..%2f       (SEM barra â€” sequÃªncia colada no Ãºltimo segmento)
site.com/path..%5C..%5C  (sem barra + 2 travessias + barra invertida)
site.com/path/..%5C..%5C (com barra + 2 travessias + barra invertida)
```

### 3.1.1 â€” Regra obrigatÃ³ria para alvos nginx: arquivos sensÃ­veis SEMPRE sem barra

Existe uma exceÃ§Ã£o **obrigatÃ³ria** Ã   regra do par (com e sem barra) acima, e
ela vale **sÃ³** para este caso especÃ­fico: quando a tecnologia do proxy
identificada for **nginx** (nÃ£o Tomcat, nÃ£o JBoss, nÃ£o outra stack Java), o
teste dos quatro arquivos sensÃ­veis padrÃ£o desta skill â€” `.git/config`,
`.env`, `README.md`, `settings.py` â€” usando as sequÃªncias `..%2f`,
`..%2f..%2f`, `..%5C`, `..%5C..%5C` Ã© feito **apenas na forma colada no
path, sem barra antes da sequÃªncia**:

```
<path>..%2f.git/config
<path>..%2f..%2f.git/config
<path>..%5C.env
<path>..%5C..%5C.env
<path>..%2f..%2fREADME.md
<path>..%5C..%5Csettings.py
```

**NÃƒO teste a forma com barra** (`<path>/..%2f..%2f.git/config`,
`<path>/..%5C..%5C.env` etc.) para esse conjunto especÃ­fico â€” arquivo
sensÃ­vel + essas 4 sequÃªncias â€” quando o alvo for nginx; ela nÃ£o faz parte
do padrÃ£o observado nesse cenÃ¡rio e sÃ³ gera requests/ruÃ­do desnecessÃ¡rios.

**Essa exceÃ§Ã£o nÃ£o muda mais nada na skill â€” vale sÃ³ para esse par exato
(os 4 arquivos acima Ã— essas 4 sequÃªncias Ã— alvo nginx):**

- Todas as **demais** sequÃªncias e testes de bypass da seÃ§Ã£o 3 (`..;/`,
  `%5c../`, `%5c..;/`, `..%252f`, `%2e%2e%2f` etc.) continuam **obrigatÃ³rias**
  nas duas formas â€” com e sem barra â€” exatamente como descrito acima, seja o
  alvo nginx ou qualquer outra tecnologia.
- Toda identificaÃ§Ã£o/confirmaÃ§Ã£o de **Tomcat, JBoss ou outra stack Java**
  (seÃ§Ãµes 4, 4.1, 4.2, 8, 8.1) continua testada normalmente **com e sem
  barra** â€” nada muda nessas seÃ§Ãµes, a regra acima Ã© especÃ­fica de nginx +
  arquivo sensÃ­vel.
- Se a tecnologia do alvo **nÃ£o** for nginx (por exemplo, a travessia jÃ¡
  revelou Tomcat/JBoss por trÃ¡s), teste os 4 arquivos sensÃ­veis nas **duas
  formas** (com e sem barra), seguindo a regra geral desta seÃ§Ã£o 3.1.

**Caso real â€” vazamento de `.git/config` com token, SEM barra antes da
sequÃªncia (alvo nginx):**

```
https://alvo.com/app..%5C..%5C.git/config
```

A travessia foi **colada no path** (`app..%5C`) â€” nÃ£o `app/..%5C` â€” com **2
travessias** e **`%5C`** (barra invertida codificada). O `.git/config`
retornou o corpo do arquivo com uma URL de repositÃ³rio contendo token
embutido; com o token foi possÃ­vel clonar o repositÃ³rio privado inteiro. Ou
seja: o padrÃ£o "path..%5C..%5C.git/config" (sem barra, 2 travessias, `%5C`)
Ã© uma combinaÃ§Ã£o que jÃ¡ provou vazar repositÃ³rio em alvo nginx â€” Ã© por isso
que, em nginx, a forma sem barra Ã© a Ãºnica forma testada para esse conjunto
de arquivos (regra 3.1.1 acima).

**Caso real â€” 2 travessias SEM barra funcionando onde a versÃ£o COM barra Ã©
bloqueada:**

```
baseline:   https://alvo.com/404.html
            Ã¢â€ â€™ {"message":"no Route matched with those values"}   (erro padrÃ£o)

com barra:  https://alvo.com/rota/..%2f..%2f404.html
            Ã¢â€ â€™ 403

SEM barra:  https://alvo.com/rota..%2f..%2f404.html
            Ã¢â€ â€™ 404 Not Found / GATEWAY   (outro erro, outro sistema â€” sinal de travessia)
```

A forma que funcionou foi **sem a barra inicial e com 2 travessias** â€” a
forma com barra deu 403. Se vocÃª sÃ³ tivesse testado com barra, teria perdido.
Por isso: **toda sequÃªncia da lista acima Ã© testada com e sem a barra antes
dela, com 1 e com 2 travessias** â€” sÃ£o 4 combinaÃ§Ãµes obrigatÃ³rias por
sequÃªncia (`path/..%2f`, `path..%2f`, `path/..%2f..%2f`, `path..%2f..%2f`),
e o mesmo para `..;/`, `..%5c`, `%5c../`, `%2e%2e%2f`, `..%252f`.

**Caso real â€” uma das duas formas responde diferente:** em um alvo, a forma
com barra (`<base>/..%2f`) carregava uma pÃ¡gina diferente da inicial com
vÃ¡rios JS (sinal); a regra vale pra qualquer host: se a forma com barra der
o mesmo erro da pÃ¡gina inicial e a forma sem barra der algo diferente â€” ou
vice-versa â€” Ã© aÃ­ que estÃ¡ a travessia. A mÃ¡quina de detecÃ§Ã£o TEM que
**diferenciar os erros**: resposta idÃªntica Ã   pÃ¡gina inicial = nÃ£o fez nada;
resposta diferente (outra pÃ¡gina de erro, outro formato, JS novo) = sinal.

### 3.1.2 â€” Caso real: `../` puro (sem encoding nenhum) expÃµe um `README.md` que vira mina de recon

Caso real completo, documentado de ponta a ponta â€” do payload mais simples
possÃ­vel atÃ© o valor real do achado. Serve de modelo pra qualquer alvo onde
a tÃ©cnica de encoding "chique" (`%2f`, `%5c`, `;`) nem chegou a ser
necessÃ¡ria.

**Baseline:**

```
GET /README.md HTTP/2
Host: site.com
Ã¢â€ â€™ 404 Not Found (pÃ¡gina padrÃ£o do site)
```

**Payload que funcionou â€” `../` cru, sem qualquer encoding, colado sem
barra no segmento anterior:**

```
GET /api../README.md HTTP/2
Host: site.com
Ã¢â€ â€™ 200 â€” conteÃºdo completo do README.md do backend
```

Note o padrÃ£o: Ã© exatamente a forma "sem barra antes da sequÃªncia" da seÃ§Ã£o
3.1 (`api` + `../` colado, nÃ£o `api/` + `../`), sÃ³ que com o traversal mais
simples que existe â€” sem `%2f`, sem `%5c`, sem `;`. Antes de qualquer
encoding especial, **sempre teste essa forma primeiro** (`<path>../<arquivo
alvo>`, com e sem barra antes do `../`) â€” muitos alvos nem chegam a
precisar de encoding.

**Por que esse achado vale muito mais do que "consegui ler um arquivo":** o
`README.md` de um repositÃ³rio de backend costuma ser o "cheatsheet do
desenvolvedor" â€” e o conteÃºdo real, quando lido por completo, pode conter:

- **Entrypoints internos da aplicaÃ§Ã£o** (ex.: `/web/index.php`,
  `/api/index.php`, `/bin/iraxen`) â€” cada um Ã© um path base novo pra rodar o
  processo completo da skill (seÃ§Ãµes 2 e 3).
- **URLs de todos os ambientes** (produÃ§Ã£o, staging, demo, desenvolvimento)
  â€” cada uma Ã© um alvo novo pra alimentar a seÃ§Ã£o 7 (comparar
  stg/demo/dev vs. prod: o que nÃ£o existe ou nÃ£o responde em um pode
  responder no outro).
- **Nome/infra do servidor interno**, revelado indiretamente (ex.: variÃ¡vel
  de configuraÃ§Ã£o de IDE remoto tipo `PHP_IDE_CONFIG`/`serverName=...`
  apontando pro hostname interno real) â€” tecnologia/infra exposta direciona
  a seÃ§Ã£o 8.
- **Comandos de execuÃ§Ã£o operacional** (ex.: `docker exec ...` pra rodar
  cronjob, importar fixtures de teste) e **nomes de tabelas internas** (ex.:
  uma tabela tipo `core_cron` referenciada no texto) â€” isso Ã© informaÃ§Ã£o de
  reconhecimento valiosa pro relatÃ³rio (mostra profundidade do acesso
  possÃ­vel), mas **nunca deve ser executado** â€” rodar um `docker exec`
  encontrado num arquivo vazado Ã© uma aÃ§Ã£o real na infraestrutura do alvo,
  fora do escopo de leitura da regra de ouro (seÃ§Ã£o 0, inÃ­cio da skill).
  Documentar o comando como evidÃªncia ("consegui ver que seria possÃ­vel
  rodar X"), nÃ£o executÃ¡-lo.
- **ConfiguraÃ§Ã£o de debug** (ex.: `xdebug` configurado "pra funcionar de
  cara") â€” sinal de ambiente com debug ligado, o que costuma acompanhar
  outras exposiÃ§Ãµes (stack traces mais verbosos, endpoints de debug).

**Regra prÃ¡tica:** depois de confirmar leitura de um `README.md` (ou
qualquer arquivo de config/texto) via travessia, **leia o arquivo inteiro
e extraia sistematicamente** â€” nÃ£o sÃ³ confirme que abriu:
1. paths/entrypoints internos Ã¢â€ â€™ viram novos path base (seÃ§Ã£o 2/3);
2. URLs de outros ambientes Ã¢â€ â€™ alimentam a seÃ§Ã£o 7;
3. nomes de host/servidor/infra Ã¢â€ â€™ alimentam a seÃ§Ã£o 8 (CVEs/versÃ£o);
4. comandos e credenciais Ã¢â€ â€™ documentar como evidÃªncia, nunca executar.

**Cuidado ao interpretar o conteÃºdo:** o prÃ³prio README pode conter
referÃªncias que jÃ¡ eram parcialmente conhecidas do ambiente externo (nomes
de arquivos internos citados, execuÃ§Ã£o de cronjob mencionada, nome do
servidor interno exposto de forma indireta) â€” trate o conteÃºdo como pista a
validar, nÃ£o como verdade absoluta sobre o que estÃ¡ de fato acessÃ­vel;
valide cada entrypoint/URL extraÃ­do dele testando na hora (mesmo processo
de baseline + travessia da seÃ§Ã£o 2/3), nunca assumindo que sÃ³ porque estÃ¡
escrito no arquivo, o acesso realmente existe.

**Nota sobre cobertura:** nem todo nome de arquivo sensÃ­vel "clÃ¡ssico" vai
responder em todo alvo â€” nesse caso real, sÃ³ o `README.md` respondeu; outros
arquivos comuns testados nÃ£o retornaram conteÃºdo. Isso Ã© normal e deve ser
registrado com honestidade no relatÃ³rio (seÃ§Ã£o 0.5/10): reportar o que
funcionou, nÃ£o inflar com tentativas que nÃ£o confirmaram nada, e sinalizar
que testar mais nomes de arquivo conhecidos do stack identificado
(seÃ§Ã£o "arquivos sensÃ­veis" mais abaixo) pode ampliar a cobertura.

## 4. Como confirmar que a travessia Ã© real

NÃ£o basta o status code mudar â€” pode ser sÃ³ um 403/404 diferente do mesmo
sistema. Sinais de travessia **confirmada**:

- O corpo da resposta muda de forma estrutural: sai da mensagem JSON/HTML do
  gateway e vira a pÃ¡gina padrÃ£o de outro sistema (ex.: pÃ¡gina padrÃ£o do
  Tomcat, tela de login diferente, stack trace revelando tecnologia/versÃ£o).
- Aparecem recursos (JS, CSS) de uma aplicaÃ§Ã£o completamente diferente da
  esperada.
- Um arquivo sensÃ­vel que sÃ³ existiria na raiz do backend real responde
  (`.git/config`, `.env`, `README.md`, `settings.py`, `web.config`, arquivos
  de configuraÃ§Ã£o de framework â€” em alvo nginx, testados sÃ³ na forma sem
  barra, regra obrigatÃ³ria da seÃ§Ã£o 3.1.1).
- Comparar sempre com o acesso direto Ã   raiz do domÃ­nio
  (`https://alvo.com/`, sem o path base) â€” se o resultado da travessia Ã©
  igual ao da raiz normal, nÃ£o Ã© travessia, Ã© sÃ³ o proxy roteando pra lÃ¡ por
  outro motivo.

Depois de confirmada, tentar identificar a tecnologia exposta (Tomcat, JBoss,
Axis2, Spring Boot Actuator, Django, nginx interno...) pelo corpo da resposta,
headers e comportamento de erro â€” isso direciona quais CVEs conhecidas e quais
paths sensÃ­veis testar a seguir (seÃ§Ãµes 5 e 8).

**Antes de qualquer outro teste, leia o conteÃºdo da prÃ³pria pÃ¡gina que a
travessia carregou.** Muitas pÃ¡ginas padrÃ£o de aplicaÃ§Ã£o (a pÃ¡gina padrÃ£o do
Tomcat Ã© o exemplo clÃ¡ssico) jÃ¡ vÃªm com **links prontos** apontando pra outros
recursos internos â€” e o mais importante: esses links jÃ¡ vÃªm formatados com o
prefixo de travessia confirmado embutido neles, porque foram gerados
relativos ao path onde vocÃª estÃ¡. Exemplo real: ao confirmar a travessia em
`https://alvo.com/documents/..;/` e cair na pÃ¡gina padrÃ£o do Tomcat, o
prÃ³prio HTML da pÃ¡gina jÃ¡ contÃ©m:

```
https://alvo.com/documents/..;/docs/
https://alvo.com/documents/..;/examples/
https://alvo.com/documents/..;/manager/html
https://alvo.com/documents/..;/host-manager/html
```

Esses links sÃ£o candidatos de **prioridade mÃ¡xima** â€” teste-os direto, na
hora. Eles nÃ£o sÃ£o um chute: Ã© a prÃ³pria aplicaÃ§Ã£o te dizendo o que existe.
Se `manager/html` ou `host-manager/html` responderem (e nÃ£o sÃ³ um redirect de
login), vocÃª jÃ¡ tem acesso a um painel administrativo conhecido â€” siga pra
seÃ§Ã£o 8 pra ver quais CVEs/credenciais testar contra ele.

Isso vale pra qualquer pÃ¡gina, nÃ£o sÃ³ Tomcat: pÃ¡ginas de erro, index padrÃ£o,
consoles administrativos, tudo que carregar depois da travessia confirmada
deve ser lido em busca de href/src/link antes de qualquer coisa.

SÃ³ depois de esgotar os links que a prÃ³pria pÃ¡gina revelou e os arquivos
sensÃ­veis diretos (seÃ§Ã£o 5), qualquer path novo que aparecer â€” via redirect,
linkagem ou JS (seÃ§Ã£o 6) â€” vira um novo path base e o processo de detecÃ§Ã£o se
repete nele (seÃ§Ãµes 2 e 3).

### 4.1 â€” O sinal pode ser apenas uma pÃ¡gina de erro DIFERENTE (e mesmo assim Ã© travessia)

Em vÃ¡rios casos reais o sinal nÃ£o Ã© um 200 com dados â€” Ã© a **troca da pÃ¡gina
de erro**. VocÃª nÃ£o recebe nada explÃ­cito, mas o erro que volta nÃ£o Ã© o erro
da aplicaÃ§Ã£o principal: Ã© o erro da aplicaÃ§Ã£o interna (Tomcat, JSP, gateway).
Isso jÃ¡ Ã© evidÃªncia de que a normalizaÃ§Ã£o caiu num sistema atrÃ¡s do proxy.

**Caso real â€” pÃ¡gina de erro JSP no lugar da pÃ¡gina principal:**

```
pÃ¡gina principal (raiz): pÃ¡gina de teste de um servidor Linux genÃ©rico (RHEL)

https://alvo.com/<path-da-app>/..;/
Ã¢â€ â€™ pÃ¡gina de ERRO em template JSP/Spring (link <c:url value='/static/...'>,
  "ERROR" centralizado em cÃ­rculo cinza) â€” um template de erro de UMA
  APLICAÃ‡ÃƒO DIFERENTE da pÃ¡gina principal
```

A travessia nÃ£o trouxe dados â€” trouxe o **template de erro da aplicaÃ§Ã£o
interna** (aplicaÃ§Ã£o escondida num path da app), que nÃ£o tem nada a ver com a
pÃ¡gina da raiz. A troca do template de erro = sinal de travessia.

**Caso real â€” erro do Tomcat exposto mesmo sem dados:**

```
https://alvo.com/painel/qualquer-coisa
Ã¢â€ â€™ HTTP Status 404 â€“ Bad Request / Apache Tomcat/9.0.71   (erro do TOMCAT)

https://alvo.com/qualquer-coisa
Ã¢â€ â€™ 404 Not Found normal (aplicaÃ§Ã£o padrÃ£o, SEM Tomcat)

https://alvo.com/painel/..;/
Ã¢â€ â€™ HTTP Status 400 â€“ Bad Request / "Message Invalid URI" / Apache Tomcat/9.0.71
```

Duas liÃ§Ãµes: (1) o roteamento pro Tomcat existe **sÃ³ debaixo daquele path
de aplicaÃ§Ã£o** â€” o mesmo path fora dele Ã© o 404 da aplicaÃ§Ã£o padrÃ£o;
(2) a travessia respondeu com o **erro 400 do prÃ³prio Tomcat** ("Invalid
URI") â€” o Tomcat reagiu Ã   sequÃªncia, o que confirma que o proxy repassou o
path cru pra ele. O 400 do Tomcat depois de uma travessia Ã© um sinal clÃ¡ssico
de que vocÃª chegou no servidor de aplicaÃ§Ã£o.

**Caso real â€” o gateway tem erro em formato JSON, e a travessia muda o
formato do erro:**

```
raiz/path normal:  {"message":"no Route matched with those values"}
travessia:         "404 Not Found / GATEWAY"  (outro formato, outra origem)
```

Erro padrÃ£o em JSON = dentro do gateway; erro em outro formato = vocÃª saiu
do gateway. **Diferenciar os erros Ã© a mÃ¡quina de detecÃ§Ã£o**: resposta igual
ao baseline = nada; resposta com formato/origem diferente = candidato forte.

### 4.2 â€” Validar em TODOS os contextos (baseline, raiz direta, path direto)

Ao confirmar uma travessia, validar o achado comparando com os TRÃŠS acessos:
(1) o baseline do path (sem travessia), (2) a raiz do domÃ­nio direta, (3) o
path direto na raiz (sem o prefixo). Caso real:

```
baseline:  /portal/            Ã¢â€ â€™ formulÃ¡rio "Password Forgotten" da app
travessia: /portal/..;/        Ã¢â€ â€™ Apache Tomcat/9.0.71 (pÃ¡gina padrÃ£o)
raiz:      /                   Ã¢â€ â€™ TAMBÃ‰M mostra pÃ¡gina do Tomcat 9.0.71
                                  (ou redirect pro login do portal)
```

Quando a raiz direta **tambÃ©m** mostra a tecnologia (Tomcat no caso), a
travessia sozinha Ã© mais fraca â€” o Tomcat estÃ¡ exposto de qualquer forma. O
caso forte Ã© quando a raiz mostra OUTRA coisa (404, login, outra app) e a
travessia mostra o Tomcat/outro sistema. Por isso a validaÃ§Ã£o em todos os
contextos Ã© obrigatÃ³ria antes de reportar: **compare sempre a resposta da
travessia com a raiz direta e com o path direto**, nÃ£o sÃ³ com o baseline.

### 4.3 â€” A raiz pode nem ser HTML â€” e isso nÃ£o significa que nÃ£o hÃ¡ nada atrÃ¡s

Caso real: a raiz do domÃ­nio responde uma **imagem PNG** (nem HTML). NÃ£o Ã©
porque a raiz Ã© um PNG/redireciona/vaza que nÃ£o existe aplicaÃ§Ã£o atrÃ¡s do
proxy â€” um path de API (`/api`) respondia uma pÃ¡gina "Not Found" e
`/api/..%2f` carregou a aplicaÃ§Ã£o inteira (SPA Vue com assets). **A resposta
da raiz nÃ£o diz nada sobre o que existe atrÃ¡s do proxy** â€” o que diz Ã© a
resposta depois da travessia.

### 4.4 â€” AplicaÃ§Ã£o escondida atrÃ¡s de um path (a pÃ¡gina principal nÃ£o Ã© a app real)

Caso real: a raiz era a pÃ¡gina de teste de um servidor Linux (RHEL), mas
**existe uma aplicaÃ§Ã£o inteira escondida** num path â€” um sistema de
formulÃ¡rios com login prÃ³prio, CSS e JS prÃ³prios. A aplicaÃ§Ã£o real nem
sempre Ã© visÃ­vel na raiz: ela pode morar num path interno que o proxy expÃµe.
Toda aplicaÃ§Ã£o encontrada atrÃ¡s de um path desses Ã© um path base completo â€”
baseline, sequÃªncias da seÃ§Ã£o 3 (com e sem barra, 1 e 2 travessias),
arquivos sensÃ­veis, e a troca de erro como sinal.

### 4.5 â€” Um host "espelho" apontado por JS pode esconder o mesmo painel no host original

Caso real: um site carregava um JS que redirecionava pra um domÃ­nio parecido
(`alvo.com` Ã¢â€ â€™ `alvo.com.net/admin_painel`). Antes de seguir o redirect,
testar o **mesmo path no host original** â€” o path pode responder 200 no host
local (sem o redirect pro host espelho), revelando um painel escondido:

```
alvo.com/admin_painel   Ã¢â€ â€™ 200 no host original (painel escondido)
```

A partir daÃ­ o painel Ã© um path base completo: testar
`admin_painel/..;/`, `admin_painel..;/`, `admin_painel..%2f`,
`..%2f..%2f`, `..%5C..%5c` â€” comparando sempre com o baseline e a raiz â€” e,
se algo responder, os arquivos da tecnologia identificada (`.git/config`,
`.env`, `README.md`, `settings.py`, coisas de Tomcat/Java/actuator/Django â€”
**apenas as relevantes pra tecnologia identificada, nunca um monte de coisas
aleatÃ³rias que geram ruÃ­do**; se a tecnologia identificada for **nginx**,
esses 4 arquivos sensÃ­veis sÃ£o testados **sÃ³ na forma sem barra**, regra
obrigatÃ³ria da seÃ§Ã£o 3.1.1 â€” para Tomcat/JBoss/Java, nas duas formas, como
sempre).

## 5. Depois da travessia confirmada â€” teste manual direto (sem fuzzing)

Depois de confirmar que uma sequÃªncia atravessa (seÃ§Ã£o 4), **NÃƒO se roda
nenhum fuzzing/brute-force** â€” tudo Ã© testado com requests diretos, um a um,
sempre na sequÃªncia exata que confirmou a travessia naquele path. Passo a
passo:

**Passo 1 â€” arquivos sensÃ­veis direto, na sequÃªncia confirmada.** Cada
arquivo clÃ¡ssico Ã© uma requisiÃ§Ã£o Ãºnica, na hora, com o path + payload
exatos da travessia:

```
<PATH_BASE><SEQ_CONFIRMADA>.env
<PATH_BASE><SEQ_CONFIRMADA>.git/config
<PATH_BASE><SEQ_CONFIRMADA>README.md
<PATH_BASE><SEQ_CONFIRMADA>settings.py
```

Exemplos reais do formato:

```
admin/..%5C..%5c  confirmou travessia  Ã¢â€ â€™  tente:  admin/..%5C..%5C.git/config
proxy/api/users/12312..%5C..%5c..%5C  confirmou travessia  Ã¢â€ â€™  tente:
    proxy/api/users/12312..%5C..%5c..%5C.env
    proxy/api/users/12312..%5C..%5c..%5C.git/config
    proxy/api/users/12312..%5C..%5c..%5C README.md
    proxy/api/users/12312..%5C..%5c..%5Csettings.py
```

**Regra obrigatÃ³ria (seÃ§Ã£o 3.1.1) â€” depende da tecnologia do proxy:**

- **Se a tecnologia identificada for nginx:** teste esses 4 arquivos
  (`.env`, `.git/config`, `README.md`, `settings.py`) com `..%2f`,
  `..%2f..%2f`, `..%5C`, `..%5C..%5C` **apenas na forma sem barra, colada no
  path** (`path..%5C..%5C.git/config`) â€” **nÃ£o** teste a forma com barra
  para esse conjunto arquivo+sequÃªncia em nginx. `path..%5C..%5C.git/config`
  jÃ¡ vazou um repositÃ³rio inteiro em caso real.
- **Se a tecnologia identificada for Tomcat, JBoss ou outra stack Java:**
  teste esses mesmos 4 arquivos nas **duas formas**, com e sem barra, como
  qualquer outra sequÃªncia da seÃ§Ã£o 3 â€” a restriÃ§Ã£o acima Ã© exclusiva de
  nginx.

Se a tecnologia identificada for Django, `settings.py` Ã© prioridade mÃ¡xima;
se for Java/Spring, `.git/config` e `.env`; se a resposta da travessia jÃ¡
mostrou dados estruturados de uma API, vocÃª jÃ¡ estÃ¡ num endpoint de dados â€”
teste rotas irmÃ£s Ã³bvias daquela API (seÃ§Ã£o 9, item 4).

**Passo 2 â€” leia a pÃ¡gina que a travessia carregou e teste os links nativos.**
PÃ¡ginas padrÃ£o (Tomcat, index de outra aplicaÃ§Ã£o) vÃªm com links prontos
(`docs/`, `examples/`, `manager/html`, `host-manager/html`) jÃ¡ formatados
com o prefixo de travessia embutido â€” teste cada um direto, na hora (seÃ§Ã£o
4).

**Passo 3 â€” rotas de JS.** Se a pÃ¡gina expÃµe JS, baixe e extraia as rotas
(seÃ§Ã£o 6) e teste cada uma nas 3 formas (atravÃ©s da travessia / com o
prefixo / direto na raiz).

**Passo 4 â€” cada resposta que mudar do baseline vira um novo path base.**
Qualquer path que responder diferente (status, corpo, redirect) apÃ³s esses
testes Ã© um path base completo: repita o processo nele (baseline da seÃ§Ã£o 2,
sequÃªncias da seÃ§Ã£o 3, confirmaÃ§Ã£o da seÃ§Ã£o 4) â€” e siga encadeando enquanto
houver resposta nova. Sem repetiÃ§Ã£o: mantenha a lista de paths jÃ¡ testados
(seÃ§Ã£o 6, item 10).

**Regras que valem pra todo teste direto pÃ³s-travessia:**

- Use **exatamente a sequÃªncia que confirmou a travessia naquele path** â€” se
  foi `..%2f` que funcionou (e `..;/` deu 403), os testes diretos usam
  `..%2f`; misturar sequÃªncias invalida tudo (vocÃª estaria testando um path
  que nem atravessou).
- Cuidado com encoding duplo (`..%252f`): confirme com `curl -v` que a
  sequÃªncia chega **literal** no servidor (olhe a linha "GET /...%252f..." no
  output verboso) â€” se alguma camada decodificar pra `%2f`, o teste estÃ¡
  testando outra coisa.
- Teste sempre as duas formas do par: com barra (`<path>/<seq>...`) e sem
  barra (`<path><seq>...`).
- A requisiÃ§Ã£o manual reproduz exatamente o que vocÃª confirmou â€” sem trocar o
  path de lugar, sem simplificar cadeias longas (ex.: a cadeia
  `web\..\.\..\.\..\.\..\.\` da seÃ§Ã£o 9 vai inteira, igual).

### 5.1 â€” Caso real: backend Windows/IIS atrÃ¡s de nginx â€” `..%5c` + downloads (DLL incluÃ­da)

**Alvo real:** `mssplus.stg.starbucks.com.cn` (app interna ASP.NET de RH,
`STBKSMSSP101_REST_SIGN`, anÃ´nimo, sem credencial). Mesmo padrÃ£o vale pra
qualquer stack Windows (IIS/ASP.NET) atrÃ¡s de proxy que nÃ£o normaliza `\`.

**Causa raiz:** o nginx repassa o path **cru** ao IIS sem normalizar `%5c`
(`\`). O IIS trata `\` como separador de diretÃ³rio e normaliza
`/api/..%5c` de volta Ã   **raiz da aplicaÃ§Ã£o interna**. O mesmo
comportamento respondeu em **8 prefixos aliases** do mesmo host
(`/api/`, `/v2/`, `/v3/`, `/assets/`, `/api_test/`, `/apicache/`,
`/apimage/`, `/apis/` Ã¢â€ â€™ mesmo backend).

**Como foi confirmado (passo a passo):**

1. **Directory listing como primeira evidÃªncia:**
   ```
   GET https://alvo.com/api/..%5c
   Ã¢â€ â€™ 200 â€” listing de /STBKSMSSP101_REST_SIGN/ (Global.asax, Controllers/,
     Models/, Properties/, obj/, bin/, FakesAssemblies/...)
   ```
   Headers delatores: `X-Powered-By: ASP.NET`, `X-AspNet-Version: 4.0.30319`,
   `Server: nginx/1.26.0`. **Controle (obrigatÃ³rio):** a raiz pÃºblica
   `https://alvo.com/` Ã¢â€ â€™ 200 SPA normal, sem listing. O listing SÃ“ existe via
   travessia â€” sinal forte, nÃ£o ruÃ­do.
2. **SubdiretÃ³rios tambÃ©m listam** (`..%5c<dir>/` com barra final):
   `..%5ccontrollers/` (123 controllers), `..%5cmodels/`, `..%5cobj/Debug/`.
3. **Request Filtering do IIS filtra POR EXTENSÃƒO:** `.cs`, `.config`,
   `.pdb`, `.dll`? (ver item 5), `.cache`, `.fakes*`, `.messages`, `.scc` Ã¢â€ â€™
   404. **`.txt` e `.xml` NÃƒO estÃ£o na lista de negaÃ§Ã£o Ã¢â€ â€™ baixam
   integralmente.** Verificar SEMPRE quais extensÃµes passam e testar as que
   passam â€” cada uma Ã© um canal de leitura.
4. **Downloads integrais confirmados** (validaÃ§Ã£o de integridade: tamanho do
   download == tamanho exibido no listing):
   ```
   GET /api/..%5cobj/Debug/STBKSMSSP101_REST.csproj.FileListAbsolute.txt
   Ã¢â€ â€™ 200, 10.320 bytes â€” inventÃ¡rio de build com paths absolutos
     C:\Projects\starbucks.git\... (89 arquivos: 48 dll, 27 xml, 3 pdb...)
   GET /api/..%5cFakesAssemblies/Microsoft.IdentityModel.Tokens.5.3.0.0.Fakes.xml
   Ã¢â€ â€™ 200, 559.593 bytes
   ```
5. **ATENÃ‡ÃƒO â€” `.dll` NÃƒO estava bloqueado (diferente do esperado):** o
   binÃ¡rio .NET baixou **de prod E de staging** com a mesma sequÃªncia:
   ```
   GET https://alvo.com/api/..%5cobj%5cDebug%5cSTBKSMSSP101_REST.dll
   Ã¢â€ â€™ 200, 486.912 bytes (PE32 .NET assembly) â€” md5 idÃªntico em prod e stg
   ```
   **Por que baixar a DLL vale a pena (nÃ£o Ã© sÃ³ "arquivo binÃ¡rio"):** com a
   DLL em mÃ£os, decompiladores (dnSpy/ILSpy) reconstroem o C# quase original.
   Neste caso revelou: **credencial LDAP em strings UTF-16**
   (`MS03394.starbucks.net:389/OU=China,DC=starbucks,DC=net` + usuÃ¡rio
   `promis` + senha `Welcome@2` + chaves `LDAP_SERVER_ADMIN_USER_CODE/PASSWORD`),
   chaves JWT/OCR (`hx_common_jwt_secret_key`, `hx_baidu_ocr_secret_key`,
   `client_secret`), **URL interna** `http://172.16.23.253:9540/` (IP
   privado), **50 tabelas do banco** via queries SQL completas embutidas
   (hxhr_employee, hxhr_emp_compensation...) e **226 tipos** (controllers,
   `LoginManager`, `JwtManager`, `BasicAuthenticationFilter`...).
6. **EvidÃªncia salva sempre:** baixar listing/arquivo/DLL para disco
   (`curl -sk --path-as-is "URL" -o arquivo`) e conferir tamanho â€” 100%
   reproduzÃ­vel para o relatÃ³rio.

**LiÃ§Ãµes pro fluxo:** (1) `..%5c` contra stack Windows atrÃ¡s de proxy =
candidato fortÃ­ssimo (seÃ§Ã£o 3.1); (2) nunca assumir que extensÃ£o sensÃ­vel
estÃ¡ bloqueada â€” **testar o download de `.dll`/binÃ¡rios explÃ­cito**, nÃ£o sÃ³
`.txt`/`.xml`; (3) listing + downloads com tamanho batendo = confirmaÃ§Ã£o de
leitura arbitrÃ¡ria, sem depender de conteÃºdo sensÃ­vel; (4) ambientes stg e
prod com o mesmo binÃ¡rio Ã¢â€ â€™ o achado vale pros dois (seÃ§Ã£o 7); (5) GET com
efeito de escrita pode coexistir (`GET /api/empRecruit` criava registros no
banco sem auth â€” checar GETs stateful apÃ³s confirmar travessia, seÃ§Ã£o 0.3:
somente leitura, nada de criar/alimentar dados reais).

## 6. Coletar rotas via JS / trÃ¡fego capturado

Se a pÃ¡gina carregada apÃ³s a travessia expÃµe arquivos JS/HTML da aplicaÃ§Ã£o
interna:

1. Baixe os JS encontrados na pÃ¡gina (ex.: `web/app.js`, `assets/index.js`)
   e leia tambÃ©m os links (`href`/`src`) presentes direto no HTML â€” como
   descrito na seÃ§Ã£o 4, pÃ¡ginas padrÃ£o (Tomcat, index de outra aplicaÃ§Ã£o
   etc.) costumam jÃ¡ vir com links prontos pra outros recursos internos.
   **Baixe TODOS os JS que a pÃ¡gina referencia** (o HTML da travessia lista
   os `<script src>`/`<link>` â€” cada um Ã© uma fonte de rotas).
2. Procure rotas/endpoints de API referenciados no cÃ³digo.
3. Teste o endpoint de duas formas â€” direto e atravÃ©s da mesma travessia que
   deu acesso ao JS. Caso real: o JS revelou `web/app.js` e o acesso foi
   tentado nas 3 formas abaixo (a que funciona depende de como o proxy
   normaliza â€” teste as trÃªs):
   ```
   https://alvo.com/<base>/..%2fweb/app.js    (atravÃ©s da travessia)
   https://alvo.com/<base>/web/app.js         (com o prefixo, sem travessia)
   https://alvo.com/web/app.js                (direto na raiz)
   ```
   O mesmo vale pros endpoints achados no JS: a travessia carregou uma SPA
   que referenciava `assets/index.js` etc. (paths absolutos `/assets/...`) â€”
   cada asset foi buscado **atravÃ©s da travessia**
   (`<api>/..%2fassets/index.js`) e baixado pra anÃ¡lise. Regra:
   `site.com/base/<SEQ>/<caminho-do-asset>` primeiro; se nÃ£o funcionar,
   `site.com/base/<caminho>` e `site.com/<caminho>`.
4. Se o endpoint aceita aÃ§Ãµes sensÃ­veis (ex.: login/token), teste **apenas**
   leitura ou fluxos que o prÃ³prio programa de bug bounty autoriza â€” nunca
   aÃ§Ãµes destrutivas. Em caso real, um endpoint de recuperaÃ§Ã£o de token
   achado no JS era acessÃ­vel tanto direto quanto atravÃ©s da travessia â€”
   testar as duas formas, pois sÃ³ uma pode responder.
5. **Toda rota extraÃ­da do JS Ã© um novo path base** â€” nÃ£o trate sÃ³ como
   "endpoint pra acessar", trate como candidato completo pra repetir o
   processo inteiro nele: rodar o baseline (seÃ§Ã£o 2), testar as sequÃªncias
   de bypass da seÃ§Ã£o 3 nele (sempre no fim do path, com/sem barra â€” nunca
   em segmento interno), e se ela aceitar algum parÃ¢metro de ID/recurso,
   testar tambÃ©m o padrÃ£o da seÃ§Ã£o 9 nesse parÃ¢metro. Uma rota de JS pode
   ela mesma esconder outra camada de proxy/normalizaÃ§Ã£o atrÃ¡s dela â€” nÃ£o
   assuma que sÃ³ porque veio de um JS ela jÃ¡ estÃ¡ "no nÃ­vel certo".
6. Isso pode gerar vÃ¡rias camadas: JS revela rota Ã¢â€ â€™ rota revela outro JS Ã¢â€ â€™
   esse JS revela mais rotas. Repita o processo em cada camada nova atÃ©
   parar de encontrar coisa nova ou esgotar o tempo razoÃ¡vel de teste.
7. **A fonte nÃ£o precisa ser sÃ³ JS estÃ¡tico â€” vale qualquer path visto em
   trÃ¡fego capturado.** Ao navegar/usar a aplicaÃ§Ã£o com o proxy (Burp/
   interceptador) capturando tudo, toda requisiÃ§Ã£o de API que aparecer no
   histÃ³rico Ã© candidata a virar path base â€” nÃ£o importa se ela veio de uma
   rota lida dentro de um `.js`, ou se foi o prÃ³prio navegador que disparou
   a chamada em tempo real (com ou sem token de autenticaÃ§Ã£o presente).
   Exemplos do tipo de path que conta:
   ```
   /api/token/proxy/user/123123
   /api/usr/admin/porta/
   ```
   Esses dois exemplos jÃ¡ sÃ£o candidatos vÃ¡lidos pra rodar o processo
   completo: baseline (seÃ§Ã£o 2), sequÃªncias de bypass (seÃ§Ã£o 3) no fim do
   path, e â€” como `123123` e `admin` parecem parÃ¢metros de ID/recurso â€”
   tambÃ©m o padrÃ£o de travessia em parÃ¢metro da seÃ§Ã£o 9:
   ```
   /api/token/proxy/user/123123..;/
   /api/token/proxy/user/123123/..;/
   /api/token/proxy/user/123123/..%2f
   /api/usr/admin/porta/..;/
   /api/usr/admin..;/porta/
   ```
8. **Teste cada path capturado duas vezes: com o token/sessÃ£o atual e sem
   ele** (removendo o header de Authorization/cookie de sessÃ£o). O
   comportamento pode mudar â€” Ã  s vezes a travessia sÃ³ revela algo quando
   autenticado, Ã  s vezes sÃ³ funciona sem autenticaÃ§Ã£o porque o backend
   interno nÃ£o valida o token da mesma forma que o proxy externo.
9. **O que ignorar:** nÃ£o vale a pena rodar esse processo em toda requisiÃ§Ã£o
   de trÃ¡fego estÃ¡tico â€” pule paths que sÃ£o claramente arquivo de recurso
   estÃ¡tico pela extensÃ£o (`.js`, `.txt`, `.jsp`, `.css`, imagens, fontes).
   Esses raramente escondem uma rota de API por trÃ¡s; o volume de ruÃ­do nÃ£o
   compensa. Foque no trÃ¡fego que parece endpoint de API (JSON de
   request/response, paths com `/api/`, `/proxy/`, verbos REST, parÃ¢metros
   de ID) â€” Ã© aÃ­ que a travessia tem chance real de expor algo.
10. **Controle de deduplicaÃ§Ã£o â€” evitar loop infinito.** Como o processo Ã©
    recursivo (item 6: rota nova volta pro baseline, que pode gerar mais uma
    rota nova), Ã© obrigatÃ³rio manter uma lista de paths jÃ¡ testados (um "path
    visitado") e checar essa lista **antes** de rodar baseline/bypass em
    qualquer rota nova:
    - Normalize o path antes de comparar (mesma barra final ou nÃ£o, mesmo
      case, sem query string irrelevante) pra nÃ£o tratar
      `/api/v1/users/admin/123123` e `/api/v1/users/admin/123123/` como dois
      paths diferentes.
    - Se uma rota extraÃ­da de JS ou vista em trÃ¡fego **jÃ¡ estÃ¡ na lista de
      paths visitados** (por jÃ¡ ter sido testada como path base normal, ou
      por jÃ¡ ter sido o resultado de uma travessia anterior), **nÃ£o repita o
      processo nela** â€” ela jÃ¡ foi coberta, marque como "jÃ¡ testado" e siga
      pra prÃ³xima.
    - Exemplo prÃ¡tico: vocÃª faz a travessia em `/site.com/base/..;/`, ela
      carrega uma pÃ¡gina que referencia `api/v1/users/admin/123123`; ao
      tentar acessar isso soltando a travessia
      (`https://site.com/api/v1/users/admin/123123`), se esse path jÃ¡ tinha
      sido descoberto/testado antes por outra via, **nÃ£o teste de novo** â€”
      isso Ã© sÃ³ a mesma rota se repetindo, testar de novo geraria repetiÃ§Ã£o
      sem gerar informaÃ§Ã£o nova.
    - SÃ³ volta a testar um path jÃ¡ visitado se algo relevante mudou desde a
      Ãºltima vez (ex.: agora vocÃª tem um token que nÃ£o tinha antes, ou uma
      sequÃªncia de bypass nova que ainda nÃ£o tinha testado nele).
    - Se em algum momento o mesmo conjunto de paths comeÃ§ar a se repetir sem
      revelar nada novo por vÃ¡rias camadas seguidas, isso Ã© o sinal de parar
      aquela ramificaÃ§Ã£o â€” nÃ£o insista indefinidamente.

## 7. Ambientes de staging vs. produÃ§Ã£o

Se o alvo tem convenÃ§Ã£o de subdomÃ­nio por ambiente (`stg.`, `dev.`, `uat.`,
sem prefixo = produÃ§Ã£o), e uma rota interna sÃ³ existir no ambiente de
staging, vale testar se a mesma rota/endpoint existe no domÃ­nio de produÃ§Ã£o
equivalente (removendo o prefixo de ambiente). Ã€s vezes a travessia sÃ³ Ã©
alcanÃ§Ã¡vel em produÃ§Ã£o mesmo que tenha sido descoberta em staging, ou
vice-versa.

**Caso real â€” descoberta em stg, dados em prod:** a travessia foi confirmada
e um endpoint de recuperaÃ§Ã£o de token foi achado via JS, mas a rota nÃ£o
existia no ambiente de staging. O caminho foi trocar pro ambiente de
produÃ§Ã£o equivalente (remover o prefixo de ambiente) e testar **a mesma
travessia e o mesmo endpoint lÃ¡** â€” em produÃ§Ã£o o endpoint respondeu e o
token recuperado dava acesso a dados sensÃ­veis de dezenas de milhares de
usuÃ¡rios. Regra: **ambiente que nÃ£o tem a rota nÃ£o significa que a rota nÃ£o
existe â€” troque de ambiente (stg Ã¢â€ â€™ prod, dev Ã¢â€ â€™ prod, prod Ã¢â€ â€™ stg) e repita o
processo completo** (travessia + endpoint + PoC de leitura).

## 8. CVEs e paths conhecidos para testar apÃ³s confirmar a tecnologia

Depois de identificar a stack exposta pelo traversal, pesquisar e testar (na
ordem: leitura/enumeraÃ§Ã£o antes de qualquer coisa mais invasiva):

- **Tomcat**: `/manager/html`, `/host-manager/html`, versÃ£o exposta em stack
  traces ou na prÃ³pria pÃ¡gina padrÃ£o (ex.: "Apache Tomcat/9.0.71") Ã¢â€ â€™
  pesquisar CVEs daquela versÃ£o especÃ­fica. Se a versÃ£o ficou visÃ­vel numa
  pÃ¡gina de erro, ela direciona as CVEs exatas a testar.
- **JBoss**: `/web-console`, `/jmx-console`, `/invoker/JMXInvokerServlet` Ã¢â€ â€™
  pesquisar CVEs de RCE via deserializaÃ§Ã£o conhecidas para a versÃ£o.
- **Axis2**: `/axis2/axis2-admin` Ã¢â€ â€™ credenciais padrÃ£o conhecidas, CVEs de
  upload de serviÃ§o malicioso.
- **GenÃ©rico**: `.git/config`, `.env`, `README.md`, `settings.py`,
  `.aws/credentials`, arquivos de actuator do Spring Boot (`/actuator/env`,
  `/actuator/heapdump`), configs de nginx/Django expostas. Em alvo **nginx**,
  `.git/config`/`.env`/`README.md`/`settings.py` sÃ£o testados sÃ³ na forma
  sem barra (regra obrigatÃ³ria da seÃ§Ã£o 3.1.1); nas demais tecnologias, nas
  duas formas.

Sempre validar se o CVE se aplica de fato Ã   versÃ£o identificada antes de
tentar qualquer exploraÃ§Ã£o â€” e restringir a leitura/enumeraÃ§Ã£o, nunca RCE ou
destruiÃ§Ã£o de dados, salvo autorizaÃ§Ã£o explÃ­cita do escopo.

### 8.1 â€” Chain de CVEs: como um 404 virou RCE (liÃ§Ã£o de caso real)

Caso real documentado (pÃ¡gina 404 Ã¢â€ â€™ RCE): um subdomÃ­nio mostrava um 404
"website is not in use" e nada no path discovery. No rodapÃ©, "Built on
xxxx CMS" â€” o nome do CMS foi colocado no path (`site.com/<cms>`) e isso
redirecionou pra um login SSO (`/sso/signin`). Brincando com o path, um
**stack trace do Tomcat revelou a versÃ£o 5.5.20**. A partir daÃ­:

1. **CVE-2007-0450** (directory traversal no `mod_proxy` do Tomcat): adicionar
   caracteres especiais no path â€” `site.com/<cms>/%5C../` â€” redirecionou
   direto pro **web console do JBoss** (bypass do proxy interno pro JBoss em
   localhost).
2. **CVE-2007-1036** (JBoss web console sem proteÃ§Ã£o): o console nÃ£o era
   protegido por senha Ã¢â€ â€™ acesso administrativo sem autenticaÃ§Ã£o.
3. **RCE** via deserializaÃ§Ã£o Java (ferramenta jexboss), sempre com as
   requisiÃ§Ãµes passando pelo mesmo bypass (`/<cms>/%5C../web-console`).

LiÃ§Ãµes pra aplicar: (1) um 404/redirect nÃ£o Ã© o fim â€” o servidor pode ter
pÃ¡ginas sobradas explorÃ¡veis; (2) **identificar a tecnologia E a versÃ£o
exata** (stack trace, pÃ¡gina padrÃ£o, header) e encadear CVEs conhecidas
daquela versÃ£o; (3) o bypass do proxy Ã© um prÃ©-requisito que se mantÃ©m em
TODAS as requisiÃ§Ãµes da cadeia (mesma sequÃªncia de travessia no path de cada
CVE testada); (4) depois de um acesso, procurar sensÃ­vel/escalonamento
horizontal (outros hosts na rede, `/etc/passwd`, dumps de backup) â€” mas
apenas leitura, dentro do escopo.

### 8.2 â€” Identificar a API/CMS exposto e consultar a DOCUMENTAÃ‡ÃƒO dele

Se a travessia cair numa API ou CMS identificÃ¡vel (ex.: uma API de busca do
Google, um framework especÃ­fico), **ler a documentaÃ§Ã£o pÃºblica daquela
API/CMS e testar os endpoints dela** atravÃ©s da travessia â€” em vez de testar
endpoints Ã  s cegas. Endpoints documentados, parÃ¢metros e CVEs daquela
aplicaÃ§Ã£o viram a lista de requests alvo
(`<PATH_BASE><SEQ_CONFIRMADA><endpoint-da-doc>`). Caso real: Sam Curry
identificou que a API interna era uma API do Google, leu a documentaÃ§Ã£o dela
e usou isso pra montar os endpoints a testar.

## 9. PadrÃ£o BFF / travessia num parÃ¢metro profundo (nÃ£o sÃ³ no `/base/`)

AlÃ©m da travessia logo num prefixo de rota (seÃ§Ãµes 2â€“3), existe um segundo
padrÃ£o, comum em arquiteturas **BFF (Backend for Frontend)** â€” onde um host
pÃºblico (`app.exemplo.com`) sÃ³ repassa a chamada pra um host interno de
verdade (ex.: `internal.exemplo.com`), geralmente sob um prefixo tipo
`/bff/proxy/...`. A diferenÃ§a chave pra seÃ§Ã£o 3: aqui a travessia nÃ£o Ã©
testada no prefixo raiz da rota, e sim **dentro de um parÃ¢metro que o
endpoint aceita como input** (um ID, um nome de recurso, etc.), porque Ã© esse
valor que costuma ser concatenado cru no path repassado ao backend interno.

**Como identificar se um endpoint Ã© candidato:**

- Endpoints "fixos", sem parÃ¢metro na URL (ex.: `/bff/proxy/orchestra/get-user`)
  normalmente **nÃ£o** aceitam travessia â€” o path Ã© fixo no cÃ³digo, nÃ£o hidrata
  de input do usuÃ¡rio. Teste, mas nÃ£o insista muito neles.
- Endpoints que tÃªm um valor variÃ¡vel na prÃ³pria URL (ex.:
  `/bff/proxy/stream/v1/users/me/streamItems/:streamItemId`) sÃ£o os bons
  candidatos â€” o `:streamItemId` costuma ser concatenado direto no path
  repassado pro host interno, entÃ£o dÃ¡ pra tentar travessia ali.
- Sinal de que funcionou: a resposta deixa de ser o JSON de erro
  genÃ©rico do BFF e passa a ser um JSON/HTML de outro sistema (ex.: outro
  formato de erro 404, mesmo ainda 404) â€” igual Ã   seÃ§Ã£o 4, comparar
  sempre contra o baseline daquele endpoint especÃ­fico.

**SequÃªncias a testar no parÃ¢metro (indo alÃ©m do `..;/` / `..%2f` padrÃ£o):**

```
:param/..%2f
:param/..;/
:param/../
:param/..%00/
:param/..%0d/
:param/..%5c
:param/..\
:param/..%ff/
:param/%2e%2e%2f
:param/.%2e/
:param/%3f
:param/%26
:param/%23
```

Se nenhuma variante simples responder diferente, use variantes mistas de
separador â€” misturar `\` e `.` no meio da sequÃªncia engana proxies/WAFs que sÃ³
sabem reconhecer o padrÃ£o "puro" `..\` ou `../`:

```
:param/..\..\               (uma travessia simples)
:param/..\..\..\             (WAF pode bloquear a partir daqui, ex.: 403)
:param/web\..\.\..\          (bypass: intercala \ e . dentro da sequÃªncia)
:param/web\..\.\..\.\..\.\..\.\..\.\..\.\   (vÃ¡rias travessias encadeadas, se o alvo estiver longe)
```

Se um nÃºmero de travessias especÃ­fico comeÃ§ar a dar 403 (WAF bloqueando a
partir de X diretÃ³rios), o prÃ³ximo passo nÃ£o Ã© desistir â€” Ã© tentar reescrever
a mesma quantidade de travessias com uma sequÃªncia "quebrada" (intercalando
`\` e `.` como acima, ou trocando por `%5c..;/`, `..%5c`, `..%2f` com duas
travessias) atÃ© a resposta voltar a mudar.

**Mapeando atÃ© a raiz do sistema interno:**

1. Ir aumentando o nÃºmero de travessias uma a uma, mantendo o resto do path
   fixo, atÃ© a resposta mudar de "404 Not Found" (ainda dentro do proxy/BFF)
   para **"400 Bad Request"** (ou equivalente) â€” isso indica que vocÃª chegou
   na raiz do sistema interno e passou dela, o backend nÃ£o sabe mais montar
   um path vÃ¡lido.
2. Uma vez identificada quantas travessias levam atÃ© a raiz, teste esse mesmo
   nÃºmero de travessias seguido de um nome de recurso **sem barra final** â€”
   se o servidor responder com **301/redirect** apontando pra
   `Location: /recurso/`, isso confirma que aquele nome de recurso existe na
   raiz do sistema interno.
3. A partir da raiz confirmada, mapear a Ã¡rvore do sistema interno com
   requests diretos na mesma sequÃªncia confirmada â€” **um nÃ­vel de cada vez**
   (ex.: `/search/` Ã¢â€ â€™ `/search/v1/` Ã¢â€ â€™ `/search/v1/accounts`), seguindo
   redirects/linkagens e testando nomes Ã³bvios da tecnologia identificada
   (seÃ§Ã£o 8); os prÃ³ximos nÃ­veis costumam aparecer via 301/redirect ou
   linkagem da prÃ³pria resposta.
4. Ao achar um endpoint de dados internos (tipo uma API de busca/listagem â€”
   ex.: se a travessia jÃ¡ retornou dados e a API interna parece conhecida,
   tipo Google API ou similar, procure primeiro a documentaÃ§Ã£o dela antes de
   testar endpoints Ã  s cegas â€” seÃ§Ã£o 8.2), testar parÃ¢metros de
   paginaÃ§Ã£o/filtro que a tecnologia identificada costuma aceitar (ex.:
   parÃ¢metros de contagem, paginaÃ§Ã£o ou filtro de uma API tipo OData/Graph)
   **apenas para confirmar o alcance do impacto na leitura** â€” nunca para
   extrair ou salvar dados em massa; o objetivo no relatÃ³rio Ã© provar que o
   acesso existe, nÃ£o coletar os dados.

**Testar em ambos os lugares do prÃ³prio path, nÃ£o sÃ³ um:** ao avaliar um
alvo com endpoints tipo `/bff/proxy/...` ou `/api/...`, testar a travessia
no fim do path (seÃ§Ã£o 3, ex. `/bff/proxy/..;/`) e dentro de cada parÃ¢metro
de ID/recurso que a rota aceitar (esta seÃ§Ã£o). SÃ£o bugs diferentes â€” um pode
funcionar sem o outro. NUNCA em segmento interno/profundo do path.

## 10. Registro de resultados (relatÃ³rio)

**No fluxo-padrÃ£o do usuÃ¡rio (seÃ§Ã£o 0), este registro materializa-se em
exatamente 3 arquivos no diretÃ³rio de trabalho:** `poc.txt` (sÃ³ URLs
confirmadas, uma por linha, sem tÃ­tulos/comentÃ¡rios â€” vazio se zero
achados), `testar_manual.txt` (sÃ³ sinais tecnicamente relevantes que
justificam olho humano, uma URL completa por linha) e `relatorio.txt`
(resumo curto com as seÃ§Ãµes **CONFIRMADO** / **INCONCLUSIVO-MANUAL** /
**SEM EVIDÃŠNCIA**). O relatÃ³rio diferencia claramente os trÃªs nÃ­veis e
explica os falsos positivos descartados; o usuÃ¡rio prefere honestidade
sobre limitaÃ§Ãµes (rate-limit, cap de cobertura) a relatÃ³rio inflado.

Fora desse fluxo, manter um arquivo de notas por engajamento
(`traversal_report.txt` na pasta de reports do engajamento, ou
`travessia_<alvo>.md` similar) dividido em TRÃŠS nÃ­veis, sempre nesta ordem
de prioridade:

1. **PoCs confirmadas 100%** â€” travessia + exploraÃ§Ã£o validada com evidÃªncia
   clara (endpoint sensÃ­vel acessado, arquivo interno lido, CVE executada,
   etc.). VÃªm PRIMEIRO no arquivo, com os curls exatos de reproduÃ§Ã£o.
2. **Travessias confirmadas, sem exploraÃ§Ã£o ainda** â€” normalizaÃ§Ã£o diverge e
   cai numa rota interna (ex.: pÃ¡gina do Tomcat acessÃ­vel via travessia, ou
   arquivo interno acessado) mas sem PoC de impacto fechada; registrar path
   exato, sequÃªncia usada e o que foi observado, para retomar depois.
3. **Travessias que valem verificaÃ§Ã£o manual** â€” sinais de menor certeza:
   troca de pÃ¡gina de erro, formato de erro diferente, mudanÃ§a de status sem
   confirmaÃ§Ã£o. Registrar **a URL completa com a sequÃªncia** (ex.:
   `https://site.com/path/..%2f`), uma por linha, pra revisÃ£o manual â€”
   nada pode ficar sÃ³ "na cabeÃ§a" ou enterrado em arquivo de log.

Nunca misturar os nÃ­veis â€” isso deixa claro no relatÃ³rio final o que Ã©
achado validado, o que Ã© pista pra investigar e o que merece olhada humana.

### 10.1 â€” Template real de relatÃ³rio (PoC confirmada)

Estrutura real usada com sucesso pra reportar uma PoC confirmada de path
traversal (nÃ­vel 1 da lista acima). Usar como modelo â€” adaptar os campos
entre colchetes:

```
Overview of the Vulnerability
Path traversal uses a server misconfiguration to access hidden files and
directories that are stored on the served web application. This can
include sensitive operating files, code and data that runs the
application, or in some cases, user credentials.
An attacker can leverage the path traversal vulnerability in this
application to gain access to system files in a folder of a directory
that is not intended for public access.

Business Impact
Path traversal can lead to reputational damage for the business due to a
loss in confidence and trust by users. It can also result in data theft
and indirect financial losses to the business through the costs of
notification and rectifying breached PII data if an attacker can
successfully exfiltrate user data.

Steps to Reproduce
Use Burp to replicate this request:

GET /[arquivo-alvo] HTTP/2
Host: [alvo]
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Encoding: gzip,deflate,br
User-Agent: [user-agent]
Connection: Keep-alive

Note that the response was 404 Not Found (default page) â€” the file is not
directly accessible.

GET /[path-base]../[arquivo-alvo] HTTP/2
Host: [alvo]
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Encoding: gzip,deflate,br
User-Agent: [user-agent]
Connection: Keep-alive

Note that it was possible to read the contents of the file.
```

Pontos-chave desse modelo, que valem pra qualquer PoC confirmada da skill:

1. **Sempre mostrar o baseline primeiro** (request sem travessia, 404/erro
   padrÃ£o) e sÃ³ depois o request com a sequÃªncia que funcionou â€” a diferenÃ§a
   entre os dois Ã‰ a prova.
2. **Overview genÃ©rico e reutilizÃ¡vel** â€” a explicaÃ§Ã£o de "o que Ã© path
   traversal" nÃ£o muda de relatÃ³rio pra relatÃ³rio; sÃ³ os detalhes de
   "Steps to Reproduce" e o que foi de fato lido mudam.
3. **Business Impact em termos de negÃ³cio**, nÃ£o sÃ³ tÃ©cnico (reputaÃ§Ã£o,
   custo de notificaÃ§Ã£o/remediaÃ§Ã£o, exposiÃ§Ã£o de PII) â€” nÃ£o citar
   `Anthropic`/dados do reporter, focar no impacto pro programa/empresa
   dona do alvo.
4. **Fechar com uma nota de honestidade sobre cobertura** quando aplicÃ¡vel
   â€” ex.: "outros nomes de arquivo comumente testados nÃ£o retornaram
   conteÃºdo neste alvo; validar contra a lista de arquivos que
   comprovadamente existem no servidor pode ampliar a cobertura" (mesmo
   espÃ­rito da seÃ§Ã£o 0.4: honestidade sobre limitaÃ§Ã£o em vez de relatÃ³rio
   inflado).
5. Se o arquivo lido (README, config etc.) revelar informaÃ§Ã£o sensÃ­vel
   adicional (entrypoints, credenciais, comandos, nomes de servidor/infra â€”
   caso real completo na seÃ§Ã£o 3.1.2), resumir isso numa seÃ§Ã£o extra do
   relatÃ³rio (ex.: "Additional Information Disclosed") **sem colar o
   conteÃºdo sensÃ­vel inteiro** â€” descrever o que foi encontrado e o
   impacto, mantendo segredos/credenciais fora do corpo do relatÃ³rio quando
   o programa pedir redaÃ§Ã£o (`[REDACTED]`).

## 11. Casos reais â€” checklist de liÃ§Ãµes de DETECÃ‡ÃƒO (nada disso pode passar)

Checklist consolidada dos padrÃµes reais que jÃ¡ flagraram travessia. Se
qualquer item abaixo acontecer ao comparar o probe com o baseline, Ã©
candidato a travessia â€” registrar e seguir o fluxo de confirmaÃ§Ã£o:

1. **PÃ¡gina diferente no lugar do erro**: o probe responde uma pÃ¡gina que nÃ£o
   Ã© o erro padrÃ£o do baseline (outra app, outra tela, JS novo).
2. **Troca de template de erro**: mesmo status, mas o erro Ã© de OUTRO sistema
   â€” Tomcat (`HTTP Status ...`, `Apache Tomcat/x.y.z`), JSP/Spring (ex.:
   `<c:url value='...'>`), gateway (`404 Not Found / GATEWAY`), vs. erro
   padrÃ£o da app (JSON `{"message":"..."}` ou pÃ¡gina normal).
3. **Erro 400 do Tomcat apÃ³s travessia** ("Invalid URI"): o backend Java
   recebeu a sequÃªncia crua e quebrou â€” sinal clÃ¡ssico de repasse sem
   normalizaÃ§Ã£o.
4. **SÃ³ a pÃ¡gina de erro do Tomcat, sem dados**: nÃ£o precisa virar um 200 com
   dados pra ser travessia â€” um erro do Tomcat no lugar do erro da app
   principal jÃ¡ Ã© o sinal (caso real de app Java).
5. **Forma SEM barra funcionou** (`path..%2f`, `path..%5C..%5C`) quando a
   forma com barra deu 403/nada â€” e vice-versa. Sempre as 4 combinaÃ§Ãµes
   (com/sem barra Ã— 1/2 travessias) por sequÃªncia.
6. **2 travessias sem barra** funcionando onde 1 travessia nÃ£o faz nada
   (caso real: `rota..%2f..%2f404.html` Ã¢â€ â€™ erro GATEWAY; `rota/...` Ã¢â€ â€™ 403).
7. **`.git/config`, `.env`, `README.md`, `settings.py`** respondendo na
   forma colada no path com `%5C`/`%2f` (`app..%5C..%5C.git/config` jÃ¡ vazou
   repositÃ³rio com token). **Em alvo nginx isso Ã© regra obrigatÃ³ria, nÃ£o sÃ³
   um sinal**: esses 4 arquivos com `..%2f`, `..%2f..%2f`, `..%5C`,
   `..%5C..%5C` sÃ£o testados **sÃ³ na forma sem barra** (seÃ§Ã£o 3.1.1); a
   forma com barra nÃ£o Ã© testada para esse conjunto especÃ­fico em nginx.
   Em Tomcat/JBoss/Java, continuam testados nas duas formas normalmente.
8. **Raiz nÃ£o-HTML** (imagem, PNG, binÃ¡rio): nÃ£o descarta nada â€” a app pode
   estar atrÃ¡s do proxy mesmo assim (SPA Vue atrÃ¡s de um path de API).
9. **AplicaÃ§Ã£o escondida atrÃ¡s de um path** cuja existÃªncia sÃ³ o erro
   diferente revela (a raiz mostrava uma pÃ¡gina de teste de servidor; a app
   real morava num path com login prÃ³prio).
10. **Host espelho apontado por JS**: antes de seguir pro host parecido,
    testar o MESMO path no host original (caso real de painel escondido).
11. **Tecnologia/versÃ£o identificÃ¡vel** na resposta (stack trace, pÃ¡gina
    padrÃ£o, header): anotar versÃ£o exata Ã¢â€ â€™ CVEs daquela versÃ£o (seÃ§Ã£o 8.1).
12. **Rota do JS que sÃ³ funciona ATRAVÃ‰S da travessia** â€” testar sempre as 3
    formas (atravÃ©s da travessia / com prefixo / direto na raiz).
13. **Ambiente sem a rota** (stg sem o endpoint): trocar pro ambiente
    equivalente (prod) e repetir o processo completo (caso real de token de
    usuÃ¡rios em prod).
14. **ValidaÃ§Ã£o em todos os contextos**: comparar travessia com baseline,
    raiz direta e path direto antes de reportar â€” se a raiz direta mostra a
    mesma coisa, o achado Ã© mais fraco (caso real de Tomcat exposto na raiz).
15. **Cuidado com os falsos positivos clÃ¡ssicos da mÃ¡quina** (todos jÃ¡
    observados em alvos reais, todos desmontados com controle): pÃ¡gina de
    404 que ECOA a URL requisitada (regex de `.jsp`/stack casa na URL
    ecoada, nÃ£o em conteÃºdo); pÃ¡gina dinÃ¢mica (challenge do Cloudflare,
    SSO/SAML com parÃ¢metros aleatÃ³rios por request â€” fingerprint nunca
    bate no seq-bad); catch-all 200 que ecoa o path (len cresce exatamente
    pelo nome do arquivo colado); 403/401 uniformes de WAF/agente (path
    aleatÃ³rio responde idÃªntico); resultado igual Ã   raiz pÃºblica do host
    (normalizaÃ§Ã£o, nÃ£o travessia); 503 flaky de upstream. O controle
    "mesma sequÃªncia num path aleatÃ³rio do host" Ã© o que separa sinal de
    ruÃ­do â€” e diferenÃ§a de comportamento isolada nunca Ã© confirmaÃ§Ã£o
    (seÃ§Ã£o 0.3).
16. **Backend Windows/IIS atrÃ¡s de proxy (seÃ§Ã£o 5.1)**: `..%5c` sem barra
    antes da sequÃªncia respondendo directory listing da webroot da app
    interna = sinal fortÃ­ssimo. Filtro de extensÃ£o do IIS (Request Filtering)
    bloqueia `.cs`/`.config`/`.pdb` mas **`.txt`/`.xml` passam e baixam
    integrais** â€” e **`.dll` pode NÃƒO estar bloqueada**: testar o download
    explÃ­cito do binÃ¡rio .NET e conferir tamanho contra o listing
    (integridade). DLL baixada Ã¢â€ â€™ decompilaÃ§Ã£o (dnSpy/ILSpy) Ã¢â€ â€™ credencial
    LDAP, chaves JWT/OCR, queries SQL do banco e URL interna (caso real
    mssplus.stg.starbucks.com.cn, seÃ§Ã£o 5.1). Mesma sequÃªncia vale pra
    aliases de prefixo (`/api/`, `/api2/`, `/apicache/`...) e pros dois
    ambientes (stg e prod, md5 idÃªntico).
17. **`../` cru, sem nenhum encoding, jÃ¡ Ã© suficiente em muitos alvos**: nÃ£o
    pule direto pras variantes `%2f`/`%5c`/`;` â€” teste primeiro
    `<path>../<arquivo>` e `<path>/../<arquivo>` sem nenhuma codificaÃ§Ã£o
    (caso real: `/README.md` Ã¢â€ â€™ 404; `/api../README.md` Ã¢â€ â€™ 200 com o conteÃºdo
    do arquivo, seÃ§Ã£o 3.1.2). Depois de ler o conteÃºdo, **extraia tudo**:
    entrypoints internos (novos path base, seÃ§Ãµes 2/3), URLs de outros
    ambientes (seÃ§Ã£o 7), nome/infra do servidor (seÃ§Ã£o 8) e comandos
    citados (documentar como evidÃªncia, **nunca executar** â€” regra de ouro).

## 12. Leituras de referÃªncia

- Orange Tsai â€” "Breaking Parser Logic: Take Your Path Normalization Off and
  Pop 0-Days Out" (Black Hat):
  https://i.blackhat.com/us-18/Wed-August-8/us-18-Orange-Tsai-Breaking-Parser-Logic-Take-Your-Path-Normalization-Off-And-Pop-0days-Out-2.pdf
  â€” a referÃªncia clÃ¡ssica sobre discrepÃ¢ncias de normalizaÃ§Ã£o entre proxy e
  backend.
- Sam Curry â€” "Hacking Starbucks" (samcurry.net/hacking-starbucks) â€” o
  writeup que originou a tÃ©cnica da seÃ§Ã£o 9: travessia dentro de um parÃ¢metro
  de um endpoint BFF, mapeando atÃ© a raiz do sistema interno via respostas
  400/301, bypass de WAF intercalando separadores, e identificaÃ§Ã£o da API
  interna (Google) pra consultar a documentaÃ§Ã£o dela (seÃ§Ã£o 8.2).
- zoidsec (Blake):
  - "How I Hacked a Crypto Company and Could Steal $1 Million Dollars Worth
    of Bitcoin":
    https://zoidsec.medium.com/how-i-hacked-a-crypto-company-and-could-steal-1-million-dollars-worth-of-bitcoin-3174434b382c
  - "Breaking Parse Logic â€” Gain Access to Nginx API / Read-Write Upstreams":
    https://zoidsec.medium.com/breaking-parse-logic-gain-access-to-nginx-api-read-write-upstreams-1cb062aa44ca

Use essas fontes para se atualizar sobre tÃ©cnicas de encoding e novas
variantes â€” a lista de sequÃªncias nas seÃ§Ãµes 3 e 9 nÃ£o Ã© exaustiva, Ã© o ponto
de partida.
