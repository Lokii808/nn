#!/usr/bin/env python3
"""
swtest.py - Swagger/OpenAPI endpoint tester (sj-style, self-contained).
Substituto do BishopFox/sj quando go/sj nao estao disponiveis.

Comandos:
  discover  <ui_url>          acha a(s) URL(s) de spec a partir de uma pagina Swagger UI
  endpoints <spec_url>        lista os endpoints do spec (sem enviar request)
  automate  <spec_url>        envia 1 request por endpoint e classifica o status
  prepare   <spec_url>        imprime comandos curl para teste manual

Flags:
  -H "Nome: Valor"   header extra (repetivel)
  -T host            override do host de destino
  -k                 ignora TLS
  (default)          automate: testa GET/HEAD/OPTIONS/POST/PUT/PATCH; bloqueia DELETE
  --allow-delete     automate: inclui tambem DELETE (destrutivo, cuidado!)
  -t N               timeout (s), default 20
"""
import sys, json, re, argparse, urllib.parse
try:
    import requests, yaml
except ImportError:
    print("faltando: pip install requests pyyaml"); sys.exit(1)
import warnings; warnings.filterwarnings("ignore")

BLOCKED = {"delete"}   # so DELETE e bloqueado por padrao; POST/PUT/PATCH sao testados
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"

def load(text):
    try: return json.loads(text)
    except Exception: return yaml.safe_load(text)

class _R:
    def __init__(self, text): self.text=text
def fetch(url, hdrs, k, t):
    if not re.match(r'^https?://', url):     # caminho local
        return _R(open(url, encoding='utf-8', errors='replace').read())
    return requests.get(url, headers=hdrs, verify=not k, timeout=t)

def discover(ui_url, hdrs, k, t):
    r = fetch(ui_url, hdrs, k, t)
    html = r.text
    specs = set()
    for m in re.findall(r'''(?:url|configUrl|spec)\s*[:=]\s*["']([^"']+\.(?:ya?ml|json))''', html, re.I):
        specs.add(m)
    for m in re.findall(r'''["'](/[^"']+\.(?:ya?ml|json))["']''', html):
        specs.add(m)
    # swagger-initializer.js costuma ter a url real
    for js in re.findall(r'src=["\']([^"\']+\.js)["\']', html):
        try:
            ju = urllib.parse.urljoin(ui_url, js)
            jt = fetch(ju, hdrs, k, t).text
            for m in re.findall(r'''url\s*[:=]\s*["']([^"']+\.(?:ya?ml|json))''', jt, re.I):
                specs.add(m)
        except Exception: pass
    base = ui_url
    out = []
    for s in sorted(specs):
        out.append(s if s.startswith("http") else urllib.parse.urljoin(base, s))
    return out

def parse_spec(spec_url, hdrs, k, t):
    r = fetch(spec_url, hdrs, k, t)
    d = load(r.text)
    if not d: return None, []
    # base host
    if "servers" in d and d["servers"]:
        server = d["servers"][0]["url"]
    elif "host" in d:
        scheme = (d.get("schemes") or ["https"])[0]
        server = f"{scheme}://{d['host']}{d.get('basePath','')}"
    else:
        p = urllib.parse.urlsplit(spec_url)
        server = f"{p.scheme}://{p.netloc}"
    if not server.startswith("http"):
        server = urllib.parse.urljoin(spec_url, server)
    eps = []
    for path, item in (d.get("paths") or {}).items():
        for method, op in (item or {}).items():
            if method.lower() not in ("get","post","put","patch","delete","head","options"): continue
            eps.append((method.upper(), path, (op or {}).get("summary","") if isinstance(op,dict) else ""))
    return server, eps

def fill(path):
    # substitui {param} por valor de teste
    return re.sub(r'\{[^}]+\}', '1', path)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["discover","endpoints","automate","prepare"])
    ap.add_argument("url")
    ap.add_argument("-H", action="append", default=[])
    ap.add_argument("-T", default=None)
    ap.add_argument("-k", action="store_true")
    ap.add_argument("--allow-delete", action="store_true", help="inclui DELETE (destrutivo)")
    ap.add_argument("-t", type=int, default=20)
    a = ap.parse_args()
    hdrs = {"User-Agent": UA}
    for h in a.H:
        if ":" in h: kk,vv=h.split(":",1); hdrs[kk.strip()]=vv.strip()

    if a.cmd == "discover":
        for s in discover(a.url, hdrs, a.k, a.t): print(s)
        return

    server, eps = parse_spec(a.url, hdrs, a.k, a.t)
    if server is None:
        print("[!] nao consegui parsear o spec"); return
    if a.T: server = re.sub(r'https?://[^/]+', a.T.rstrip('/'), server) if '://' in a.T else re.sub(r'(https?://)[^/]+', r'\1'+a.T, server)
    print(f"[server] {server}   [endpoints] {len(eps)}", file=sys.stderr)

    if a.cmd == "endpoints":
        for m,p,s in eps: print(f"{m:7} {p}   {s}")
        return
    if a.cmd == "prepare":
        for m,p,s in eps:
            u = server.rstrip('/') + fill(p)
            hs = " ".join(f"-H '{k}: {v}'" for k,v in hdrs.items())
            print(f"curl -sk -X {m} {hs} '{u}'")
        return
    if a.cmd == "automate":
        hits=[]
        for m,p,s in eps:
            if m.lower() in BLOCKED and not a.allow_delete:
                print(f"[skip-delete] {m:7} {p}   (use --allow-delete para incluir)"); continue
            u = server.rstrip('/') + fill(p)
            try:
                r = requests.request(m, u, headers=hdrs, verify=not a.k, timeout=a.t, allow_redirects=False)
                code = r.status_code; ln = len(r.content)
            except Exception as e:
                print(f"[err] {m:7} {p}  {e}"); continue
            flag = ""
            if code == 200: flag = "  <== 200 SEM AUTH? verificar"
            elif code in (401,403): flag = "  (protegido)"
            elif code in (500,): flag = "  <== 500 erro server"
            print(f"[{code}] {ln:>7}b {m:7} {p}{flag}")
            if code == 200: hits.append((m,p,u,ln))
        print(f"\n### {len(hits)} endpoints retornaram 200 sem autenticacao", file=sys.stderr)
        for m,p,u,ln in hits: print(f"   {m} {u}  ({ln}b)", file=sys.stderr)

if __name__ == "__main__":
    main()