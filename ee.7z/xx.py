import os
import yaml

def update_yaml_ids(directory):
    yaml_files = [f for f in os.listdir(directory) if f.endswith('.yaml')]
    used_ids = set()  # Para garantir IDs únicos

    for index, file_name in enumerate(yaml_files, start=1):
        file_path = os.path.join(directory, file_name)

        with open(file_path, 'r') as file:
            try:
                content = yaml.safe_load(file)  # Carrega o conteúdo do YAML
                if 'id' in content:
                    original_id = content['id']
                    # Gera um novo ID com sufixo único
                    new_id = f"{original_id}-{index}"
                    while new_id in used_ids:  # Evita duplicatas
                        index += 1
                        new_id = f"{original_id}-{index}"
                    content['id'] = new_id
                    used_ids.add(new_id)
                else:
                    print(f"Aviso: 'id' não encontrado em {file_name}.")
                    continue
            except Exception as e:
                print(f"Erro ao processar {file_name}: {e}")
                continue

        # Salva o YAML atualizado
        with open(file_path, 'w') as file:
            yaml.dump(content, file, default_flow_style=False)

        print(f"'id' atualizado em: {file_name}")

# Use a função apontando para o diretório com os arquivos YAML
directory_path = r"C:\Users\xx\Desktop\bot recon\bot sub\paths\esses"
update_yaml_ids(directory_path)
