#!/usr/bin/env python3

import os
import sys
from urllib.parse import urlparse


def main():
    if len(sys.argv) != 2:
        print(f"Uso: python3 {sys.argv[0]} lista.txt")
        sys.exit(1)

    lista = sys.argv[1]

    if not os.path.isfile(lista):
        print(f"Arquivo não encontrado: {lista}")
        sys.exit(1)

    katana_out = "katana.txt"

    cmd = (
        f"katana -list {lista} "
        "-fs rdn "
        "-jc "
        "-ct 240 "
        "-c 5 "
        "-d 2 "
        "-retry 1 "
        "-silent "
        "-timeout 5 "
        "-ef jpg,jpeg,gif,css,tif,tiff,png,ttf,woff,woff2,ico,pdf,svg,txt"
        f"-o {katana_out}"
    )

    print("[+] Executando Katana...")
    os.system(cmd)

    if not os.path.exists(katana_out):
        print("[-] katana.txt não foi gerado.")
        sys.exit(1)

    print("[+] Carregando escopo...")

    escopo = set()

    with open(lista, "r") as f:
        for linha in f:
            url = linha.strip()

            if not url:
                continue

            host = urlparse(url).netloc.lower()

            if host:
                escopo.add(host)

    print(f"[+] {len(escopo)} domínios no escopo.")

    linhas_validas = []

    with open(katana_out, "r") as f:
        for linha in f:
            url = linha.strip()

            if not url:
                continue

            host = urlparse(url).netloc.lower()

            if not host:
                continue

            for dominio in escopo:
                if host == dominio or host.endswith("." + dominio):
                    linhas_validas.append(url)
                    break

    with open(katana_out, "w") as f:
        for url in sorted(set(linhas_validas)):
            f.write(url + "\n")

    print(f"[+] {len(linhas_validas)} URLs permaneceram dentro do escopo.")
    print(f"[+] Resultado salvo em {katana_out}")


if __name__ == "__main__":
    main()