import os
import time
import sys

# CORREÇÃO 1: Verificar ferramentas necessárias
def check_tool(tool_name):
    """Verifica se uma ferramenta está instalada"""
    return os.system(f"which {tool_name} > /dev/null 2>&1") == 0

def check_and_install_tools():
    """Verifica e orienta sobre ferramentas faltantes"""
    tools = {
        "subfinder": "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
        "jq": "sudo apt install jq -y",
        "anew": "go install -v github.com/tomnomnom/anew@latest",
        "unfurl": "go install -v github.com/tomnomnom/unfurl@latest",
        "curl": "sudo apt install curl -y"
    }
    
    missing = []
    for tool, install_cmd in tools.items():
        if not check_tool(tool):
            missing.append(f"  - {tool}: {install_cmd}")
    
    if missing:
        print("❌ Ferramentas faltando:")
        for msg in missing:
            print(msg)
        print("\n⚠️  Instale as ferramentas acima e tente novamente.")
        return False
    return True

# Verificar ferramentas antes de começar
print("[+] Verificando ferramentas necessárias...")
if not check_and_install_tools():
    sys.exit(1)

# Ler a lista de domínios do arquivo
if not os.path.exists("xx.txt"):
    print("❌ Arquivo xx.txt não encontrado!")
    sys.exit(1)

with open("xx.txt", "r") as f:
    domain_list = [d.strip() for d in f.read().splitlines() if d.strip()]

if not domain_list:
    print("❌ Nenhum domínio encontrado em xx.txt")
    sys.exit(1)

print(f"[+] {len(domain_list)} domínios carregados: {', '.join(domain_list)}\n")

# Criar um arquivo para armazenar todos os subdomínios encontrados
with open("todos_subs.txt", "w") as output_file:
    output_file.write("")  # Limpa o arquivo

total_subdomains = 0

for idx, domain_nome in enumerate(domain_list, 1):
    print(f"\n{'='*50}")
    print(f"[{idx}/{len(domain_list)}] Enumerando subdomínios para: {domain_nome}")
    print(f"{'='*50}")
    
    # Limpar arquivo temporário anterior
    if os.path.exists("temp_subs.txt"):
        os.remove("temp_subs.txt")
    
    # 1. Subfinder
    print("  ⏳ Subfinder...")
    os.system(f"subfinder -all -d {domain_nome} >> temp_subs.txt 2>/dev/null")
    time.sleep(1)
    print("  ✅ Subfinder OK")
    
    # 2. crt.sh
    print("  ⏳ crt.sh...")
    os.system(f"curl -s 'https://crt.sh/?q=%25.{domain_nome}&output=json' | jq -r '.[].name_value' 2>/dev/null | anew | sed 's/\\*\\.//g' >> temp_subs.txt")
    print("  ✅ crt.sh OK")
    
    # 3. Anubis (jldc.me) - APENAS UMA VEZ
    print("  ⏳ Anubis (jldc.me)...")
    os.system(f'curl -s "https://jldc.me/anubis/subdomains/{domain_nome}" | grep -Po "((http|https):\\/\\/)?(([\\w.-]*)\\.([\\w]*)\\.([A-z]))\\w+" 2>/dev/null | anew >> temp_subs.txt')
    time.sleep(1)
    print("  ✅ Anubis OK")
    
    # 4. Wayback Machine (Archive)
    print("  ⏳ Wayback Machine...")
    os.system(f'curl -s "http://web.archive.org/cdx/search/cdx?url=*.{domain_nome}&output=text&fl=original&collapse=urlkey" | sed -e "s_https*://__" -e "s/\\?.*//" | sort -u >> temp_subs.txt 2>/dev/null')
    print("  ✅ Archive OK")
    
    # 5. AlienVault OTX
    print("  ⏳ AlienVault OTX...")
    os.system(f"curl -s 'https://otx.alienvault.com/api/v1/indicators/domain/{domain_nome}/url_list?limit=100&page=1' | jq -r '.url_list[]?.hostname' 2>/dev/null | sort -u >> temp_subs.txt")
    print("  ✅ AlienVault OK")
    
    # 6. Subdomain Center
    print("  ⏳ Subdomain Center...")
    os.system(f'curl -s "https://api.subdomain.center/?domain={domain_nome}" | jq -r ".[]" 2>/dev/null | sort -u >> temp_subs.txt')
    print("  ✅ Subdomain Center OK")
    
    # REMOVIDO: JLDC (repetido com Anubis)
    
    # Filtrar e adicionar ao arquivo final
    print("  ⏳ Filtrando e consolidando...")
    os.system("cat temp_subs.txt 2>/dev/null | anew | unfurl domain 2>/dev/null | sort -u >> todos_subs.txt")
    
    # Contar quantos subdomínios foram encontrados neste domínio
    domain_count = 0
    if os.path.exists("todos_subs.txt"):
        with open("todos_subs.txt", "r") as f:
            all_subs = f.read().splitlines()
            # Contar subdomínios deste domínio específico
            domain_count = len([s for s in all_subs if s.endswith(f".{domain_nome}") or s == domain_nome])
    
    total_subdomains += domain_count
    print(f"  ✅ {domain_count} subdomínios encontrados para {domain_nome}")
    print(f"  📊 Total acumulado: {total_subdomains}")
    
    # Limpar arquivo temporário
    os.system("rm -f temp_subs.txt")
    
    # Pequena pausa entre domínios para evitar rate limiting
    if idx < len(domain_list):
        print("  ⏳ Aguardando 3 segundos antes do próximo domínio...")
        time.sleep(3)

print(f"\n{'='*50}")
print(f"✅ Processo concluído!")
print(f"📊 Total de subdomínios únicos: {total_subdomains}")
print(f"📁 Arquivo salvo em: todos_subs.txt")
print(f"{'='*50}")

# Estatísticas finais
if os.path.exists("todos_subs.txt"):
    with open("todos_subs.txt", "r") as f:
        final_count = len(f.read().splitlines())
    print(f"📊 Total no arquivo: {final_count} subdomínios")
    print(f"💡 Dica: Use 'cat todos_subs.txt | head -10' para visualizar os primeiros")